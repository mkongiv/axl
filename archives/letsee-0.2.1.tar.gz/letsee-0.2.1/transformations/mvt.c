/* Generated from transformations/matvecttransp.cloog by CLooG v0.14.0 64 bits in 0.00s. */
/* CLooG asked for 164 KBytes. */
/* DON'T FORGET TO USE -lm OPTION TO COMPILE. */

/* Useful headers. */
#include <sys/time.h>
#include <sys/resource.h>
#include <time.h>
#include <sched.h>
  
#include <string.h>
#define LD_CACHE_SIZE 150000
#define FLOAT_TYPE double
#define FLOAT_MODIFIER "%f "

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* Parameter value. */
#define PARVAL 1

/* Useful macros. */
#define ceild(n,d)  ceil(((double)(n))/((double)(d)))
#define floord(n,d) floor(((double)(n))/((double)(d)))
#define max(x,y)    ((x) > (y)? (x) : (y))  
#define min(x,y)    ((x) < (y)? (x) : (y))  

/* Statement macros (please set). */
#define S1(i) { x1[i] = 0; }
#define S2(i) { x2[i] = 0; }
#define S3(i,j) { x1[i] = x1[i] + a[i][j] * y1[j]; }
#define S4(i,j) { x2[i] = x2[i] + a[j][i] * y2[j]; }

int main(int argc, char** argv) {
  

#ifdef test_malloc
/* Array declaration. */
FLOAT_TYPE* x1 = (FLOAT_TYPE*) malloc((PARVAL1 + 1) * sizeof(FLOAT_TYPE));
FLOAT_TYPE* x2 = (FLOAT_TYPE*) malloc((PARVAL1 + 1) * sizeof(FLOAT_TYPE));
FLOAT_TYPE* y1 = (FLOAT_TYPE*) malloc((PARVAL1 + 1) * sizeof(FLOAT_TYPE));
FLOAT_TYPE* y2 = (FLOAT_TYPE*) malloc((PARVAL1 + 1) * sizeof(FLOAT_TYPE));
FLOAT_TYPE** a = (FLOAT_TYPE**) malloc((PARVAL1 + 1) * sizeof(FLOAT_TYPE*));

#else
FLOAT_TYPE x1[PARVAL1 + 1];
FLOAT_TYPE x2[PARVAL1 + 1];
FLOAT_TYPE y1[PARVAL1 + 1];
FLOAT_TYPE y2[PARVAL1 + 1];
FLOAT_TYPE a[PARVAL1 + 1][PARVAL1 + 1];
#endif

long double* cache;
cache = (long double*) malloc(LD_CACHE_SIZE * sizeof(long double));


/* Array initialization. */
unsigned iarray, iarray2;
for (iarray = 0; iarray <= PARVAL1; ++iarray) {
   x1[iarray] = M_PI;
   x2[iarray] = M_PI;
   y1[iarray] = M_PI;
   y2[iarray] = M_PI;
#ifdef test_malloc
   a[iarray] = (FLOAT_TYPE*) malloc((PARVAL1 + 1) * sizeof(FLOAT_TYPE));
#endif
   for (iarray2 = 0; iarray2 <= PARVAL1; ++iarray2)
      a[iarray][iarray2] = M_PI;
}

/* Clear the cache */
for (iarray = 0; iarray < LD_CACHE_SIZE; ++iarray)
   cache[iarray] = M_PI;

  /* Use FIFO scheduler to limit OS interference. */
  struct sched_param schedParam;
  schedParam.sched_priority = 99;
  sched_setscheduler(0, SCHED_FIFO, &schedParam);

  /* Initialize timer */
  double		time_start, time_stop;
  struct rusage	rusage;

  getrusage(RUSAGE_SELF, &rusage);
  time_start = (double)(rusage.ru_utime.tv_sec);
  time_start = time_start + (double)(rusage.ru_utime.tv_usec) * 1.0e-06;

  /* Initialize the hardware clock cycle counter. */
  unsigned long long int cycle_start, cycle_stop;
  __asm__ volatile ("RDTSC" : "=A" (cycle_start));


  /* Original iterators. */
  int i, j ;
  /* Parameters. */
  int M=PARVAL1, total=0 ;

  for (i=0;i<=M;i++) {
    S1(i) ;
    S2(i) ;
    for (j=0;j<=M;j++) {
      S3(i,j) ;
      S4(i,j) ;
    }
  }


  /* stop the hardware clock cycle counter. */
   __asm__ volatile ("RDTSC" : "=A" (cycle_stop));

  /* Print the cycle count of the kernel. */
  printf("Cycles: %llu\n", cycle_stop - cycle_start);

  getrusage(RUSAGE_SELF, &rusage);
  time_stop = (double)(rusage.ru_utime.tv_sec);
  time_stop = time_stop + (double)(rusage.ru_utime.tv_usec) * 1.0e-06;

  /* Print the time taken by the kernel. */
  printf("Time:   %fs\n", time_stop - time_start);

  
char end_line = 10;
char buf[512];
strcpy(buf, argv[0]);
strcat(buf, ".output");
FILE* o_file = fopen(buf, "w");
for (iarray = 0; iarray <= PARVAL1; ++iarray) {
   fprintf(o_file, FLOAT_MODIFIER, x1[iarray]);
}
fprintf(o_file, "%c", end_line);
for (iarray = 0; iarray <= PARVAL1; ++iarray) {
   fprintf(o_file, FLOAT_MODIFIER, x2[iarray]);
}
fprintf(o_file, "%c", end_line);
fclose(o_file);
#ifdef test_malloc
for (iarray = 0; iarray <= PARVAL1; ++iarray)
   free(a[iarray]);
free(a);
free(x1);
free(x2);
free(y1);
free(y2);
#endif

  return 0 ;
}
