#!/bin/sh
# checker.sh: this file is part of the LetSee project.
# 
# LetSee, the LEgal Transformation SpacE Explorator.
# 
# Copyright (C) 2006 Louis-Noel Pouchet
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
# 
# The complete GNU General Public Licence Notice can be found as the
# `COPYING' file in the root directory.
# 
# Author:
# Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
# 

echo "A sample test suite... running matmult"

cd .. && ./src/scripts/tester2.sh -1 1 -1 1 -1 1  "gcc -O3 -DPARVAL1=64 -Dtest_malloc" ./tests/battery/matmult.candl

exit 0
