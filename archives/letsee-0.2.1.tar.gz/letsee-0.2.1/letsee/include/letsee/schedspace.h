/*
 * schedspace.h: this file is part of the LetSee project.
 *
 * LetSee, the LEgal Transformation SpacE Explorator.
 *
 * Copyright (C) 2006 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * The complete GNU General Public Licence Notice can be found as the
 * `COPYING' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */
#ifndef LETSEE_SCHEDSPACE_H
# define LETSEE_SCHEDSPACE_H

# include <letsee/common.h>
# include <letsee/options.h>
# include <letsee/space.h>
# include <letsee/transformations.h>
# include <letsee/farkas.h>
# include <letsee/graph.h>
# include <letsee/dependence.h>
# include <fm/piptools.h>
# include <fm/solution.h>
# include <fm/system.h>
# include <fm/solver.h>
# include <fm/compsol.h>
# include <candl/candl.h>



BEGIN_C_DECLS

extern
void
ls_schedspace_optimize_space (CandlProgram* program,
			      s_ls_options_t* options,
			      s_ls_space_t* space);

extern
CandlDependence*
ls_schedspace_depgraph_preprocess (CandlProgram* program,
				   CandlDependence* dependences);

extern
s_ls_space_t*
ls_schedspace_build (CandlProgram* program,
		     CandlDependence* dependences,
		     s_ls_options_t* options);

END_C_DECLS


#endif // LETSEE_SCHEDSPACE_H
