/*
 * heuristic-m1.h: this file is part of the LetSee project.
 *
 * LetSee, the LEgal Transformation SpacE Explorator.
 *
 * Copyright (C) 2006,2007,2008 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * The complete GNU General Public Licence Notice can be found as the
 * `COPYING' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */
#ifndef LETSEE_HEURISTIC_M1_H
# define LETSEE_HEURISTIC_M1_H

# include <letsee/heuristics.h>
# include <letsee/space.h>
# include <letsee/options.h>
# include <candl/program.h>
# include <fm/list.h>

BEGIN_C_DECLS

extern
void
ls_heuristic_m1 (s_ls_space_t* space,
		 CandlProgram* program,
		 s_ls_options_t* options);


END_C_DECLS


#endif // LETSEE_HEURISTIC_M1_H
