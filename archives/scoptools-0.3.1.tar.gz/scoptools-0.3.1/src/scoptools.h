/*
 * project.h: this file is part of the ScopTools project.
 * 
 * ScopTools, a set of convenience functions to translate to/from ScopLib.
 * 
 * Copyright (C) 2010 Louis-Noel Pouchet
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 * 
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 * 
 * Author:
 * Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 */
#ifndef SCOPTOOLS_SCOPTOOLS_H
# define SCOPTOOLS_SCOPTOOLS_H


#endif // SCOPTOOLS_SCOPTOOLS_H
