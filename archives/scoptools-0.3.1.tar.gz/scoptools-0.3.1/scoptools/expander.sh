# ! /bin/sh

if [ -f "$1" ]; then
    gcc -E -P -CC "$1" | sed -e 's/;;/;/g' | grep -v "pragma omp" | grep -v "pragma iv" | grep -v "pragma simd" > .tmp.2.c
    mv .tmp.2.c "$1";
fi;
