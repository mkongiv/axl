/*
 * intops.c: this file is part of the FM project.
 *
 * FM, a fast and optimized C implementation of Fourier-Motzkin
 * projection algorithm.
 *
 * Copyright (C) 2006 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * The complete GNU General Public Licence Notice can be found as the
 * `COPYING' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */
#if HAVE_CONFIG_H
# include <fm/config.h>
#endif

#include <fm/common.h>
#include <fm/intops.h>


static int fm_has_z_gmp_zero = 0;
static int fm_has_z_gmp_one = 0;
static int fm_has_z_gmp_mone = 0;

static z_type_t fm_z_zero_val;
static z_type_t fm_z_one_val;
static z_type_t fm_z_mone_val;


#ifndef FM_FASTINT64_MODE

const
z_type_t z_zero()
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    {
      fm_z_zero_val.llint = 0;
      return fm_z_zero_val;
    }
#ifdef FM_HAS_GMP_SUPPORT
  else
    {
      if (fm_has_z_gmp_zero == 0)
	{
	  fm_has_z_gmp_zero = 1;
	  mpz_init(fm_z_zero_val.gmpint);
	  mpz_set_si(fm_z_zero_val.gmpint, 0);
	}
      return fm_z_zero_val;
    }
#endif
}


const
z_type_t z_one()
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    {
      fm_z_one_val.llint = 1;
      return fm_z_one_val;
    }
#ifdef FM_HAS_GMP_SUPPORT
  else
    {
      if (fm_has_z_gmp_one == 0)
	{
	  fm_has_z_gmp_one = 1;
	  mpz_init(fm_z_one_val.gmpint);
	  mpz_set_si(fm_z_one_val.gmpint, 1);
	}
      return fm_z_one_val;
    }
#endif
}


const
z_type_t z_mone()
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    {
      fm_z_mone_val.llint = -1;
      return fm_z_mone_val;
    }
#ifdef FM_HAS_GMP_SUPPORT
  else
    {
      if (fm_has_z_gmp_mone == 0)
	{
	  fm_has_z_gmp_mone = 1;
	  mpz_init(fm_z_mone_val.gmpint);
	  mpz_set_si(fm_z_mone_val.gmpint, -1);
	}
      return fm_z_mone_val;
    }
#endif
}



void z_init(z_type_t* vu)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = 0;
#ifdef FM_HAS_GMP_SUPPORT
  else
    {
      mpz_init (vu->gmpint);
      mpz_set_si (vu->gmpint, 0);
    }
#endif
}



void z_clear(z_type_t* v1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    {
    }
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_clear (v1->gmpint);
#endif
}



fm_llint_t z_get_si(z_type_t* vu)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    return vu->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    return mpz_get_si(vu->gmpint);
#endif
}



void z_assign(z_type_t* vu, z_type_t* vu1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_set(vu->gmpint, vu1->gmpint);
#endif
}



void z_assign_si(z_type_t* vu, long long int v1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = v1;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_set_si(vu->gmpint, v1);
#endif
}



int z_cmp_si(z_type_t* vu, long long int v1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    return vu->llint - v1;
#ifdef FM_HAS_GMP_SUPPORT
  else
    return mpz_cmp_si(vu->gmpint, v1);
#endif
}



int z_cmp(z_type_t* vu, z_type_t* vu1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    {
      if (vu->llint == vu1->llint)
	return 0;
      else if (vu->llint < vu1->llint)
	return -1;
      else
	return 1;
    }
#ifdef FM_HAS_GMP_SUPPORT
  else
    return mpz_cmp(vu->gmpint, vu1->gmpint);
#endif
}


void z_print(FILE* f, char* mod, z_type_t* vu)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    fprintf(f, Z_STRING_MODIFIER, vu->llint);
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_out_str (f, 10, vu->gmpint);
#endif
}




void z_inc(z_type_t* vu, z_type_t* vu1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint + 1;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_add_ui (vu->gmpint, vu1->gmpint, 1);
#endif
}



void z_dec(z_type_t* vu, z_type_t* vu1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint - 1;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_sub_ui (vu->gmpint, vu1->gmpint, 1);
#endif
}



void z_abs(z_type_t* vu, z_type_t* vu1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    {
      if (vu1->llint >= 0)
	vu->llint = vu1->llint;
      else
	vu->llint = - vu1->llint;
    }
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_abs (vu->gmpint, vu1->gmpint);
#endif
}



void z_opp(z_type_t* vu, z_type_t* vu1)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = -vu1->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_neg (vu->gmpint, vu1->gmpint);
#endif
}



void z_add(z_type_t* vu, z_type_t* vu1, z_type_t* vu2)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint + vu2->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_add (vu->gmpint, vu1->gmpint, vu2->gmpint);
#endif
}



void z_sub(z_type_t* vu, z_type_t* vu1, z_type_t* vu2)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint - vu2->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_sub (vu->gmpint, vu1->gmpint, vu2->gmpint);
#endif
}



void z_mul(z_type_t* vu, z_type_t* vu1, z_type_t* vu2)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint * vu2->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_mul (vu->gmpint, vu1->gmpint, vu2->gmpint);
#endif
}



void z_div(z_type_t* vu, z_type_t* vu1, z_type_t* vu2)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint / vu2->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_div (vu->gmpint, vu1->gmpint, vu2->gmpint);
#endif
}



void z_mod(z_type_t* vu, z_type_t* vu1, z_type_t* vu2)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    vu->llint = vu1->llint % vu2->llint;
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_mod (vu->gmpint, vu1->gmpint, vu2->gmpint);
#endif
}




void z_gcd(z_type_t* vu, z_type_t* vu1, z_type_t* vu2)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    *vu = fm_z_gcd(*vu1, *vu2);
#ifdef FM_HAS_GMP_SUPPORT
  else
    mpz_gcd (vu->gmpint, vu1->gmpint, vu2->gmpint);
#endif
}



void z_lcm(z_type_t* vu, z_type_t* vu1, z_type_t* vu2)
{
  if (g_fm_integer_mode == FM_INTEGER_MODE_LLINT)
    *vu = fm_z_lcm(*vu1, *vu2);
#ifdef FM_HAS_GMP_SUPPORT
  else
    {
      fm_gmpint_t r1; mpz_init(r1);
      mpz_mul(r1, vu1->gmpint, vu2->gmpint);
      mpz_gcd (vu->gmpint, vu1->gmpint, vu2->gmpint);
      mpz_div(vu->gmpint, r1, vu->gmpint);
      mpz_clear(r1);
    }
#endif
}

#endif
