/*
 * intops_ops.h: this file is part of the FM project.
 *
 * FM, a fast and optimized C implementation of Fourier-Motzkin
 * projection algorithm.
 *
 * Copyright (C) 2006-2008 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 *  as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */


#ifndef FM_INTOPS_OPS_H
# define FM_INTOPS_OPS_H

# include <stdlib.h>
# include <fm/common.h>
# include <fm/mode.h>


# ifndef FM_FASTINT64_MODE
BEGIN_C_DECLS

extern
const
z_type_t z_zero();

extern
const
z_type_t z_one();

extern
const
z_type_t z_mone();

extern
void z_init(z_type_t* vu);

extern
void z_clear(z_type_t* v1);

extern
fm_llint_t z_get_si(z_type_t* vu);

extern
void z_assign(z_type_t* vu, z_type_t* vu1);

extern
void z_assign_si(z_type_t* vu, long long int v1);

extern
int z_cmp_si(z_type_t* vu, long long int v1);

extern
int z_cmp(z_type_t* vu, z_type_t* vu1);

extern
void z_print(FILE* f, char* mod, z_type_t* vu);

extern
void z_inc(z_type_t* vu, z_type_t* vu1);

extern
void z_dec(z_type_t* vu, z_type_t* vu1);

extern
void z_abs(z_type_t* vu, z_type_t* vu1);

extern
void z_opp(z_type_t* vu, z_type_t* vu1);

extern
void z_add(z_type_t* vu, z_type_t* vu1, z_type_t* vu2);

extern
void z_sub(z_type_t* vu, z_type_t* vu1, z_type_t* vu2);

extern
void z_mul(z_type_t* vu, z_type_t* vu1, z_type_t* vu2);

extern
void z_div(z_type_t* vu, z_type_t* vu1, z_type_t* vu2);

extern
void z_mod(z_type_t* vu, z_type_t* vu1, z_type_t* vu2);

extern
z_type_t fm_z_gcd(z_type_t, z_type_t);

extern
z_type_t fm_z_lcm(z_type_t, z_type_t);

extern
void z_gcd(z_type_t* vu, z_type_t* vu1, z_type_t* vu2);

extern
void z_lcm(z_type_t* vu, z_type_t* vu1, z_type_t* vu2);

END_C_DECLS
#endif


#endif // FM_INTOPS_OPS_H
