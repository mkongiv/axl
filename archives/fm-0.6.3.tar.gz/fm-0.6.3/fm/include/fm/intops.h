/*
 * intops.h: this file is part of the FM project.
 *
 * FM, a fast and optimized C implementation of Fourier-Motzkin
 * projection algorithm.
 *
 * Copyright (C) 2006-2008 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 *  as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */


#ifndef FM_INTOPS_H
# define FM_INTOPS_H

# include <stdlib.h>
# include <fm/common.h>
# include <fm/mode.h>


/**
 * Compile with -DFM_FASTINT64_MODE if and only if the library was
 * built with option --enable-fm-fastint64. If that is the case, then
 * the integer type is a flat long long int. This is the 'legacy' fast
 * integer mode in FM (all versions of FM prior to 0.6.0).
 *
 * In all other cases, the integer type will be a union, and all
 * arithmetic function will be dispatched to methods of intops.c.
 *
 */

/**
 * Functions offered:
 *
 *  Z_INIT(val)			initialize a value.
 *  Z_CLEAR(val)		free memory used by a value.
 *  Z_ASSIGN(val1,val2)		val1 = val2
 *  Z_ASSIGN_SI(val1,intval)	val1 = intval
 *  int = Z_GET_SI(val)		get the llint associated with val
 *  Z_ZERO			the constant '0'
 *  Z_ONE			the constant '1'
 *  Z_MONE			the constant '-1'
 *  Z_OPP(val1,val2)		val1 = -val2
 *  Z_INC(val)			val = val + 1
 *  Z_DEC(val)			val = val - 1
 *  Z_ADD(val1,val2,val3)      	val1 = val2 + val3
 *  Z_SUB(val1,val2,val3)      	val1 = val2 - val3
 *  Z_MUL(val1,val2,val3)      	val1 = val2 * val3
 *  Z_DIV(val1,val2,val3)      	val1 = val2 / val3
 *  Z_MOD(val1,val2,val3)      	val1 = val2 % val3
 *
 *  Z_CMP(val1,op,val2)      	(val1 op val2)
 *  Z_CMP_SI(val,op,intval)     (val  op intval)
 *
 *
 */

typedef long long int fm_llint_t;

# ifndef FM_FASTINT64_MODE
// Dispatched int's w/ gmp enabled:
#  ifdef FM_HAS_GMP_SUPPORT
#   include <gmp.h>
typedef mpz_t fm_gmpint_t;
union u_z_type {
  fm_llint_t	llint;
  fm_gmpint_t  	gmpint;
};
typedef union u_z_type z_type_t;
#   else
// Dispatched int's w/o gmp enabled:
union u_z_type {
  fm_llint_t	llint;
};
typedef union u_z_type z_type_t;
#   endif
#  else
// Legacy (fast) int's:
typedef fm_llint_t z_type_t;
#  endif

# define Z_STRING_MODIFIER "%lld"
# define Z_STRING_MODIFIER_SSCANF "%Ld"

# ifndef FM_FASTINT64_MODE
#  define Z_ZERO (z_zero())
#  define Z_ONE (z_one())
#  define Z_MONE (z_mone())
#  define Z_INIT(v) z_init(&(v))
#  define Z_CLEAR(v) z_clear(&(v))
#  define Z_GET_SI(v) z_get_si(&(v))
#  define Z_ASSIGN(v, v1) z_assign(&(v), &(v1))
#  define Z_ASSIGN_SI(v, v1) z_assign_si(&(v), v1)
#  define Z_CMP_SI(v, op, v1) (z_cmp_si(&(v), v1) op 0)
#  define Z_CMP(v, op, v1) (z_cmp(&(v), &(v1)) op 0)
#  define Z_PRINT(out, v) z_print(out, Z_STRING_MODIFIER, &(v))
#  define Z_INC(v, v1) z_inc(&(v), &(v1))
#  define Z_DEC(v, v1) z_dec(&(v), &(v1))
#  define Z_ABS(v, v1) z_abs(&(v), &(v1))
#  define Z_OPP(v, v1) z_opp(&(v), &(v1))
#  define Z_ADD(v, v1, v2) z_add(&(v), &(v1), &(v2))
#  define Z_SUB(v, v1, v2) z_sub(&(v), &(v1), &(v2))
#  define Z_MUL(v, v1, v2) z_mul(&(v), &(v1), &(v2))
#  define Z_DIV(v, v1, v2) z_div(&(v), &(v1), &(v2))
#  define Z_MOD(v, v1, v2) z_mod(&(v), &(v1), &(v2))
#  define Z_GCD(v, v1, v2) z_gcd(&(v), &(v1), &(v2))
#  define Z_LCM(v, v1, v2) z_lcm(&(v), &(v1), &(v2))
# else
#  define Z_ZERO ( 0 )
#  define Z_ONE ( 1 )
#  define Z_MONE ( -1 )
#  define Z_INIT(v1) ( v1 = 0 )
#  define Z_CLEAR(v1)
#  define Z_GET_SI(v) ( v )
#  define Z_ASSIGN(v, v1) ( v = v1 )
#  define Z_ASSIGN_SI(v, val) ( v = val )
#  define Z_CMP_SI(v1, op, v2) (v1 op v2)
#  define Z_CMP(v1, op, v2) (v1 op v2)
#  define Z_PRINT(out, v) fprintf(out, Z_STRING_MODIFIER, v)
#  define Z_INC(v, v1) ((v = v1 + 1))
#  define Z_DEC(v, v1) ((v = v1 - 1))
#  define Z_ABS(v, v1) ( v = v1 > 0 ? v1 : -v1 )
#  define Z_OPP(v, v1) ((v = -v1))
#  define Z_ADD(v, v1, v2) ( v = v1 + v2 )
#  define Z_SUB(v, v1, v2) ( v = v1 - v2 )
#  define Z_MUL(v, v1, v2) ( v = v1 * v2 )
#  define Z_DIV(v, v1, v2) ( v = v1 / v2 )
#  define Z_MOD(v, v1, v2) ( v = v1 % v2 )
#  define Z_GCD(v, v1, v2) ( v = fm_z_gcd(v1, v2) )
#  define Z_LCM(v, v1, v2) ( v = fm_z_lcm(v1, v2) )
# endif

# ifndef FM_INTOPS_INLINE_H
#  include <fm/intops_ops.h>
# endif

#endif // FM_INTOPS_H
