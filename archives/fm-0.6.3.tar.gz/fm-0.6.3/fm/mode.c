/*
 * mode.c: this file is part of the FM project.
 *
 * FM, a fast and optimized C implementation of Fourier-Motzkin
 * projection algorithm.
 *
 * Copyright (C) 2006-2013 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 *  as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */
#if HAVE_CONFIG_H
# include <fm/config.h>
#endif

#include <assert.h>
#include <fm/common.h>
#include <fm/mode.h>


int g_fm_integer_mode = 0;

void
fm_mode_set_to_gmp ()
{
#ifndef FM_HAS_GMP_SUPPORT
  fprintf (stderr, "[FM][ERROR] FM was not built with GMP support\n");
  assert (0);
  exit (1);
#endif

#ifdef FM_FASTINT64_MODE
  fprintf (stderr, "[FM][ERROR] FM was built exclusively for int 64bits\n");
  assert (0);
  exit (1);
#endif

  g_fm_integer_mode = FM_INTEGER_MODE_GMP;
}


void
fm_mode_set_to_llint ()
{
  g_fm_integer_mode = FM_INTEGER_MODE_LLINT;
#ifdef FM_FASTINT64_MODE
  fprintf (stderr, "[FM][WARNING] FM was built exclusively for int 64bits\n");
  fprintf (stderr, "[FM][WARNING] function fm_mode_set_to_llint() has no effect\n");
#endif
}
