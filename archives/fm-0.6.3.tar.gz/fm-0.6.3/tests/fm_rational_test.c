/*
 * fm_rational_test.c: this file is part of the FM project.
 *
 * FM, a fast and optimized C implementation of Fourier-Motzkin
 * projection algorithm.
 *
 * Copyright (C) 2006-2008 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 *  as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */
#if HAVE_CONFIG_H
# include <fm/config.h>
#endif

#include <stdio.h>
#include <fm/common.h>
#include <fm/rational.h>


int
main ()
{
  fprintf(stderr, "=> Testing rational class\n");
  fprintf(stderr, "* Allocation tests\n");
  s_fm_rational_t* r1 = fm_rational_alloc ();
  if (Z_CMP_SI(r1->num, !=, 0) || Z_CMP_SI(r1->denum, !=, 1))
    return 1;
  z_type_t val1; Z_INIT(val1);
  z_type_t val2; Z_INIT(val2);
  Z_ASSIGN_SI(val1, 1);
  Z_ASSIGN_SI(val2, 0);
  fprintf(stderr, "* Assignation tests\n");
#ifdef NDEBUG
  if (fm_rational_assign (r1, val1, val2) != 1)
    return 1;
#endif

  Z_ASSIGN_SI(val1, -1);
  Z_ASSIGN_SI(val2, 2);
  fm_rational_assign (r1, val1, val2);
  if (Z_CMP_SI(r1->num, !=, -1) || Z_CMP_SI(r1->denum, !=, 2))
    return 1;

  Z_ASSIGN_SI(val1, -1);
  Z_ASSIGN_SI(val2, -2);
  fm_rational_assign (r1, val1, val2);
  if (Z_CMP_SI(r1->num, !=, 1) || Z_CMP_SI(r1->denum, !=, 2))
    return 1;

  Z_ASSIGN_SI(val1, 1);
  Z_ASSIGN_SI(val2, -2);
  fm_rational_assign (r1, val1, val2);
  if (Z_CMP_SI(r1->num, !=, -1) || Z_CMP_SI(r1->denum, !=, 2))
    return 1;

  fprintf(stderr, "* Operators tests:\n");
  s_fm_rational_t* r2 = fm_rational_alloc ();
  s_fm_rational_t* r = fm_rational_alloc ();
  Z_ASSIGN_SI(val1, 1);
  Z_ASSIGN_SI(val2, 3);
  fm_rational_assign (r2, val1, val2);

  fprintf(stderr, "** ADD tests\n");
  fm_rational_add(r, r1, r2);
  if (Z_CMP_SI(r->num, !=, -1) || Z_CMP_SI(r->denum, !=, 6))
    return 1;

  fprintf(stderr, "** SUB tests\n");
  fm_rational_sub(r, r1, r2);
  if (Z_CMP_SI(r->num, !=, -5) || Z_CMP_SI(r->denum, !=, 6))
    return 1;

  fprintf(stderr, "** MUL tests\n");
  fm_rational_mul(r, r1, r2);
  if (Z_CMP_SI(r->num, !=, -1) || Z_CMP_SI(r->denum, !=, 6))
    return 1;

  fprintf(stderr, "** DIV tests\n");
  fm_rational_div(r, r1, r2);
  if (Z_CMP_SI(r->num, !=, -3) || Z_CMP_SI(r->denum, !=, 2))
    return 1;

  fprintf(stderr, "** OPP tests\n");
  fm_rational_opp(r, r1);
  if (Z_CMP_SI(r->num, !=, 1) || Z_CMP_SI(r->denum, !=, 2))
    return 1;

  fprintf(stderr, "** EQ tests\n");
  if (! fm_rational_equal(r1, r1))
    return 1;

  fprintf(stderr, "* Free tests\n");
  fm_rational_free (r);
  fm_rational_free (r1);
  fm_rational_free (r2);
  Z_CLEAR(val1);
  Z_CLEAR(val2);

  fprintf(stderr, "== All done for rational class.\n");

  return 0;
}
