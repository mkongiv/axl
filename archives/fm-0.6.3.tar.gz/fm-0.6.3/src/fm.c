/*
 * fm.c: this file is part of the FM project.
 *
 * FM, a fast and optimized C implementation of Fourier-Motzkin
 * projection algorithm.
 *
 * Copyright (C) 2006-2008 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 *  as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <Louis-Noel.Pouchet@inria.fr>
 *
 */
#if HAVE_CONFIG_H
# include <config.h>
#endif

#include <fm/common.h>
#include <fm/intops.h>
#include <fm/system.h>
#include <fm/solution.h>
#include <fm/solver.h>
#include <fm/compsol.h>


void
fms_usage ()
{
  fprintf (stderr, "Usage: fm-solver input-file [output-file]\n");
  exit (1);
}

void
fms_error ()
{
  fprintf (stderr, "fm-solver: Bad input file.\n");
  exit (1);
}



int
main (int argc, char * const argv[])
{
  if (argc < 2 || argc > 3)
    fms_usage ();

  fm_mode_set_to_llint ();

  FILE* f = fopen (argv[1], "r");
  if (f == NULL)
    fms_error ();

  // Read the input system.
  s_fm_system_t* system = fm_system_read (f);
  fclose (f);

  if (f == NULL)
    fms_error ();

  s_fm_system_t* to_solve = system;
  s_fm_compsol_t* cs_tosolve = fm_compsol_init_sys (to_solve);
  fm_system_free (to_solve);
  system = fm_solution_to_system (cs_tosolve->poly);
  fm_solution_free (cs_tosolve->poly);
  cs_tosolve->poly = fm_solver (system,
				FM_SOLVER_FAST | FM_SOLVER_AUTO_SIMPLIFY);
  if (cs_tosolve->poly == NULL)
    {
      printf ("[FM][solver] Error: system infeasible\n");
      fm_compsol_free (cs_tosolve);
      return 1;
    }

  s_fm_solution_t* solution2 = fm_compsol_expand (cs_tosolve);
  fm_solution_print (stdout, solution2);
  fm_solution_free (solution2);
  fm_compsol_free (cs_tosolve);

  return 0;
  // Solve the system.
  s_fm_solution_t* solution =
    fm_solver (system, FM_SOLVER_FAST | FM_SOLVER_NORMALIZE_EQ | FM_SOLVER_VERBOSE);

  if (argc == 3)
    f = fopen (argv[2], "w");
  else
    f = fdopen (dup (fileno (stdout)), "w");

  if (f == NULL)
    fms_usage ();

  // Output the results.
  fm_solution_print (f, solution);
  fclose (f);

  // Be clean.
  fm_system_free (system);
  fm_solution_free (solution);

  return 0;
}
