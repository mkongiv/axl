
   /**------ ( ----------------------------------------------------------**
    **       )\                      CAnDL                               **
    **----- /  ) --------------------------------------------------------**
    **     ( * (                 isl-wrapper.c                           **
    **----  \#/  --------------------------------------------------------**
    **    .-"#'-.        First version: January 31st 2011                **
    **--- |"-.-"| -------------------------------------------------------**
          |     |
          |     |
 ******** |     | *************************************************************
 * CAnDL  '-._,-' the Chunky Analyzer for Dependences in Loops (experimental) *
 ******************************************************************************
 *                                                                            *
 * Copyright (C) 2003-2008 Cedric Bastoul                                     *
 *                                                                            *
 * This is free software; you can redistribute it and/or modify it under the  *
 * terms of the GNU Lesser General Public License as published by the Free    *
 * Software Foundation; either version 3 of the License, or (at your option)  *
 * any later version.                                                         *
 *                                                                            *
 * This software is distributed in the hope that it will be useful, but       *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY *
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License   *
 * for more details.                                                          *
 *                                                                            *
 * You should have received a copy of the GNU Lesser General Public License   *
 * along with software; if not, write to the Free Software Foundation, Inc.,  *
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA                     *
 *                                                                            *
 * CAnDL, the Chunky Dependence Analyzer                                      *
 * Written by Cedric Bastoul, Cedric.Bastoul@inria.fr                         *
 *                                                                            *
 ******************************************************************************/
/**
 * \file isl-wrapper.c
 * \author Sven Verdoolaege and Louis-Noel Pouchet
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <candl/candl.h>

# ifdef CANDL_SUPPORTS_ISL

# undef Q
# include <gmp.h>

# include <isl/ctx.h>
# include <isl/val.h>
# include <isl/map.h>
# include <isl/union_map.h>
# include <isl/set.h>
# include <isl/union_set.h>
# include <isl/constraint.h>
# include <isl/aff.h>
# include <isl/space.h>


/// WARNING: This is hard-coding that ISL uses GMP.


/**
 * isl_constraint_read_from_matrix:
 * Convert a single line of a matrix to a isl_constraint.
 * Returns a pointer to the constraint if successful; NULL otherwise.
 */
static
isl_constraint*
isl_constraint_read_from_matrix(isl_space* space, Entier* row)
{
  isl_constraint* constraint;
  int j;
  int nvariables = isl_space_dim (space, isl_dim_set);
  int nparam = isl_space_dim (space, isl_dim_param);
  isl_local_space* ls =
    isl_local_space_from_space (isl_space_copy(space));

  if (CANDL_get_si(row[0]) == 0)
    constraint = isl_equality_alloc (ls);
  else
    constraint = isl_inequality_alloc (ls);

  for (j = 0; j < nvariables; ++j)
    isl_constraint_set_coefficient_si (constraint, isl_dim_set,
				       j, CANDL_get_si(row[1 + j]));

  for (j = 0; j < nparam; ++j)
    isl_constraint_set_coefficient_si (constraint, isl_dim_param, j,
				       CANDL_get_si(row[1 + nvariables + j]));

  isl_constraint_set_constant_si (constraint,
				  CANDL_get_si(row[1 + nvariables + nparam]));

  return constraint;
}


isl_set*
isl_set_from_piplib_matrix(isl_ctx* ctx,
			   PipMatrix* matrix,
			   int nparam)
{
  isl_basic_set* bset;
  int i;
  unsigned nrows, ncolumns;

  nrows = matrix->NbRows;
  ncolumns = matrix->NbColumns;
  int nvariables = ncolumns - 2 - nparam;

  isl_space* space = isl_space_set_alloc (ctx, nparam, nvariables);

  bset = isl_basic_set_universe (isl_space_copy(space));

  for (i = 0; i < nrows; ++i) {
    Entier* row = matrix->p[i];
    isl_constraint* constraint =
      isl_constraint_read_from_matrix (space, row);
    bset = isl_basic_set_add_constraint (bset, constraint);
  }

  isl_set* ret = isl_set_from_basic_set (isl_basic_set_copy (bset));
  isl_basic_set_free (bset);

  return ret;
}


static
int count_cst(__isl_take isl_constraint *c, void *user)
{
  (*((int*)user))++;

  return 0;
}



static
int copy_cst_to_mat(__isl_take isl_constraint *c, void *user)
{
  // 1- Get the first free row of the matrix.
  int pos;
  PipMatrix* mat = (PipMatrix*)user;
  for (pos = 0; pos < mat->NbRows &&
	 CANDL_get_si(mat->p[pos][0]) != -1; ++pos)
    ;

  // 2- Set the eq/ineq bit.
  if (isl_constraint_is_equality (c))
    CANDL_set_si(mat->p[pos][0], 0);
  else
    CANDL_set_si(mat->p[pos][0], 1);

  // 3- Set all coefficients.
  isl_ctx* ctxt = isl_ctx_alloc ();
  isl_val* val;
  int j;
  int nb_vars = isl_local_space_dim (isl_constraint_get_local_space (c),
				     isl_dim_set);
  for (j = 0; j < nb_vars; ++j)
    {
      val = isl_constraint_get_coefficient_val (c, isl_dim_set, j);
      CANDL_set_si(mat->p[pos][j + 1], isl_val_get_num_si(val));
      if (isl_val_get_den_si(val) != 1)
	{
	  fprintf (stderr, "[Candl][ERROR] Denominator of isl_val is not 1\n");
	  assert (0);
	}
    }
  int nb_param = isl_local_space_dim (isl_constraint_get_local_space(c),
				     isl_dim_param);
  for (j = 0; j < nb_param; ++j)
    {
      val = isl_constraint_get_coefficient_val (c, isl_dim_param, j);
      CANDL_set_si(mat->p[pos][j + nb_vars + 1], isl_val_get_num_si (val));
      if (isl_val_get_den_si(val) != 1)
	{
	  fprintf (stderr, "[Candl][ERROR] Denominator of isl_val is not 1\n");
	  assert (0);
	}
    }
  val = isl_constraint_get_constant_val (c);
  CANDL_set_si(mat->p[pos][mat->NbColumns - 1], isl_val_get_num_si (val));
  if (isl_val_get_den_si(val) != 1)
    {
      fprintf (stderr, "[Candl][ERROR] Denominator of isl_val is not 1\n");
      assert (0);
    }

  isl_ctx_free (ctxt);

  return 0;
}


int bset_get(__isl_take isl_basic_set *bset, void *user)
{
  *((struct isl_basic_set**)user) = bset;

  return 0;
}


PipMatrix*
isl_set_to_piplib_matrix(struct isl_ctx* ctx,
			 struct isl_set* set,
			 int nparam)
{
  struct isl_basic_set* bset = NULL;
  // There is only one basic set in this set.
  isl_set_foreach_basic_set (set, bset_get, &bset);
  if (bset == NULL)
    return NULL;

  // 1- Count the number of eq/ineq.
  int count = 0;
  isl_basic_set_foreach_constraint (bset, count_cst, &count);

  // 2- Count the dimensions.
  int nb_vars = isl_space_dim (isl_basic_set_get_space (bset), isl_dim_set);

  // 3- Allocate output matrix, and prepare it.
  PipMatrix* res = pip_matrix_alloc (count, nb_vars + nparam + 2);
  int i;
  for (i = 0; i < count; ++i)
    CANDL_set_si(res->p[i][0], -1);

  // 4- Convert each constraint to a row of the matrix.
  isl_basic_set_foreach_constraint (bset, copy_cst_to_mat, res);

  return res;
}


#endif
