#! /bin/sh


./checker.sh "CAnDL test suite" "$TEST_FILES"
