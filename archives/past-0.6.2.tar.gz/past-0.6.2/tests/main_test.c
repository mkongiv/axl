/* 
 * main_test.c: This file is part of the PAST project.
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <past/symbols.h>
#include <past/past.h>
#include <past/past_api.h>
#include <past/pprint.h>

void tester (s_past_node_t* root)
{
  printf ("[TESTER] Starting tests.\n");
  // Consistency check.
  int num_errors = past_consistency_check (root, 1);
  printf ("[CHECK] Number of consistency errors in base tree: %d\n",
	  num_errors);

  // Pretty-print.
  printf ("[CHECK] Print original tree\n");
  past_pprint (stdout, root);

  // Clone.
  s_past_node_t* cloned = past_clone (root);

  // Consistency check.
  num_errors = past_consistency_check (cloned, 1);
  printf ("[CHECK] Number of consistency errors in cloned tree: %d\n",
	  num_errors);

  // pprint clone.
  printf ("[CHECK] Print cloned tree\n");
  past_pprint (stdout, cloned);

  if (past_tree_are_equal (root, cloned))
    printf ("[OK] original and clone are equal\n");
  else
    printf ("[ERROR] original and clone are not equal\n");

  printf ("[CHECK] Free the full tree (deep-free)\n");
  past_deep_free (root);
  num_errors = past_consistency_check (cloned, 1);
  printf ("[CHECK] Number of consistency errors in cloned tree after free: %d\n",
	  num_errors);
  past_deep_free (cloned);
  printf ("[TESTER] All done.\n");
}

/// Some globals used across tests.
s_symbol_table_t* symtable;

// symbols to be used:
s_symbol_t* i;
s_symbol_t* j;
s_symbol_t* k;
s_symbol_t* A;
s_symbol_t* B;
s_symbol_t* C;
s_symbol_t* N;
s_symbol_t* M;
s_symbol_t* typeint;

// Constants to be used.
s_past_node_t* mone;
s_past_node_t* zero;
s_past_node_t* one;


s_past_node_t* test1(s_symbol_table_t* symt) {

  // build a simple vector-add code:
  /* for (i = 0; i < N; ++i) */
  /*   A[i] += B[i]; */

  // Build B[i]
  s_past_node_t* arrefB =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (B),
			     past_node_varref_create (i));
  // Build A[i]
  s_past_node_t* arrefA =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (A),
			     past_node_varref_create (i));

  // Build A[i] += B[i];
  s_past_node_t* stmt =
    past_node_statement_create
    (past_node_binary_create (past_addassign, arrefA, arrefB));

  // Build ++i
  s_past_node_t* inc =
    past_node_unary_create (past_inc_before,
			    past_node_varref_create (i));

  // Build i < N
  s_past_node_t* test =
    past_node_binary_create (past_lt,
			     past_node_varref_create (i),
			     past_node_varref_create (N));

  // Build i = 0
  s_past_node_t* init =
    past_node_binary_create (past_assign,
			     past_node_varref_create (i),
			     past_clone (zero));

  // Build program, encapsulate things in basic blocks.
  s_past_node_t* forloop =
    past_node_for_create (init, test, i,
			  inc, past_node_block_create (stmt));
  s_past_node_t* prog =
    past_node_block_create (forloop);
  s_past_node_t* root = past_node_root_create (symt, prog);

  return root;
}


s_past_node_t* test2(s_symbol_table_t* symt) {
  // Build:
  /* int i = 0; */
  /* int j = *(&(i)); */


  // build int
  s_past_node_t* tint = past_node_varref_create (typeint);
  // encapsulate in a 'type' node, for added semantics.
  tint = past_node_type_create (tint);

  // build i
  s_past_node_t* iref = past_node_varref_create (i);

  // build int i = 0;
  s_past_node_t* vard =
    past_node_vardecl_create (tint, iref);
  vard = past_node_binary_create (past_assign, vard, past_clone (zero));
  s_past_node_t* stmt = past_node_statement_create (vard);

  // Build int j = *(&i);
  s_past_node_t* init =
    past_node_unary_create (past_addressof, past_node_varref_create (i));
  init = past_node_unary_create (past_derefof, init);
  s_past_node_t* vard2 =
    past_node_vardecl_create (past_clone (tint),
			      past_node_varref_create (j));
  vard2 = past_node_binary_create (past_assign, vard2, init);
  s_past_node_t* stmt2 = past_node_statement_create (vard2);
  past_append_last (stmt, stmt2);
  s_past_node_t* bb = past_node_block_create (stmt);
  s_past_node_t* root = past_node_root_create (symt, bb);

  return root;
}

s_past_node_t* test3(s_symbol_table_t* symt) {
  // build a simple vector-add code with declaration:
  /* for (int i = 0; i < N; ++i) */
  /*   A[i] += B[i]; */

  // Build B[i]
  s_past_node_t* arrefB =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (B),
			     past_node_varref_create (i));
  // Build A[i]
  s_past_node_t* arrefA =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (A),
			     past_node_varref_create (i));

  // Build A[i] += B[i];
  s_past_node_t* stmt =
    past_node_statement_create
    (past_node_binary_create (past_addassign, arrefA, arrefB));

  // Build ++i
  s_past_node_t* inc =
    past_node_unary_create (past_inc_before,
			    past_node_varref_create (i));

  // Build i < N
  s_past_node_t* test =
    past_node_binary_create (past_lt,
			     past_node_varref_create (i),
			     past_node_varref_create (N));

  // Build int i = 0
  s_past_node_t* init =
    past_node_binary_create (past_assign,
			     past_node_vardecl_create
			     (past_node_type_create
			      (past_node_varref_create (typeint)),
			      past_node_varref_create (i)),
			     past_clone (zero));

  // Build program, encapsulate things in basic blocks.
  s_past_node_t* forloop =
    past_node_for_create (init, test, i,
			  inc, past_node_block_create (stmt));
  s_past_node_t* prog =
    past_node_block_create (forloop);
  s_past_node_t* root = past_node_root_create (symt, prog);

  return root;
}


s_past_node_t* test4(s_symbol_table_t* symt) {
  // build a simple matrix-add code with declaration:
  /* for (int i = 0; i < N; ++i) */
  /*   for (int j = 0; j < M; ++j) */
  /*     A[i][j] += B[i][j]; */

  // Build B[i][j];
  s_past_node_t* arrefB =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (B),
			     past_node_varref_create (i));
  arrefB = past_node_binary_create (past_arrayref,
				    arrefB,
				    past_node_varref_create (j));
  // Build A[i][j]
  s_past_node_t* arrefA =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (A),
			     past_node_varref_create (i));
  arrefA = past_node_binary_create (past_arrayref,
				    arrefA,
				    past_node_varref_create (j));

  // Build A[i][j] += B[i][j];
  s_past_node_t* stmt =
    past_node_statement_create
    (past_node_binary_create (past_addassign, arrefA, arrefB));

  // Build ++i
  s_past_node_t* inci =
    past_node_unary_create (past_inc_before,
			    past_node_varref_create (i));
  // Build ++j
  s_past_node_t* incj =
    past_node_unary_create (past_inc_before,
			    past_node_varref_create (j));

  // Build i < N
  s_past_node_t* testi =
    past_node_binary_create (past_lt,
			     past_node_varref_create (i),
			     past_node_varref_create (N));
  // Build j < M
  s_past_node_t* testj =
    past_node_binary_create (past_lt,
			     past_node_varref_create (j),
			     past_node_varref_create (M));

  // Build int i = 0
  s_past_node_t* tint =
    past_node_type_create (past_node_varref_create (typeint));
  s_past_node_t* initi =
    past_node_binary_create (past_assign,
			     past_node_vardecl_create
			     (tint, past_node_varref_create (i)),
			     past_clone (zero));

  // Build int j = 0
  s_past_node_t* initj =
    past_node_binary_create (past_assign,
			     past_node_vardecl_create
			     (past_clone (tint),
			      past_node_varref_create (j)),
			     past_clone (zero));

  // Build program, encapsulate things in basic blocks.
  s_past_node_t* forloopj =
    past_node_for_create (initj, testj, j,
			  incj, past_node_block_create (stmt));
  s_past_node_t* forloopi =
    past_node_for_create (initi, testi, i,
			  inci, past_node_block_create (forloopj));

  s_past_node_t* prog =
    past_node_block_create (forloopi);
  s_past_node_t* root = past_node_root_create (symt, prog);

  return root;
}


s_past_node_t* test5(s_symbol_table_t* symt) {
  // Build:
  /* A* a = (A*) new B(); */
  /* int i = a->b; */
  /* a->c = a->d() + a->e(2*i); */

  // build type A*
  s_past_node_t* tA = past_node_varref_create (A);
  tA = past_node_unary_create (past_pointertype, tA);
  tA = past_node_type_create (tA);

  // build variable ref a
  s_symbol_t* syma = symbol_add_from_char (symt, "a");
  s_past_node_t* a = past_node_varref_create (syma);

  // build function call B()
  s_past_node_t* consB =
    past_node_funcall_create (past_node_varref_create (B), NULL);

  // build function call new B() (will be pp as new (B()))
  s_symbol_t* news = symbol_add_from_char (symt, "new");
  s_past_node_t* newB =
    past_node_funcall_create (past_node_varref_create (news),
			      consB);

  // build first statement.
  s_past_node_t* stmt1 =
    past_node_statement_create
    (past_node_binary_create
     (past_assign,
      past_node_vardecl_create (tA, a),
      past_node_cast_create (past_clone (tA), newB)));

  // build int i = a->b;
  s_symbol_t* symb = symbol_add_from_char (symt, "b");
  s_past_node_t* stmt2 =
    past_node_statement_create
    (past_node_binary_create
     (past_assign,
      past_node_vardecl_create
      (past_node_type_create
       (past_node_varref_create (typeint)),
       past_node_varref_create (i)),
      past_node_unary_create
      (past_arrow,
       past_node_varref_create (symbol_add_from_char (symt, "a->b")))));

  past_append_last (stmt1, stmt2);

  // build   a->c = a->d() + a->e(2*i);
  s_symbol_t* symc = symbol_add_from_char (symt, "c");
  s_symbol_t* symd = symbol_add_from_char (symt, "d");
  s_symbol_t* syme = symbol_add_from_char (symt, "e");
  s_past_node_t* stmt3 =
    past_node_statement_create
    (past_node_binary_create
     (past_assign,
      past_node_unary_create
      (past_arrow,
       past_node_varref_create (symbol_add_from_char (symt, "a->c"))),
      past_node_binary_create
      (past_add,
       past_node_funcall_create
	(past_node_unary_create
	 (past_arrow,
	  past_node_varref_create (symbol_add_from_char (symt, "a->d"))),
	 NULL),
       past_node_funcall_create
       (past_node_unary_create
	(past_arrow, past_node_varref_create (symbol_add_from_char (symt, "a->e"))),
	past_node_binary_create
	(past_mul,
	 past_node_value_create_from_int (2),
	 past_node_varref_create (i))))));

  past_append_last (stmt1, stmt3);

  s_past_node_t* bb = past_node_block_create (stmt1);
  s_past_node_t* root = past_node_root_create (symt, bb);

  return root;
}



s_past_node_t* test6(s_symbol_table_t* symt) {
  // Build:
  /* template <class T> */
  /* class foo { */
  /*   foo(...) { } */
  /* } */

  /* void bar(int a) { */
  /*   int b = 0; */
  /* } */

  char* mystr = "\n  template <class T>\n  class foo {\n    foo(...) { }\n  }\n  ";

  s_past_node_t* gen =
    past_node_generic_create (strdup (mystr), NULL);
  s_symbol_t* symvoid = symbol_add_from_char (symt, "void");
  s_symbol_t* symbar = symbol_add_from_char (symt, "bar");
  s_symbol_t* syma = symbol_add_from_char (symt, "a");
  s_symbol_t* symb = symbol_add_from_char (symt, "b");
  s_past_node_t* mainfunc =
    past_node_fundecl_create
    (past_node_type_create
     (past_node_varref_create (symvoid)),
     past_node_varref_create (symbar),
     past_node_vardecl_create
     (past_node_type_create
      (past_node_varref_create (typeint)),
      past_node_varref_create (syma)),
     past_node_block_create
     (past_node_statement_create
     (past_node_binary_create
     (past_assign,
      past_node_vardecl_create
      (past_node_type_create
       (past_node_varref_create (typeint)),
       past_node_varref_create (symb)),
      past_node_value_create_from_int (0)))));

  past_append_last (gen, mainfunc);
  s_past_node_t* root = past_node_root_create (symt, gen);

  return root;
}



int main() {
  symtable = symbol_table_malloc ();
  i = symbol_add_from_char (symtable, "i");
  j = symbol_add_from_char (symtable, "j");
  k = symbol_add_from_char (symtable, "k");
  A = symbol_add_from_char (symtable, "A");
  B = symbol_add_from_char (symtable, "B");
  C = symbol_add_from_char (symtable, "C");
  N = symbol_add_from_char (symtable, "N");
  M = symbol_add_from_char (symtable, "M");
  typeint = symbol_add_from_char (symtable, "int");
  mone = past_node_value_create_from_int (-1);
  zero = past_node_value_create_from_int (0);
  one = past_node_value_create_from_int (1);

  // 1- Basic for loop.
  tester (test1 (symtable));

  // 2- Basic vardecl.
  tester (test2 (symtable));

  // 3- Basic for loop with vardecl
  tester (test3 (symtable));

  // 4- parfor/SIMD test.
  s_past_node_t* t3bis = test3 (symtable);
  s_past_node_t** outerfors = past_outer_loops (t3bis);
  int it;
  for (it = 0; outerfors[it]; ++it)
    past_for_to_parfor (outerfors[it]);
  XFREE(outerfors);
  tester (t3bis);

  // 5- Doubly-nested loop w/ init.
  tester (test4 (symtable));

  // 6- OMP test.
  /// BUG 1: when vardecl used for the iterator in the init clause, the
  /// variable is still collected as private.
  /// BUG 2: unclear whether it's legal to declare the paritioned
  /// iterator a la C99 for openmp loops.
  s_past_node_t* t4bis = test4 (symtable);
  outerfors = past_outer_loops (t4bis);
  for (it = 0; outerfors[it]; ++it)
    past_for_to_parfor (outerfors[it]);
  XFREE(outerfors);
  tester (t4bis);

  // 7- Object declaration and access.
  tester (test5 (symtable));

  // 8- Generic node.
  tester (test6 (symtable));

  // Be clean.
  symbol_table_free (symtable);
}
