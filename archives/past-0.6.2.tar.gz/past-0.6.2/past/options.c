/*
 * options.c: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * 
 */
#if HAVE_CONFIG_H
# include <past/config.h>
#endif

#include <past/common.h>
#include <past/past.h>
#include <past/options.h>

/**
 *
 *
 */
s_past_options_t* past_options_malloc ()
{
  s_past_options_t* ret = XMALLOC(s_past_options_t, 1);
  ret->pprint_encapsulate_arrayref = 0;
  ret->pprint_simdfunc_separation = 0;

  return ret;
}



/**
 *
 *
 */
void past_options_free (s_past_options_t* opts)
{
  if (opts)
    XFREE(opts);
}
