/*
 * xmalloc.c: This file is part of the PAST project.
 * 
 * PAST: the PoCC Abstract Syntax Tree
 * 
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * 
 */
#if HAVE_CONFIG_H
# include <past/config.h>
#endif

#include <past/common.h>
#include <past/error.h>

void *
xmalloc (size_t num)
{
  void *new = malloc (num);
  if (! new)
    past_fatal ("Memory exhausted");
  return new;
}

void *
xrealloc (void *p, size_t num)
{
  void *new;

  if (! p)
    return xmalloc (num);

  new = realloc (p, num);
  if (! new)
    past_fatal ("Memory exhausted");

  return new;
}

void *
xcalloc (size_t num, size_t size)
{
  void *new = xmalloc (num * size);
  bzero (new, num * size);
  return new;
}
