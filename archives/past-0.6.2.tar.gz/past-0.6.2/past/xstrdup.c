/*
 * xstrdup.c: This file is part of the PAST project.
 * 
 * PAST: the PoCC Abstract Syntax Tree
 * 
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * 
 */
#ifndef WITH_DMALLOC

#if HAVE_CONFIG_H
#  include <past/config.h>
#endif

#include <past/common.h>

char *
xstrdup (const char *string)
{
  return string ? strcpy (xmalloc (strlen (string) + 1), string) : NULL;
}

#endif /* !WITH_DMALLOC */
