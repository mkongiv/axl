/*
 * pprint.c: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <past/config.h>
#endif

#include <assert.h>
#include <past/common.h>
#include <past/past.h>
#include <past/symbols.h>
#include <past/pprint.h>
#include <past/past_api.h>

#define PAST_INDENT_STEP 2


/**
 * Pretty-print table for unary and binary operators.
 *
 */
struct pprint_op {
  cs_past_node_type_t* type;
  char* scalar_op;
  char* sse_op_single;
  char* sse_op_double;
  char* avx_op_single;
  char* avx_op_double;
  char* avx2_op_single;
  char* avx2_op_double;
};
// Use a global variable for the table. It is declared in past_pprint().
static struct pprint_op* g_pprint_table = NULL;

static
char* pprint_find_str_op (cs_past_node_type_t* type,
			  e_past_op_type_t op_type)
{
  int i;
  for (i = 0; g_pprint_table && g_pprint_table[i].type != NULL; ++i)
    {
      if (g_pprint_table[i].type == type)
	{
	  switch (op_type)
	    {
	      // Default to scalar.
	    case e_past_unknown_op_type:
	    case e_past_scalar_op_type:
	      return g_pprint_table[i].scalar_op;
	    case e_past_sse_single_op_type:
	      return g_pprint_table[i].sse_op_single;
	    case e_past_sse_double_op_type:
	      return g_pprint_table[i].sse_op_double;
	    case e_past_avx_single_op_type:
	      return g_pprint_table[i].avx_op_single;
	    case e_past_avx_double_op_type:
	      return g_pprint_table[i].avx_op_double;
	    case e_past_avx2_single_op_type:
	      return g_pprint_table[i].avx2_op_single;
	    case e_past_avx2_double_op_type:
	      return g_pprint_table[i].avx2_op_double;
	    default: assert(! "Unsupported operation type"); return NULL;
	    }
	}
    }
  return NULL;
}



static
void
past_pprint_binary_scalar (FILE* out, int indent,
			   s_past_node_t* s, char* str,
			   s_symbol_table_t* symboltable,
			   past_metainfo_fun_t mprint,
			   past_pprint_extensions_fun_t past_pprint_ext,
			   s_past_options_t* opts)
{
  s_past_binary_t* pb = (s_past_binary_t*) s;

  int need_parenth = 0;
  if (past_get_enclosing_node (s, past_binary) ||
      past_get_enclosing_node (s, past_ternary))
    need_parenth = 1;
  if (need_parenth)
    fprintf (out, "(");
  past_pprint_node (out, indent, pb->lhs, symboltable, mprint,
		    past_pprint_ext, opts);
  // Do not put space for -> and .
  int use_space = 1;
  fprintf (out, " ");
  fprintf (out, "%s", str);
  fprintf (out, " ");
  past_pprint_node (out, indent, pb->rhs, symboltable, mprint,
		    past_pprint_ext, opts);
  if (need_parenth)
    fprintf (out, ")");
}


static
void
past_pprint_binaryfunc (FILE* out, int indent,
			s_past_node_t* s, char* str,
			s_symbol_table_t* symboltable,
			past_metainfo_fun_t mprint,
			past_pprint_extensions_fun_t past_pprint_ext,
			s_past_options_t* opts)
{
  s_past_binary_t* pb = (s_past_binary_t*) s;
  fprintf (out, "%s", str);
  fprintf (out, "(");
  past_pprint_node (out, indent, pb->lhs, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ", ");
  past_pprint_node (out, indent, pb->rhs, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ")");
}

static
void
past_pprint_binary (FILE* out, int indent,
		    s_past_node_t* s, char* str,
		    s_symbol_table_t* symboltable,
		    past_metainfo_fun_t mprint,
		    past_pprint_extensions_fun_t past_pprint_ext,
		    s_past_options_t* opts)
{
  // Defaults to printing the 'scalar' operator 'str', unless the type
  // of the operator is not scalar/unknown AND the operator is defined
  // in the operator translation table 'g_pprint_table' above.
  s_past_binary_t* pb = (s_past_binary_t*) s;
  char* strop = pprint_find_str_op (s->type, pb->op_type);
  if (strop == NULL ||
      pb->op_type == e_past_unknown_op_type ||
      pb->op_type == e_past_scalar_op_type)
    past_pprint_binary_scalar (out, indent, s, str, symboltable, mprint,
			       past_pprint_ext, opts);
  else
    past_pprint_binaryfunc (out, indent, s, strop, symboltable, mprint,
			    past_pprint_ext, opts);
}

static
void
past_pprint_arrayref (FILE* out, int indent,
		      s_past_node_t* s,
		      s_symbol_table_t* symboltable,
		      past_metainfo_fun_t mprint,
		      past_pprint_extensions_fun_t past_pprint_ext,
		      s_past_options_t* opts)
{
  PAST_DECLARE_TYPED(binary, pa, s);
  past_pprint_node (out, indent, pa->lhs, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, "[");
  past_pprint_node (out, indent, pa->rhs, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, "]");
}


static
void
past_pprint_ternary (FILE* out, int indent,
		     s_past_node_t* s, char* str,
		     s_symbol_table_t* symboltable,
		     past_metainfo_fun_t mprint,
		     past_pprint_extensions_fun_t past_pprint_ext,
		     s_past_options_t* opts)
{
  s_past_ternary_t* pt = (s_past_ternary_t*) s;
  char* strop = pprint_find_str_op (s->type, pt->op_type);
  if (strop == NULL ||
      pt->op_type == e_past_unknown_op_type ||
      pt->op_type == e_past_scalar_op_type)
    strop = str;
  fprintf (out, "%s", strop);
  fprintf (out, "(");
  past_pprint_node (out, indent, pt->arg1, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ", ");
  past_pprint_node (out, indent, pt->arg2, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ", ");
  past_pprint_node (out, indent, pt->arg3, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ")");
}


static
void
past_pprint_unaryfunc_prefix (FILE* out, int indent,
			      s_past_node_t* s, char* str,
			      s_symbol_table_t* symboltable,
			      past_metainfo_fun_t mprint,
			      past_pprint_extensions_fun_t past_pprint_ext,
			      s_past_options_t* opts)
{
  s_past_unary_t* pu = (s_past_unary_t*) s;
  char* strop = pprint_find_str_op (s->type, pu->op_type);
  if (strop == NULL ||
      pu->op_type == e_past_unknown_op_type ||
      pu->op_type == e_past_scalar_op_type)
    strop = str;
  fprintf (out, "%s", strop);
  /* if (! past_node_is_a (pu->expr, past_varref) && */
  /*     ! past_node_is_a (pu->expr, past_value)) */
    fprintf (out, "(");
  past_pprint_node (out, indent, pu->expr, symboltable, mprint,
		    past_pprint_ext, opts);
  /* if (! past_node_is_a (pu->expr, past_varref) && */
  /*     ! past_node_is_a (pu->expr, past_value)) */
  fprintf (out, ")");
}

static
void
past_pprint_unaryfunc_postfix (FILE* out, int indent,
			       s_past_node_t* s, char* str,
			       s_symbol_table_t* symboltable,
			       past_metainfo_fun_t mprint,
			       past_pprint_extensions_fun_t past_pprint_ext,
			       s_past_options_t* opts)
{
  s_past_unary_t* pu = (s_past_unary_t*) s;
  char* strop = pprint_find_str_op (s->type, pu->op_type);
  if (strop == NULL ||
      pu->op_type == e_past_unknown_op_type ||
      pu->op_type == e_past_scalar_op_type)
    strop = str;
  else
    {
      // If a function is defined for a postfix unary operator, prints
      // it as a function call.
      fprintf (out, "%s", str);
      str = "";
    }

  if (! past_node_is_a (pu->expr, past_varref) &&
      ! past_node_is_a (pu->expr, past_value))
    fprintf (out, "(");
  past_pprint_node (out, indent, pu->expr, symboltable, mprint,
		    past_pprint_ext, opts);
  if (! past_node_is_a (pu->expr, past_varref) &&
      ! past_node_is_a (pu->expr, past_value))
  fprintf (out, ")");
  fprintf (out, "%s", str);
}


static
void
past_pprint_varref (FILE* out, int indent,
		      s_past_node_t* s,
		      s_symbol_table_t* symboltable,
		      past_metainfo_fun_t mprint,
		      past_pprint_extensions_fun_t past_pprint_ext,
		      s_past_options_t* opts)
{
  s_past_varref_t* pv = (s_past_varref_t*) s;
  if (pv->symbol->name_str)
    fprintf (out, "%s", (char*) pv->symbol->name_str);
  else
    fprintf (out, "%p", pv->symbol->data);
}

static
void
past_pprint_vardecl (FILE* out, int indent,
		     s_past_node_t* s,
		     s_symbol_table_t* symboltable,
		     past_metainfo_fun_t mprint,
		     past_pprint_extensions_fun_t past_pprint_ext,
		     s_past_options_t* opts)
{
  PAST_DECLARE_TYPED(vardecl, pf, s);
  past_pprint_node (out, indent, pf->type,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, " ");
  past_pprint_node (out, indent, pf->name,
		    symboltable, mprint, past_pprint_ext, opts);
}

static
void
past_pprint_ternary_cond (FILE* out, int indent,
			  s_past_node_t* s,
			  s_symbol_table_t* symboltable,
			  past_metainfo_fun_t mprint,
			  past_pprint_extensions_fun_t past_pprint_ext,
			  s_past_options_t* opts)
{
  PAST_DECLARE_TYPED(ternary_cond, pf, s);
  fprintf (out, "(");
  past_pprint_node (out, indent, (s_past_node_t*)pf->cond,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, " ? ");
  past_pprint_node (out, indent, (s_past_node_t*)pf->true_clause,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, " : ");
  past_pprint_node (out, indent, (s_past_node_t*)pf->false_clause,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, ")");
}


static
void
past_pprint_fundecl (FILE* out, int indent,
		     s_past_node_t* s,
		     s_symbol_table_t* symboltable,
		     past_metainfo_fun_t mprint,
		     past_pprint_extensions_fun_t past_pprint_ext,
		     s_past_options_t* opts)
{
  PAST_DECLARE_TYPED(fundecl, pf, s);
  past_pprint_node (out, indent, pf->type,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, " ");
  past_pprint_node (out, indent, pf->name,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, "(");
  if (pf->args_list)
    {
      s_past_node_t* next;
      s_past_node_t* cur = pf->args_list;
      for (next = cur->next; cur; ((cur = next) && (next = cur->next)))
	{
	  cur->next = NULL;
	  past_pprint_node (out, indent, cur, symboltable, mprint,
			    past_pprint_ext, opts);
	  cur->next = next;
	  if (next)
	    fprintf (out, ", ");
	}
    }
  fprintf (out, ")\n");
  fprintf (out, "{\n");
  past_pprint_node (out, indent + PAST_INDENT_STEP, pf->body, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, "\n}\n");
}


static
void
past_pprint_funcall (FILE* out, int indent,
		     s_past_node_t* s,
		     s_symbol_table_t* symboltable,
		     past_metainfo_fun_t mprint,
		     past_pprint_extensions_fun_t past_pprint_ext,
		     s_past_options_t* opts)
{
  PAST_DECLARE_TYPED(funcall, pf, s);
  past_pprint_node (out, indent, pf->name,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, "(");
  if (pf->args_list)
    {
      s_past_node_t* next;
      s_past_node_t* cur = pf->args_list;
      for (next = cur->next; cur; ((cur = next) && (next = cur->next)))
	{
	  cur->next = NULL;
	  past_pprint_node (out, indent, cur, symboltable, mprint,
			    past_pprint_ext, opts);
	  cur->next = next;
	  if (next)
	    fprintf (out, ", ");
	}
    }
  fprintf (out, ")");
}


static
void
past_pprint_for (FILE* out, int indent,
		 s_past_node_t* s,
		 s_symbol_table_t* symboltable,
		 past_metainfo_fun_t mprint,
		 char* newlb,
		 char* newub,
		 past_pprint_extensions_fun_t past_pprint_ext,
		 s_past_options_t* opts)
{
  s_past_for_t* pf = (s_past_for_t*) s;
  fprintf (out, "%*s", indent, "");
  if (mprint)
    {
      mprint (s, out);
      if (s->metainfo)
	fprintf (out, "%*s", indent, "");
    }
  fprintf (out, "for (");
  if (! newlb)
    past_pprint_node (out, indent, pf->init, symboltable, mprint,
		      past_pprint_ext, opts);
  else
    {
      s_past_node_t* vref = past_node_varref_create (pf->iterator);
      past_pprint_node (out, indent, vref, symboltable,
			mprint, past_pprint_ext, opts);
      past_deep_free (vref);
      fprintf (out, " = ");
      fprintf (out, "%s", newlb);
    }
  fprintf (out, "; ");
  if (! newub)
    past_pprint_node (out, indent, pf->test, symboltable, mprint,
		      past_pprint_ext, opts);
  else
    {
      if (past_node_is_a (pf->test, past_binary))
	{
	  PAST_DECLARE_TYPED(binary, pb, pf->test);
	  past_pprint_node (out, indent, pb->lhs, symboltable, mprint,
			    past_pprint_ext, opts);
	  if (past_node_is_a (pf->test, past_leq))
	    fprintf (out, " <= ");
	  else if (past_node_is_a (pf->test, past_lt))
	    fprintf (out, " < ");
	  else if (past_node_is_a (pf->test, past_equal))
	    fprintf (out, " == ");
	  else
	    assert(0);
	  fprintf (out, "%s", newub);
	}
    }
  fprintf (out, "; ");
  past_pprint_node (out, indent, pf->increment, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ") {\n");
  past_pprint_node (out, indent + PAST_INDENT_STEP, pf->body, symboltable,
		    mprint, past_pprint_ext, opts);
  fprintf (out, "%*s", indent, "");
  fprintf (out, "}\n");
}

static
void
traverse_private_iter (s_past_node_t* node, void* args)
{
  if (past_node_is_a (node, past_for))
    {
      PAST_DECLARE_TYPED(for, pf, node);
      int i;
      s_symbol_t** privatevars = args;
      for (i = 0; privatevars[i] &&
	     !symbol_equal (privatevars[i], pf->iterator); ++i)
	;
      if (! privatevars[i])
	privatevars[i] = pf->iterator;
    }
}
static
void find_lb_decls (s_past_node_t* root, s_past_node_t* cur,
		    s_symbol_t** privatevars)
{
  s_past_node_t* tmp = cur->parent;
  s_past_node_t* tmp2 = cur;
  s_past_node_t* last = cur;
  while (tmp)
    {
      if (past_node_is_a (tmp, past_for) ||
	  past_node_is_a (tmp, past_if) ||
	  past_node_is_a (tmp, past_affineguard) ||
	  past_node_is_a (tmp, past_block))
	{
	  if (past_node_is_a (tmp, past_for))
	    tmp2 = ((s_past_for_t*)tmp)->body;
	  else if (past_node_is_a (tmp, past_affineguard))
	    tmp2 = ((s_past_affineguard_t*)tmp)->then_clause;
	  else if (past_node_is_a (tmp, past_block))
	    tmp2 = ((s_past_block_t*)tmp)->body;
	  else if (past_node_is_a (tmp, past_if))
	    tmp2 = ((s_past_if_t*)tmp)->then_clause;
	  for (; tmp2 && tmp2 != last; tmp2 = tmp2->next)
	    {
	      if (past_node_is_a (tmp2, past_statement))
		{
		  PAST_DECLARE_TYPED(statement, ps, tmp2);
		  if (past_node_is_a (ps->body, past_assign))
		    {
		      PAST_DECLARE_TYPED(binary, pb, ps->body);
		      if (past_node_is_a (pb->lhs, past_vardecl))
			{
			  PAST_DECLARE_TYPED(vardecl, pf, pb->lhs);
			  int i;
			  s_past_node_t** vrs = past_collect_nodetype
			    (pf->name, past_varref);
			  assert (vrs &&  vrs[0]);
			  for (i = 0; privatevars[i] &&
				 !symbol_equal
				 (privatevars[i],
				  ((s_past_varref_t*)vrs[0])->symbol); ++i)
			    ;
			  if (! privatevars[i])
			    privatevars[i] = ((s_past_varref_t*)vrs[0])->symbol;
			}
		    }
		}
	    }
	  if (past_node_is_a (tmp, past_if))
	    tmp2 = ((s_past_if_t*)tmp)->else_clause;
	  for (; tmp2 && tmp2 != last; tmp2 = tmp2->next)
	    {
	      if (past_node_is_a (tmp2, past_statement))
		{
		  PAST_DECLARE_TYPED(statement, ps, tmp2);
		  if (past_node_is_a (ps->body, past_assign))
		    {
		      PAST_DECLARE_TYPED(binary, pb, ps->body);
		      if (past_node_is_a (pb->lhs, past_vardecl))
			{
			  PAST_DECLARE_TYPED(vardecl, pf, pb->lhs);
			  int i;
			  s_past_node_t** vrs = past_collect_nodetype
			    (pf->name, past_varref);
			  assert (vrs &&  vrs[0]);
			  for (i = 0; privatevars[i] &&
				 !symbol_equal
				 (privatevars[i],
				  ((s_past_varref_t*)vrs[0])->symbol); ++i)
			    ;
			  if (! privatevars[i])
			    privatevars[i] = ((s_past_varref_t*)vrs[0])->symbol;
			}
		    }
		}
	    }
	  last = tmp;
	  tmp = tmp->parent;
	}
      else
	break;
    }
}
static
void
past_pprint_parfor (FILE* out, int indent,
		    s_past_node_t* s,
		    s_symbol_table_t* symboltable,
		    past_metainfo_fun_t mprint,
		    past_pprint_extensions_fun_t past_pprint_ext,
		    s_past_options_t* opts)
{
  s_past_parfor_t* pf = (s_past_parfor_t*) s;
  char* omp_init = NULL;
  char* omp_test = NULL;

  // Collect loop iterators and loop bounds surrouned by the loop.
  s_past_node_t* tmp;
  int nb_maybe_priv = 0;
  for (tmp = pf->body; tmp; tmp = tmp->next)
    nb_maybe_priv += past_count_for_loops (tmp);
  s_symbol_t* privatevars[nb_maybe_priv + 1];
  int i;
  for (i = 0; i < nb_maybe_priv + 1; ++i)
    privatevars[i] = NULL;

  // Find the root node, to collect other loop bounds.
  s_past_node_t* r;
  for (r = s; r->parent; r = r->parent)
    ;
  for (tmp = r; tmp; tmp = tmp->next)
    nb_maybe_priv += past_count_nodetype (tmp, past_vardecl);
  s_symbol_t* firstprivate[nb_maybe_priv + 1];
  for (i = 0; i < nb_maybe_priv + 1; ++i)
    firstprivate[i] = NULL;
  past_visitor (pf->body, traverse_private_iter, privatevars, NULL, NULL);
  find_lb_decls (r, pf->body, firstprivate);
  s_past_node_t* parent;
  for (parent = s->parent; parent && ! past_node_is_a (parent, past_parfor);
       parent = parent->parent)
    ;
  char* extrafirstprivate[3] = { NULL, NULL, NULL };

  // If the loop is an inner-loop, then print a vectorization pragma.
  if (privatevars[0] == NULL)
    {
      fprintf (out, "%*s#pragma ivdep\n", indent, "");
      fprintf (out, "%*s#pragma vector always\n", indent, "");
      fprintf (out, "%*s#pragma simd\n", indent, "");
    }
  // Otherwise, print an OpenMP pragma iff the loop is not surrounded
  // by another parfor AND is not a point-loop.
  else if (! parent && pf->type != e_past_point_loop)
    {
      // Do not omp-ify point loops.
      if (pf->type == e_past_point_loop)
	{
	  past_pprint_for (out, indent, s, symboltable, mprint, omp_init,
			   omp_test, past_pprint_ext, opts);
	  return;
	}

      // Do not omp-ify loops surrounded by more than one loop.
      s_past_node_t* parent;
      int num_enclosing_for = 0;
      int num_enclosing_parfor = 0;
      for (parent = s->parent; parent; parent = parent->parent)
	{
	  if (past_node_is_a (parent, past_for))
	    ++num_enclosing_for;
	  if (past_node_is_a (parent, past_parfor))
	    ++num_enclosing_parfor;
	}
      if (num_enclosing_for > 2)
	{
	  past_pprint_for (out, indent, s, symboltable, mprint, omp_init,
			   omp_test, past_pprint_ext, opts);
	  return;
	}

      // Do not nest omp-ified loops.
      if (num_enclosing_parfor > 0)
	{
	  past_pprint_for (out, indent, s, symboltable, mprint, omp_init,
			   omp_test, past_pprint_ext, opts);
	  return;
	}

      // Omp-ify the loop.
      if (pf->init)
	{
	  if (past_node_is_a (pf->init, past_binary))
	    {
	      PAST_DECLARE_TYPED(binary, pb, pf->init);
	      if (! past_node_is_a (pb->rhs, past_varref) &&
		  ! past_node_is_a (pb->rhs, past_value))
		{
		  fprintf (out, "%*s", indent, "");
		  fprintf (out, "lb1 = ");
		  past_pprint_node (out, indent, pb->rhs, symboltable, mprint,
				    past_pprint_ext, opts);
		  fprintf (out, ";\n");
		  omp_init = "lb1";
		  for (i = 0; extrafirstprivate[i]; ++i)
		    ;
		  extrafirstprivate[i] = "lb1";
		}
	    }
	}
      if (pf->test)
	{
	  if (past_node_is_a (pf->test, past_binary))
	    {
	      PAST_DECLARE_TYPED(binary, pb, pf->test);
	      if (past_node_is_a (pf->test, past_leq) ||
		  past_node_is_a (pf->test, past_lt))
		{
		  if (! past_node_is_a (pb->rhs, past_varref) &&
		      ! past_node_is_a (pb->rhs, past_value))
		    {
		      fprintf (out, "%*s", indent, "");
		      fprintf (out, "ub1 = ");
		      past_pprint_node (out, indent, pb->rhs, symboltable,
					mprint, past_pprint_ext, opts);
		      fprintf (out, ";\n");
		      omp_test = "ub1";
		      for (i = 0; extrafirstprivate[i]; ++i)
			;
		      extrafirstprivate[i] = "ub1";
		    }
		}
	    }
	}
      fprintf (out, "%*s#pragma omp parallel for ", indent, "");
      // Put them in the private clause, if any.
      if (privatevars[0])
	{
	  fprintf (out, "private(");
	  for (i = 0; privatevars[i]; ++i)
	    {
	      s_past_node_t* vref = past_node_varref_create (privatevars[i]);
	      past_pprint_varref (out, indent, vref,
				  symboltable, mprint, past_pprint_ext, opts);
	      past_deep_free (vref);
	      if (privatevars[i + 1])
		fprintf (out, ", ");
	    }
	  fprintf (out, ")");
	}
      if (firstprivate[0] || extrafirstprivate[0])
	{
	  fprintf (out, " firstprivate(");
	  for (i = 0; firstprivate[i]; ++i)
	    {
	      s_past_node_t* vref = past_node_varref_create (firstprivate[i]);
	      past_pprint_varref (out, indent, vref,
				  symboltable, mprint, past_pprint_ext, opts);
	      past_deep_free (vref);
	      if (firstprivate[i + 1])
		fprintf (out, ", ");
	    }
	  if (extrafirstprivate[0])
	    {
	      if (firstprivate[0])
		fprintf (out, ", ");
	      if (extrafirstprivate[1])
		fprintf (out, "%s, %s", extrafirstprivate[0],
			 extrafirstprivate[1]);
	      else
		fprintf (out, "%s", extrafirstprivate[0]);
	    }
	  fprintf (out, ")");
	}
      fprintf (out, "\n");
    }
  past_pprint_for (out, indent, s, symboltable, mprint, omp_init, omp_test,
		   past_pprint_ext, opts);
}


static
void
past_pprint_while (FILE* out, int indent,
		   s_past_node_t* s,
		   s_symbol_table_t* symboltable,
		   past_metainfo_fun_t mprint,
		   past_pprint_extensions_fun_t past_pprint_ext,
		   s_past_options_t* opts)
{
  s_past_while_t* pf = (s_past_while_t*) s;
  fprintf (out, "%*s", indent, "");
  if (mprint)
    {
      mprint (s, out);
      if (s->metainfo)
	fprintf (out, "%*s", indent, "");
    }
  fprintf (out, "while (");
  past_pprint_node (out, indent, pf->condition, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ") {\n");
  past_pprint_node (out, indent + PAST_INDENT_STEP, pf->body, symboltable,
		    mprint, past_pprint_ext, opts);
  fprintf (out, "%*s", indent, "");
  fprintf (out, "}\n");
}

static
void
past_pprint_do_while (FILE* out, int indent,
		      s_past_node_t* s,
		      s_symbol_table_t* symboltable,
		      past_metainfo_fun_t mprint,
		      past_pprint_extensions_fun_t past_pprint_ext,
		      s_past_options_t* opts)
{
  s_past_do_while_t* pf = (s_past_do_while_t*) s;
  fprintf (out, "%*s", indent, "");
  if (mprint)
    {
      mprint (s, out);
      if (s->metainfo)
	fprintf (out, "%*s", indent, "");
    }
  fprintf (out, "do {\n");
  past_pprint_node (out, indent + PAST_INDENT_STEP, pf->body, symboltable,
		    mprint, past_pprint_ext, opts);
  fprintf (out, "%*s", indent, "");
  fprintf (out, "}\n");
  fprintf (out, "%*s", indent, "");
  fprintf (out, "while (");
  past_pprint_node (out, indent, pf->condition, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ");");
}


static
void
past_pprint_value (FILE* out, int indent,
		   s_past_node_t* s,
		   s_symbol_table_t* symboltable,
		   past_metainfo_fun_t mprint,
		   past_pprint_extensions_fun_t past_pprint_ext,
		   s_past_options_t* opts)
{
  s_past_value_t* pt = (s_past_value_t*) s;
  switch (pt->type)
    {
    case e_past_value_int:
    case e_past_value_bool:
      fprintf (out, "%d", pt->value.intval);
      break;
    case e_past_value_float:
      fprintf (out, "%f", pt->value.floatval);
      break;
    case e_past_value_double:
      fprintf (out, "%f", pt->value.doubleval);
      break;
    case e_past_value_char:
    case e_past_value_uchar:
      fprintf (out, "%c", pt->value.charval);
      break;
    case e_past_value_uint:
      fprintf (out, "%u", pt->value.uintval);
      break;
    case e_past_value_longint:
      fprintf (out, "%ld", pt->value.longintval);
      break;
    case e_past_value_ulongint:
      fprintf (out, "%lu", pt->value.ulongintval);
      break;
    case e_past_value_longlongint:
    case e_past_value_longlong:
      fprintf (out, "%lld", pt->value.longlongintval);
      break;
    case e_past_value_ulonglongint:
      fprintf (out, "%llu", pt->value.ulonglongintval);
      break;
    case e_past_value_longdouble:
      fprintf (out, "%Lf", pt->value.longdoubleval);
      break;
    case e_past_value_ptr:
      fprintf (out, "%p", pt->value.ptrval);
      break;
    case e_past_value_hexuint:
      fprintf (out, "%x", pt->value.hexuintval);
      break;
    default:
      fprintf (stderr, "[PAST] pprint: other data types not yet implemented\n");
      assert (0);
    }
}


static
void
past_pprint_string (FILE* out, int indent,
		   s_past_node_t* s,
		   s_symbol_table_t* symboltable,
		   past_metainfo_fun_t mprint,
		   past_pprint_extensions_fun_t past_pprint_ext,
		   s_past_options_t* opts)
{
  s_past_string_t* pt = (s_past_string_t*) s;
  fprintf (out, "%s", pt->data);
}

static
void
past_pprint_affineguard (FILE* out, int indent,
			 s_past_node_t* s,
			 s_symbol_table_t* symboltable,
			 past_metainfo_fun_t mprint,
			 past_pprint_extensions_fun_t past_pprint_ext,
			 s_past_options_t* opts)
{
  s_past_affineguard_t* pa = (s_past_affineguard_t*) s;
  fprintf (out, "%*s", indent, "");
  if (mprint)
    {
      mprint (s, out);
      if (s->metainfo)
	fprintf (out, "%*s", indent, "");
    }
  fprintf (out, "if (");
  past_pprint_node (out, indent, pa->condition, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ") {\n");
  past_pprint_node (out, indent + PAST_INDENT_STEP,
		    pa->then_clause, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, "%*s", indent, "");
  fprintf (out, "}\n");
}

static
void
past_pprint_if (FILE* out, int indent,
		s_past_node_t* s,
		s_symbol_table_t* symboltable,
		past_metainfo_fun_t mprint,
		past_pprint_extensions_fun_t past_pprint_ext,
		s_past_options_t* opts)
{
  s_past_if_t* pa = (s_past_if_t*) s;
  fprintf (out, "%*s", indent, "");
  if (mprint)
    {
      mprint (s, out);
      if (s->metainfo)
	fprintf (out, "%*s", indent, "");
    }
  fprintf (out, "if (");
  past_pprint_node (out, indent, pa->condition, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ") {\n");
  past_pprint_node (out, indent + PAST_INDENT_STEP,
		    pa->then_clause, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, "%*s", indent, "");
  fprintf (out, "}\n");
  if (pa->else_clause)
    {
      fprintf (out, "%*s", indent, "");
      fprintf (out, "else {\n");
      past_pprint_node (out, indent + PAST_INDENT_STEP,
			pa->else_clause, symboltable, mprint,
			past_pprint_ext, opts);
      fprintf (out, "%*s", indent, "");
      fprintf (out, "}\n");
    }
}


static
void
past_pprint_cloogstmt (FILE* out, int indent,
		       s_past_node_t* s,
		       s_symbol_table_t* symboltable,
		       past_metainfo_fun_t mprint,
		       past_pprint_extensions_fun_t past_pprint_ext,
		       s_past_options_t* opts)
{
  s_past_cloogstmt_t* pa = (s_past_cloogstmt_t*) s;
  fprintf (out, "%*s", indent, "");
  fprintf (out, "%s(", (char*) pa->stmt_name->symbol->name_str);
  s_past_node_t* subs;
  for (subs = pa->substitutions; subs; subs = subs->next)
    {
      s_past_node_t* tmp = subs->next;
      subs->next = NULL;
      past_pprint_node (out, indent, subs, symboltable, mprint,
			past_pprint_ext, opts);
      subs->next = tmp;
      if (subs->next)
	fprintf (out, ", ");
    }
  fprintf (out, ");");
  if (mprint)
    mprint (s, out);
  fprintf (out, "\n");
}

static
void
past_pprint_statement (FILE* out, int indent,
		       s_past_node_t* s,
		       s_symbol_table_t* symboltable,
		       past_metainfo_fun_t mprint,
		       past_pprint_extensions_fun_t past_pprint_ext,
		       s_past_options_t* opts)
{
  s_past_statement_t* ps = (s_past_statement_t*) s;
  fprintf (out, "%*s", indent, "");
  past_pprint_node (out, indent, ps->body, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, "; ");
  if (mprint)
    mprint (s, out);
  fprintf (out, "\n");
}


static
void
past_pprint_block (FILE* out, int indent,
		   s_past_node_t* s,
		   s_symbol_table_t* symboltable,
		   past_metainfo_fun_t mprint,
		   past_pprint_extensions_fun_t past_pprint_ext,
		   s_past_options_t* opts)
{
  s_past_block_t* pa = (s_past_block_t*) s;
  fprintf (out, "%*s", indent, "");
  if (mprint)
    {
      mprint (s, out);
      if (s->metainfo)
	fprintf (out, "%*s", indent, "");
    }
  fprintf (out, "{\n");
  past_pprint_node (out, indent + PAST_INDENT_STEP, pa->body, symboltable,
		    mprint, past_pprint_ext, opts);
  fprintf (out, "%*s", indent, "");
  fprintf (out, "}\n");
}


static
void
past_pprint_cast (FILE* out, int indent,
		  s_past_node_t* s,
		  s_symbol_table_t* symboltable,
		  past_metainfo_fun_t mprint,
		  past_pprint_extensions_fun_t past_pprint_ext,
		  s_past_options_t* opts)
{
  s_past_cast_t* pu = (s_past_cast_t*) s;
  fprintf (out, "(");
  past_pprint_node (out, indent, pu->type,
		    symboltable, mprint, past_pprint_ext, opts);
  fprintf (out, ")(");
  past_pprint_node (out, indent, pu->expr, symboltable, mprint,
		    past_pprint_ext, opts);
  fprintf (out, ")");
}


static
void
past_pprint_generic (FILE* out, int indent,
		  s_past_node_t* s,
		  s_symbol_table_t* symboltable,
		  past_metainfo_fun_t mprint,
		  past_pprint_extensions_fun_t past_pprint_ext,
		  s_past_options_t* opts)
{
  s_past_generic_t* pu = (s_past_generic_t*) s;
  if (pu->char_data)
    fprintf (out, "%s", pu->char_data);
  else if (pu->ptr_data)
    fprintf (out, "[generic ptr=%p]", pu->ptr_data);
  else
    fprintf (out, "[generic]");
}


void
past_pprint_node (FILE* out,
		  int indent,
		  s_past_node_t* node,
		  s_symbol_table_t* symboltable,
		  past_metainfo_fun_t mprint,
		  past_pprint_extensions_fun_t past_pprint_ext,
		  s_past_options_t* opts)
{
  s_past_node_t* s;
  for (s = node; s; s = s->next)
    {
      if (past_node_is_a (s, past_parfor))
	past_pprint_parfor (out, indent, s, symboltable, mprint,
			    past_pprint_ext, opts);
      else if (past_node_is_a (s, past_for))
	past_pprint_for (out, indent, s, symboltable, mprint, NULL, NULL,
			 past_pprint_ext, opts);
      else if (past_node_is_a (s, past_while))
	past_pprint_while (out, indent, s, symboltable, mprint, past_pprint_ext,
			   opts);
      else if (past_node_is_a (s, past_do_while))
	past_pprint_do_while (out, indent, s, symboltable, mprint,
			      past_pprint_ext, opts);
      else if (past_node_is_a (s, past_type))
	{
	  // past_type is for semantics only, no pprint specifics.
	  PAST_DECLARE_TYPED(type, pt, s);
	  past_pprint_node (out, indent, pt->texpr, symboltable, mprint,
			    past_pprint_ext, opts);
	}
      else if (past_node_is_a (s, past_string))
	past_pprint_string (out, indent, s, symboltable, mprint,
			    past_pprint_ext, opts);

#define pprint_single_node(type)				\
      else if (past_node_is_a (s, past_##type))		\
	past_pprint_##type (out, indent, s, symboltable, mprint, past_pprint_ext, opts)

      pprint_single_node(varref);
      pprint_single_node(value);
      pprint_single_node(affineguard);
      pprint_single_node(statement);
      pprint_single_node(cloogstmt);
      pprint_single_node(if);
      pprint_single_node(block);
      pprint_single_node(arrayref);
      pprint_single_node(vardecl);
      pprint_single_node(ternary_cond);
      pprint_single_node(funcall);
      pprint_single_node(fundecl);
      pprint_single_node(cast);
      pprint_single_node(generic);


#define pprint_tern_node(type, str)			\
      else if (past_node_is_a (s, past_##type))	\
	past_pprint_ternary (out, indent, s, str, symboltable, mprint, past_pprint_ext, opts)
      pprint_tern_node(fma, "pocc_fma");
      pprint_tern_node(fms, "pocc_fms");


#define pprint_bin_node(type, str)			\
      else if (past_node_is_a (s, past_##type))	\
	past_pprint_binary (out, indent, s, str, symboltable, mprint, past_pprint_ext, opts)
      pprint_bin_node(add, "+");
      pprint_bin_node(sub, "-");
      pprint_bin_node(mul, "*");
      pprint_bin_node(div, "/");
      pprint_bin_node(mod, "%");
      pprint_bin_node(and, "&&");
      pprint_bin_node(or, "||");
      pprint_bin_node(equal, "==");
      pprint_bin_node(notequal, "!=");
      pprint_bin_node(assign, "=");
      pprint_bin_node(geq, ">=");
      pprint_bin_node(leq, "<=");
      pprint_bin_node(gt, ">");
      pprint_bin_node(lt, "<");
      pprint_bin_node(xor, "^");
      pprint_bin_node(band, "&");
      pprint_bin_node(bor, "|");
      pprint_bin_node(addassign, "+=");
      pprint_bin_node(subassign, "-=");
      pprint_bin_node(mulassign, "*=");
      pprint_bin_node(divassign, "/=");
      pprint_bin_node(modassign, "%=");
      pprint_bin_node(andassign, "&=");
      pprint_bin_node(orassign, "|=");
      pprint_bin_node(xorassign, "^=");
      pprint_bin_node(lshiftassign, "<<=");
      pprint_bin_node(rshiftassign, ">>=");
      pprint_bin_node(lshift, "<<");
      pprint_bin_node(rshift, ">>");
      pprint_bin_node(dot, ".");
      pprint_bin_node(arrow, "->");

#define pprint_binfun_node(type, str)			\
      else if (past_node_is_a (s, past_##type))	\
	past_pprint_binaryfunc (out, indent, s, str, symboltable, mprint, past_pprint_ext, opts)

      pprint_binfun_node(min, "min");
      pprint_binfun_node(max, "max");
      pprint_binfun_node(ceild, "ceild");
      pprint_binfun_node(floord, "floord");

#define pprint_unfun_node(type, str)			\
      else if (past_node_is_a (s, past_##type))	\
	past_pprint_unaryfunc_prefix (out, indent, s, str, symboltable, mprint, past_pprint_ext, opts)

      pprint_unfun_node(round, "round");
      pprint_unfun_node(floor, "floor");
      pprint_unfun_node(ceil, "ceil");
      pprint_unfun_node(sqrt, "sqrt");
      pprint_unfun_node(inc_before, "++");
      pprint_unfun_node(dec_before, "--");
      pprint_unfun_node(unaminus, "-");
      pprint_unfun_node(unaplus, "+");
      pprint_unfun_node(opsizeof, "sizeof");
      pprint_unfun_node(addressof, "&");
      pprint_unfun_node(derefof, "*");
      pprint_unfun_node(bcomp, "~");
      pprint_unfun_node(not, "!");

#define pprint_unfun_node_post(type, str)			\
      else if (past_node_is_a (s, past_##type))	\
	past_pprint_unaryfunc_postfix (out, indent, s, str, symboltable, mprint, past_pprint_ext, opts)

      pprint_unfun_node_post(inc_after, "++");
      pprint_unfun_node_post(dec_after, "--");
      pprint_unfun_node_post(referencetype, "&");
      pprint_unfun_node_post(pointertype, "*");


      else if (past_pprint_ext &&
	       past_pprint_ext (out, indent, s, symboltable, mprint, opts))
	;
      else
	fprintf (stderr, "[PAST] Pretty-print: Unsupported node type\n");
    }
}


/**
 * Default C pretty-printer, with options support.
 *
 *
 */
void
past_pprint_options (FILE* out, s_past_node_t* root, s_past_options_t* options)
{
  s_past_node_t* to_del = NULL;
  if (options && options->pprint_encapsulate_arrayref)
    // In-place replacement: root cannot be an arrayref.
    to_del = root = past_encapsulate_arrayref_in_func (past_clone (root));

  if (past_node_is_a (root, past_root))
    {
      s_past_root_t* pr = (s_past_root_t*) root;
      past_pprint_node (out, 0, pr->body, pr->symboltable, NULL, NULL, options);
    }
  else
    past_pprint_node (out, 0, root, NULL, NULL, NULL, options);

  if (to_del)
    past_deep_free (to_del);
}
  
  #define FILL_IN_PPRINT_TABLE \
  struct pprint_op pprint_table[] = {\
    /* Ternary nodes.	*/						\
    {past_fma, "pocc_fma", NULL, NULL, NULL, NULL, "_mm256_fmadd_ps", "_mm256_fmadd_pd"}, \
    {past_fms, "pocc_fms", NULL, NULL, NULL, NULL, "_mm256_fmsub_ps", "_mm256_fmsub_pd"}, \
    /* Binary nodes.*/							\
    {past_add, "+", "_mm_add_ps", "_mm_add_pd", "_mm256_add_ps", "_mm256_add_pd","_mm256_add_ps", "_mm256_add_pd"}, \
    {past_sub, "-", "_mm_sub_ps", "_mm_sub_pd", "_mm256_sub_ps", "_mm256_sub_pd","_mm256_sub_ps", "_mm256_sub_pd"}, \
    {past_mul, "*", "_mm_mul_ps", "_mm_mul_pd", "_mm256_mul_ps", "_mm256_mul_pd","_mm256_mul_ps", "_mm256_mul_pd"}, \
    {past_div, "/", "_mm_div_ps", "_mm_div_pd", "_mm256_div_ps", "_mm256_div_pd","_mm256_div_ps", "_mm256_div_pd"}, \
    /* prefix unaries.  */ \
    {past_sqrt, "sqrt", "_mm_sqrt_ps", "_mm_sqrt_pd", "_mm256_sqrt_ps", "_mm256_sqrt_pd", "_mm256_sqrt_ps", "_mm256_sqrt_pd"},  \
    { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}			\
  }; \
  g_pprint_table = pprint_table;

/**
 * Default C pretty-printer.
 *
 *
 */
void
past_pprint (FILE* out, s_past_node_t* root)
{
  FILL_IN_PPRINT_TABLE;

  // Pretty print the tree.
  s_past_options_t* popts = past_options_malloc ();
  if (past_node_is_a (root, past_root))
    {
      s_past_root_t* pr = (s_past_root_t*) root;
      past_pprint_node (out, 0, pr->body, pr->symboltable, NULL, NULL, popts);
    }
  else
    past_pprint_node (out, 0, root, NULL, NULL, NULL, popts);
}


/**
 * C pretty-printer using 'mprint' to print meta-info, if any.
 * prototype: void mprint (s_past_node_t* node, FILE* out).
 *
 */
void
past_pprint_metainfo (FILE* out, s_past_node_t* root,
		      past_metainfo_fun_t mprint)
{
  FILL_IN_PPRINT_TABLE;

  s_past_options_t* popts = past_options_malloc ();
  if (past_node_is_a (root, past_root))
    {
      s_past_root_t* pr = (s_past_root_t*) root;
      past_pprint_node (out, 0, pr->body, pr->symboltable, mprint, NULL, popts);
    }
  else
    past_pprint_node (out, 0, root, NULL, mprint, NULL, popts);
}



/**
 * C pretty-printer using 'mprint' to print meta-info, if any.
 * prototype: void mprint (s_past_node_t* node, FILE* out).
 * Uses 'past_pprint_ext' to print user-defined nodes, if any.
 *
 */
void
past_pprint_extended_metainfo (FILE* out, s_past_node_t* root,
			       past_metainfo_fun_t mprint,
			       past_pprint_extensions_fun_t past_pprint_ext)
{
  FILL_IN_PPRINT_TABLE;
  
  s_past_options_t* popts = past_options_malloc ();
  if (past_node_is_a (root, past_root))
    {
      s_past_root_t* pr = (s_past_root_t*) root;
      past_pprint_node (out, 0, pr->body, pr->symboltable, mprint,
			past_pprint_ext, popts);
    }
  else
    past_pprint_node (out, 0, root, NULL, mprint, past_pprint_ext, popts);
}
