/*
 * symbols.c: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <past/config.h>
#endif

#include <past/common.h>
#include <past/symbols.h>


/**
 *
 *
 */
s_symbol_t*
symbol_malloc ()
{
  s_symbol_t* ret = XMALLOC(s_symbol_t, 1);
  ret->name_str = NULL;
  ret->data = NULL;
  ret->num_refs = 1;
  ret->type = past_unknown;
  ret->sym_table = NULL;
  ret->generated = 0;
  ret->declaration = NULL;
  ret->struct_depth = 0;
  ret->parent_symb = NULL;
  ret->next = NULL;
  ret->prev = NULL;

  return ret;
}

/**
 *
 *
 */
s_symbol_table_t*
symbol_table_malloc ()
{
  s_symbol_table_t* ret = XMALLOC(s_symbol_table_t, 1);
  ret->symbols = NULL;

  return ret;
}

/**
 *
 *
 */
void
symbol_free (s_symbol_t* symbol)
{
  if (symbol)
    {
      if (symbol->name_str)
	XFREE(symbol->name_str);
      XFREE(symbol);
    }
}

/**
 *
 *
 */
void
symbol_table_free (s_symbol_table_t* table)
{
  if (table)
    {
      s_symbol_t* s;
      s_symbol_t* next;
      for (s = table->symbols; s; )
	{
	  next = s->next;
	  symbol_free (s);
	  s = next;
	}
      XFREE(table);
    }
}

/**
 *
 *
 */
void
symbol_table_print (s_symbol_table_t* table)
{
  printf ("[DEBUG] Dump symbol table %p\n", table);
  if (table)
    {
      s_symbol_t* s;
      for (s = table->symbols; s; s = s->next)
	{
	  printf ("name_str=%s data=%p parent_symb=%p decl_ptr=%p table=%p generated=%d num_refs=%d\n",
		  s->name_str, s->data, s->parent_symb, s->declaration,
		  s->sym_table, s->generated, s->num_refs);
	}
    }
}

/**
 *
 *
 */
void
symbol_table_print_symbols_by_name (s_symbol_table_t* table, char* str)
{
  printf ("[DEBUG] Dump symbol table %p\n", table);
  if (table)
    {
      s_symbol_t* s;
      for (s = table->symbols; s; s = s->next)
	{
	  if (str && s->name_str && ! strcmp (s->name_str, str))
	    printf ("name_str=%s data=%p parent_symb=%p decl_ptr=%p table=%p generated=%d num_refs=%d\n",
		    s->name_str, s->data, s->parent_symb, s->declaration,
		    s->sym_table, s->generated, s->num_refs);
	}
    }
}

/**
 *
 *
 */
s_symbol_t*
symbol_create (e_symbol_type_t type, const char* name_str, void* data)
{
  s_symbol_t* ret = symbol_malloc ();
  ret->type = type;
  if (name_str)
    ret->name_str = strdup (name_str);
  ret->data = data;

  return ret;
}

/**
 *
 *
 */
s_symbol_t*
symbol_add (s_symbol_table_t* table, s_symbol_t* symbol)
{
  // If there's no symbol table, simply return the symbol.
  if (table == NULL)
    {
      symbol->sym_table = NULL;
      return symbol;
    }

  s_symbol_t* s;
  symbol->sym_table = table;
  if ((s = symbol_find (table, symbol)))
    {
      (s->num_refs)++;
      return s;
    }
  else
    {
      symbol->next = table->symbols;
      if (table->symbols)
	table->symbols->prev = symbol;
      table->symbols = symbol;
      return symbol;
    }
}

/**
 *
 *
 */
s_symbol_t*
symbol_get_or_insert (s_symbol_table_t* table, const char* name_str, void* data)
{
  s_symbol_t* s = symbol_create (past_unknown, name_str, data);
  s_symbol_t* ret = symbol_add (table, s);
  if (ret != s)
    symbol_free (s);
  return ret;
}

/**
 *
 *
 */
s_symbol_t*
symbol_add_from_char (s_symbol_table_t* table, const char* name_str)
{
  return symbol_get_or_insert (table, name_str, NULL);
}


/**
 *
 *
 */
void
symbol_remove (s_symbol_table_t* table, s_symbol_t* symbol)
{
  s_symbol_t* s;
  if ((s = symbol_find (table, symbol)))
    {
      if (s->num_refs > 1)
	(s->num_refs)--;
      else
	{
	  if (s->prev)
	    {
	      s->prev->next = s->next;
	      if (s->next)
		s->next->prev = s->prev;
	    }
	  else
	    {
	      table->symbols = s->next;
	      if (s->next)
		s->next->prev = NULL;
	    }
	  symbol_free (s);
	}
    }
}

/**
 *
 *
 */
s_symbol_t*
symbol_find (s_symbol_table_t* table, s_symbol_t* symbol)
{
  s_symbol_t* s;
  for (s = table->symbols; s; s = s->next)
    {
      if (symbol_equal (s, symbol))
	return s;
    }
  return NULL;
}


/**
 * Returns true if symbol 'symb' has 'parent' as one of its parent
 * symbol.
 *
 */
int
symbol_parent_find (s_symbol_t* symb, s_symbol_t* parent)
{
  while (symb && symb->parent_symb != parent)
    symb = symb->parent_symb;
  return symb != NULL;
}


/**
 *
 *
 */
int
symbol_equal (s_symbol_t* s1, s_symbol_t* s2)
{
  if (s1 == s2)
    return 1;
  if (s1 == NULL || s2 == NULL)
    return 0;
  int eq_str = (!s1->name_str) && (!s2->name_str);
  if (s1->name_str && s2->name_str)
    eq_str = ! strcmp (s1->name_str, s2->name_str);
  s_symbol_t* pars1 = s1->parent_symb;
  s_symbol_t* pars2 = s2->parent_symb;
  while (pars1 && pars2 && pars1 == pars2)
    {
      pars1 = pars1->parent_symb;
      pars2 = pars2->parent_symb;
    }
  return (s1->data == s2->data) && eq_str &&
    (s1->declaration == s2->declaration) &&
    (s1->struct_depth == s2->struct_depth) &&
    (pars1 == pars2);
}

/**
 *
 *
 */
int
symbol_type_equal (s_symbol_t* s1, s_symbol_t* s2)
{
  return symbol_equal (s1, s2) && s1->type == s2->type;
}

/**
 *
 *
 */
s_symbol_t*
symbol_find_from_data (s_symbol_table_t* table, void* data)
{
  if (table == NULL || data == NULL)
    return NULL;
  s_symbol_t* s;
  for (s = table->symbols; s; s = s->next)
    if (s->data == data)
      return s;
  return NULL;
}

/**
 *
 *
 */
s_symbol_t*
symbol_find_from_char (s_symbol_table_t* table, char* name_str)
{
  if (table == NULL || name_str == NULL)
    return NULL;
  s_symbol_t* s;
  for (s = table->symbols; s; s = s->next)
    if (s->name_str && ! strcmp (s->name_str, name_str))
      return s;
  return NULL;
}
