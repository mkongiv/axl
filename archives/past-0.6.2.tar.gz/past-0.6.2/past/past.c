/*
 * past.c: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <past/config.h>
#endif

#include <assert.h>
#include <past/common.h>
#include <past/past.h>

/**
 *
 *
 */
int
past_node_is_a (s_past_node_t* node, cs_past_node_type_t* type)
{
  int i = 0;
  if (!node || !type)
    return 0;
  while (i < PAST_NODE_HIERARCHY_HEIGHT && node->type->freefun[i])
    if (node->type->freefun[i++] == type->freefun[0])
      return 1;
  return 0;
}

static
void
past_node_init (s_past_node_t* node,
		cs_past_node_type_t* type,
		past_visitor_fun_t visitor,
		past_clone_fun_t clone)
{
  node->type = type;
  node->visitor = visitor;
  node->clone = clone;
  node->parent = NULL;
  node->next = NULL;
  node->metainfo = NULL;
  node->decoration = NULL;
  node->usr = NULL;
}

void
past_node_freeattr (s_past_node_t* node)
{
  if (node)
    {
      XFREE(node->metainfo);
    }
}

static
void
set_parent_sibling_nodes (s_past_node_t* node, s_past_node_t* parent)
{
  for (; node; node->parent = parent, node = node->next)
    ;
}

/**
 * past_node. Abstract type.
 *
 */
void
past_node_free (s_past_node_t* node)
{
  assert ("past_node: cannot be explicitly instantiated");
  printf ("Calling virtual function past_node_free!\n");
  exit (1);
}
cs_past_node_type_t s_past_node = { past_node_free, NULL };
cs_past_node_type_t* const past_node = &s_past_node;


/**
 * past_root
 *
 * Note: symbol table is not freed, it must be freed before deleting
 * the node.
 */
void
past_root_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_root));
  s_past_root_t* pr = (s_past_root_t*) node;
  /// Do not delete the symbol table as cloning nodes with a symbol
  /// table only do a shallow copy of the symbol table.
  //symbol_table_free (pr->symboltable);
  past_node_freeattr (node);
  XFREE(pr);
}
static void
past_root_visitor (s_past_node_t* node,
		   past_fun_t prefix,
		   void* prefix_data,
		   past_fun_t suffix,
		   void* suffix_data)
{
  assert (past_node_is_a (node, past_root));
  PAST_DECLARE_TYPED(root, r, node);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(root);

static s_past_node_t*
past_root_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_root));
  PAST_DECLARE_TYPED(root, r, node);
  return past_node_root_create (r->symboltable, past_clone (r->body));
}

s_past_root_t* past_root_create (s_symbol_table_t* symboltable,
				 s_past_node_t* body)
{
  s_past_root_t* n = XMALLOC(s_past_root_t, 1);
  past_node_init (&(n->node), past_root, past_root_visitor, past_root_clone);
  n->symboltable = symboltable;
  n->body = body;
  set_parent_sibling_nodes (n->body, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_root_create (s_symbol_table_t* symboltable,
				      s_past_node_t* body)
{
  return &past_root_create(symboltable, body)->node;
}


/**
 * past_varref
 *
 *
 */
void
past_varref_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_varref));
  s_past_varref_t* pv = (s_past_varref_t*) node;
  past_node_freeattr (node);
  XFREE(pv);
}
static void
past_varref_visitor (s_past_node_t* node,
		     past_fun_t prefix,
		     void* prefix_data,
		     past_fun_t suffix,
		     void* suffix_data)
{
  assert (past_node_is_a (node, past_varref));
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(varref);

static s_past_node_t*
past_varref_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_varref));
  PAST_DECLARE_TYPED(varref, v, node);
  s_past_node_t* n =  past_node_varref_create (v->symbol);
  PAST_DECLARE_TYPED(varref, pv, n);
  n->usr = v->usr;
  return n;
}

s_past_varref_t* past_varref_create (s_symbol_t* symbol)
{
  s_past_varref_t* n = XMALLOC(s_past_varref_t, 1);
  past_node_init (&(n->node), past_varref, past_varref_visitor,
		  past_varref_clone);
  n->symbol = symbol;
  n->usr = NULL;
  return n;
}

s_past_node_t* past_node_varref_create (s_symbol_t* symbol)
{
  return &past_varref_create (symbol)->node;
}

/**
 * past_type
 *
 *
 */
void
past_type_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_type));
  s_past_type_t* pv = (s_past_type_t*) node;
  past_node_freeattr (node);
  XFREE(pv);
}
static void
past_type_visitor (s_past_node_t* node,
		     past_fun_t prefix,
		     void* prefix_data,
		     past_fun_t suffix,
		     void* suffix_data)
{
  assert (past_node_is_a (node, past_type));
  PAST_DECLARE_TYPED(type, r, node);
  past_visitor (r->texpr, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(type);

static s_past_node_t*
past_type_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_type));
  PAST_DECLARE_TYPED(type, n, node);
  s_past_type_t* t = past_type_create (past_clone (n->texpr));
  t->usr = n->usr;
  return &(t->node);
}

s_past_type_t* past_type_create (s_past_node_t* texpr)
{
  s_past_type_t* n = XMALLOC(s_past_type_t, 1);
  past_node_init (&(n->node), past_type, past_type_visitor,
		  past_type_clone);
  n->texpr = texpr;
  n->usr = NULL;

  return n;
}

s_past_node_t* past_node_type_create (s_past_node_t* texpr)
{
  return &past_type_create (texpr)->node;
}


/**
 * past_value
 *
 *
 */
void
past_value_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_value));
  s_past_value_t* pv = (s_past_value_t*) node;
  past_node_freeattr (node);
  XFREE(pv);
}
static void
past_value_visitor (s_past_node_t* node,
		    past_fun_t prefix,
		    void* prefix_data,
		    past_fun_t suffix,
		    void* suffix_data)
{
  assert (past_node_is_a (node, past_value));
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(value);

static s_past_node_t*
past_value_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_value));
  PAST_DECLARE_TYPED(value, v, node);
  return past_node_value_create (v->type, v->value);
}

s_past_value_t* past_value_create (int type, u_past_value_data_t val)
{
  s_past_value_t* n = XMALLOC(s_past_value_t, 1);
  past_node_init (&(n->node), past_value, past_value_visitor, past_value_clone);
  n->type = type;
  n->value = val;

  return n;
}

s_past_node_t* past_node_value_create (int type, u_past_value_data_t val)
{
  return &past_value_create (type, val)->node;
}

s_past_value_t* past_value_create_from_int (int val)
{
  u_past_value_data_t uval;
  uval.intval = val;
  return past_value_create (e_past_value_int, uval);
}

s_past_node_t* past_node_value_create_from_int (int val)
{
  return &past_value_create_from_int (val)->node;
}




/**
 * past_string
 *
 *
 */
void
past_string_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_string));
  s_past_string_t* pv = (s_past_string_t*) node;
  if (pv->data)
    XFREE(pv->data);
  past_node_freeattr (node);
  XFREE(pv);
}
static void
past_string_visitor (s_past_node_t* node,
		    past_fun_t prefix,
		    void* prefix_data,
		    past_fun_t suffix,
		    void* suffix_data)
{
  assert (past_node_is_a (node, past_string));
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(string);

static s_past_node_t*
past_string_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_string));
  PAST_DECLARE_TYPED(string, v, node);
  return past_node_string_create (v->data);
}

s_past_string_t* past_string_create (char* data)
{
  s_past_string_t* n = XMALLOC(s_past_string_t, 1);
  past_node_init (&(n->node), past_string, past_string_visitor,
		  past_string_clone);
  if (data)
    n->data = strdup (data);
  else
    n->data = NULL;

  return n;
}

s_past_node_t* past_node_string_create (char* data)
{
  return &past_string_create (data)->node;
}


/**
 * past_for
 *
 *
 */
void
past_for_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_for));
  s_past_for_t* pf = (s_past_for_t*) node;
  past_deep_free (pf->init);
  past_deep_free (pf->test);
  past_deep_free (pf->increment);
  past_deep_free (pf->body);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_for_visitor (s_past_node_t* node,
		  past_fun_t prefix,
		  void* prefix_data,
		  past_fun_t suffix,
		  void* suffix_data)
{
  assert (past_node_is_a (node, past_for));
  PAST_DECLARE_TYPED(for, r, node);
  past_visitor (r->init, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->test, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->increment, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(for);

static s_past_node_t*
past_for_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_for));
  PAST_DECLARE_TYPED(for, f, node);
  s_past_node_t* n = past_node_for_create (past_clone (f->init),
					   past_clone (f->test),
					   f->iterator,
					   past_clone (f->increment),
					   past_clone (f->body));
  PAST_DECLARE_TYPED(for, cf, n);
  cf->usr = f->usr;
  cf->type = f->type;
  cf->property = f->property;

  return n;
}

s_past_for_t* past_for_create (s_past_node_t* init,
			       s_past_node_t* test,
			       s_symbol_t* iterator,
			       s_past_node_t* increment,
			       s_past_node_t* body)
{
  s_past_for_t* n = XMALLOC(s_past_for_t, 1);
  past_node_init (&(n->node), past_for, past_for_visitor, past_for_clone);
  n->init = init;
  n->test = test;
  n->iterator = iterator;
  n->increment = increment;
  n->body = body;
  n->type = e_past_unknown_loop;
  n->property = e_past_unset_prop;
  set_parent_sibling_nodes (n->init, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->test, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->increment, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->body, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_for_create (s_past_node_t* init,
				     s_past_node_t* test,
				     s_symbol_t* iterator,
				     s_past_node_t* increment,
				     s_past_node_t* body)
{
  return &past_for_create (init, test, iterator, increment, body)->node;
}


/**
 * past_parfor
 *
 *
 */
void
past_parfor_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_parfor));
  s_past_parfor_t* pf = (s_past_parfor_t*) node;
  past_deep_free (pf->init);
  past_deep_free (pf->test);
  past_deep_free (pf->increment);
  past_deep_free (pf->body);
  if (pf->private_vars)
    XFREE(pf->private_vars);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_parfor_visitor (s_past_node_t* node,
		     past_fun_t prefix,
		     void* prefix_data,
		     past_fun_t suffix,
		     void* suffix_data)
{
  assert (past_node_is_a (node, past_parfor));
  PAST_DECLARE_TYPED(parfor, r, node);
  past_visitor (r->init, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->test, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->increment, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_2(parfor,for);

static s_past_node_t*
past_parfor_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_parfor));
  PAST_DECLARE_TYPED(parfor, f, node);
  s_past_node_t* n = past_node_parfor_create (past_clone (f->init),
					      past_clone (f->test),
					      f->iterator,
					      past_clone(f->increment),
					      past_clone (f->body));
  PAST_DECLARE_TYPED(parfor, cf, n);
  cf->usr = f->usr;
  cf->type = f->type;
  cf->property = f->property;
  if (f->private_vars)
    {
      int i;
      for (i = 0; f->private_vars[i]; ++i)
	;
      s_symbol_t** newvars = XMALLOC(s_symbol_t*, i + 1);
      for (i = 0; f->private_vars[i]; ++i)
	newvars[i] = f->private_vars[i];
      newvars[i] = NULL;
      cf->private_vars = newvars;
    }

  return n;
}

s_past_parfor_t* past_parfor_create (s_past_node_t* init,
				     s_past_node_t* test,
				     s_symbol_t* iterator,
				     s_past_node_t* increment,
				     s_past_node_t* body)
{
  s_past_parfor_t* n = XMALLOC(s_past_parfor_t, 1);
  past_node_init (&(n->node), past_parfor, past_parfor_visitor,
		  past_parfor_clone);
  n->init = init;
  n->test = test;
  n->iterator = iterator;
  n->increment = increment;
  n->body = body;
  n->type = e_past_unknown_loop;
  n->property = e_past_unset_prop;
  n->private_vars = NULL;
  set_parent_sibling_nodes (n->init, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->test, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->increment, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->body, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_parfor_create (s_past_node_t* init,
					s_past_node_t* test,
					s_symbol_t* iterator,
					s_past_node_t* increment,
					s_past_node_t* body)
{
  return &past_parfor_create (init, test, iterator, increment, body)->node;
}




/**
 * past_while
 *
 *
 */
void
past_while_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_while));
  s_past_while_t* pf = (s_past_while_t*) node;
  past_deep_free (pf->condition);
  past_deep_free (pf->body);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_while_visitor (s_past_node_t* node,
		    past_fun_t prefix,
		    void* prefix_data,
		    past_fun_t suffix,
		    void* suffix_data)
{
  assert (past_node_is_a (node, past_while));
  PAST_DECLARE_TYPED(while, r, node);
  past_visitor (r->condition, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(while);

static s_past_node_t*
past_while_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_while));
  PAST_DECLARE_TYPED(while, f, node);
  s_past_node_t* n = past_node_while_create (past_clone (f->condition),
					     past_clone (f->body));
  PAST_DECLARE_TYPED(while, cf, n);
  cf->usr = f->usr;

  return n;
}

s_past_while_t* past_while_create (s_past_node_t* condition,
				   s_past_node_t* body)
{
  s_past_while_t* n = XMALLOC(s_past_while_t, 1);
  past_node_init (&(n->node), past_while, past_while_visitor, past_while_clone);
  n->condition = condition;
  n->body = body;
  n->usr = NULL;
  set_parent_sibling_nodes (n->condition, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->body, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_while_create (s_past_node_t* condition,
				       s_past_node_t* body)
{
  return &past_while_create (condition, body)->node;
}



/**
 * past_do_while
 *
 *
 */
void
past_do_while_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_do_while));
  s_past_do_while_t* pf = (s_past_do_while_t*) node;
  past_deep_free (pf->condition);
  past_deep_free (pf->body);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_do_while_visitor (s_past_node_t* node,
		       past_fun_t prefix,
		       void* prefix_data,
		       past_fun_t suffix,
		       void* suffix_data)
{
  assert (past_node_is_a (node, past_do_while));
  PAST_DECLARE_TYPED(do_while, r, node);
  past_visitor (r->condition, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(do_while);

static s_past_node_t*
past_do_while_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_do_while));
  PAST_DECLARE_TYPED(do_while, f, node);
  s_past_node_t* n = past_node_do_while_create (past_clone (f->condition),
					     past_clone (f->body));
  PAST_DECLARE_TYPED(do_while, cf, n);
  cf->usr = f->usr;

  return n;
}

s_past_do_while_t* past_do_while_create (s_past_node_t* condition,
					 s_past_node_t* body)
{
  s_past_do_while_t* n = XMALLOC(s_past_do_while_t, 1);
  past_node_init (&(n->node), past_do_while, past_do_while_visitor,
		  past_do_while_clone);
  n->condition = condition;
  n->body = body;
  n->usr = NULL;
  set_parent_sibling_nodes (n->condition, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->body, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_do_while_create (s_past_node_t* condition,
					  s_past_node_t* body)
{
  return &past_do_while_create (condition, body)->node;
}



/**
 * past_ternary
 *
 *
 */
void
past_ternary_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_ternary));
  s_past_ternary_t* pf = (s_past_ternary_t*) node;
  past_deep_free (pf->arg1);
  past_deep_free (pf->arg2);
  past_deep_free (pf->arg3);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_ternary_visitor (s_past_node_t* node,
		     past_fun_t prefix,
		     void* prefix_data,
		     past_fun_t suffix,
		     void* suffix_data)
{
  assert (past_node_is_a (node, past_ternary));
  PAST_DECLARE_TYPED(ternary, r, node);
  past_visitor (r->arg1, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->arg2, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->arg3, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(ternary);

#define declare_tern_free_ops(type)					\
  void past_##type##_free (s_past_node_t* node)				\
   { past_ternary_free (node); }					\
  static void past_##type##_visitor (s_past_node_t* node,		\
				     past_fun_t prefix,			\
				     void* prefix_data,			\
				     past_fun_t suffix,			\
				     void* suffix_data)			\
   { past_ternary_visitor (node, prefix, prefix_data, suffix, suffix_data); } \
  PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_2(type, ternary);
// FMA.
declare_tern_free_ops(fma);
declare_tern_free_ops(fms);


static s_past_node_t*
past_ternary_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_ternary));
  PAST_DECLARE_TYPED(ternary, b, node);
  s_past_node_t* ret =
    past_node_ternary_create (node->type, past_clone (b->arg1),
			      past_clone (b->arg2), past_clone (b->arg3));
  PAST_DECLARE_TYPED(ternary, pt, ret);
  pt->op_type = b->op_type;

  return ret;
}

s_past_ternary_t* past_ternary_create (cs_past_node_type_t* type,
				       s_past_node_t* arg1,
				       s_past_node_t* arg2,
				       s_past_node_t* arg3)
{
  s_past_ternary_t* n = XMALLOC(s_past_ternary_t, 1);
  if (type)
    past_node_init (&(n->node), type, past_ternary_visitor, past_ternary_clone);
  else
    past_node_init (&(n->node), past_ternary, past_ternary_visitor,
		    past_ternary_clone);
  n->arg1 = arg1;
  n->arg2 = arg2;
  n->arg3 = arg3;
  n->op_type = e_past_unknown_op_type;
  set_parent_sibling_nodes (n->arg1, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->arg2, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->arg3, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_ternary_create (cs_past_node_type_t* type,
					s_past_node_t* arg1,
					s_past_node_t* arg2,
					s_past_node_t* arg3)
{
  return &past_ternary_create (type, arg1, arg2, arg3)->node;
}


/**
 * past_binary
 *
 *
 */
void
past_binary_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_binary));
  s_past_binary_t* pf = (s_past_binary_t*) node;
  past_deep_free (pf->lhs);
  past_deep_free (pf->rhs);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_binary_visitor (s_past_node_t* node,
		     past_fun_t prefix,
		     void* prefix_data,
		     past_fun_t suffix,
		     void* suffix_data)
{
  assert (past_node_is_a (node, past_binary));
  PAST_DECLARE_TYPED(binary, r, node);
  past_visitor (r->lhs, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->rhs, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(binary);

#define declare_bin_free_ops(type)					\
  void past_##type##_free (s_past_node_t* node)				\
   { past_binary_free (node); }						\
  static void past_##type##_visitor (s_past_node_t* node,		\
				     past_fun_t prefix,			\
				     void* prefix_data,			\
				     past_fun_t suffix,			\
				     void* suffix_data)			\
   { past_binary_visitor (node, prefix, prefix_data, suffix, suffix_data); } \
  PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_2(type, binary);

declare_bin_free_ops(add);
declare_bin_free_ops(sub);
declare_bin_free_ops(mul);
declare_bin_free_ops(div);
declare_bin_free_ops(mod);
declare_bin_free_ops(min);
declare_bin_free_ops(max);
declare_bin_free_ops(ceild);
declare_bin_free_ops(floord);
declare_bin_free_ops(and);
declare_bin_free_ops(or);
declare_bin_free_ops(equal);
declare_bin_free_ops(notequal);
declare_bin_free_ops(assign);
declare_bin_free_ops(geq);
declare_bin_free_ops(leq);
declare_bin_free_ops(gt);
declare_bin_free_ops(lt);
declare_bin_free_ops(arrayref);
declare_bin_free_ops(xor);
declare_bin_free_ops(band);
declare_bin_free_ops(bor);
declare_bin_free_ops(lshift);
declare_bin_free_ops(rshift);
declare_bin_free_ops(addassign);
declare_bin_free_ops(subassign);
declare_bin_free_ops(mulassign);
declare_bin_free_ops(divassign);
declare_bin_free_ops(modassign);
declare_bin_free_ops(andassign);
declare_bin_free_ops(orassign);
declare_bin_free_ops(xorassign);
declare_bin_free_ops(lshiftassign);
declare_bin_free_ops(rshiftassign);
declare_bin_free_ops(dot);
declare_bin_free_ops(arrow);


static s_past_node_t*
past_binary_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_binary));
  PAST_DECLARE_TYPED(binary, b, node);
  s_past_node_t* ret =
    past_node_binary_create (node->type, past_clone (b->lhs),
			     past_clone (b->rhs));
  PAST_DECLARE_TYPED(binary, pb, ret);
  pb->op_type = b->op_type;
  return ret;
}

s_past_binary_t* past_binary_create (cs_past_node_type_t* type,
				     s_past_node_t* lhs,
				     s_past_node_t* rhs)
{
  s_past_binary_t* n = XMALLOC(s_past_binary_t, 1);
  if (type)
    past_node_init (&(n->node), type, past_binary_visitor, past_binary_clone);
  else
    past_node_init (&(n->node), past_binary, past_binary_visitor,
		    past_binary_clone);
  n->lhs = lhs;
  n->rhs = rhs;
  n->op_type = e_past_unknown_op_type;
  set_parent_sibling_nodes (n->lhs, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->rhs, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_binary_create (cs_past_node_type_t* type,
					s_past_node_t* lhs,
					s_past_node_t* rhs)
{
  return &past_binary_create (type, lhs, rhs)->node;
}


/**
 * past_unary
 *
 *
 */
void
past_unary_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_unary));
  s_past_unary_t* pf = (s_past_unary_t*) node;
  past_deep_free (pf->expr);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_unary_visitor (s_past_node_t* node,
		    past_fun_t prefix,
		    void* prefix_data,
		    past_fun_t suffix,
		    void* suffix_data)
{
  assert (past_node_is_a (node, past_unary));
  PAST_DECLARE_TYPED(unary, r, node);
  past_visitor (r->expr, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(unary);

#define declare_un_free_ops(type)					\
  void past_##type##_free (s_past_node_t* node)				\
    { past_unary_free (node); }						\
  static void past_##type##_visitor (s_past_node_t* node,		\
				     past_fun_t prefix,			\
				     void* prefix_data,			\
				     past_fun_t suffix,			\
				     void* suffix_data)			\
   { past_unary_visitor (node, prefix, prefix_data, suffix, suffix_data); } \
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_2(type, unary);

declare_un_free_ops(inc_before);
declare_un_free_ops(inc_after);
declare_un_free_ops(dec_before);
declare_un_free_ops(dec_after);
declare_un_free_ops(unaminus);
declare_un_free_ops(unaplus);
declare_un_free_ops(opsizeof);
declare_un_free_ops(addressof);
declare_un_free_ops(derefof);
declare_un_free_ops(referencetype);
declare_un_free_ops(pointertype);
declare_un_free_ops(bcomp);
declare_un_free_ops(round);
declare_un_free_ops(floor);
declare_un_free_ops(ceil);
declare_un_free_ops(sqrt);
declare_un_free_ops(not);


static s_past_node_t*
past_unary_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_unary));
  PAST_DECLARE_TYPED(unary, u, node);
  s_past_node_t* ret =
    past_node_unary_create (node->type, past_clone (u->expr));
  PAST_DECLARE_TYPED(unary, pu, ret);
  pu->op_type = u->op_type;
  return ret;
}

s_past_unary_t* past_unary_create (cs_past_node_type_t* type,
				   s_past_node_t* expr)
{
  s_past_unary_t* n = XMALLOC(s_past_unary_t, 1);
  if (type)
    past_node_init (&(n->node), type, past_unary_visitor, past_unary_clone);
  else
    past_node_init (&(n->node), past_unary, past_unary_visitor,
		    past_unary_clone);
  n->expr = expr;
  n->op_type = e_past_unknown_op_type;
  set_parent_sibling_nodes (n->expr, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_unary_create (cs_past_node_type_t* type,
				       s_past_node_t* expr)
{
  return &past_unary_create (type, expr)->node;
}


/**
 * past_block
 *
 *
 */
void
past_block_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_block));
  s_past_block_t* pf = (s_past_block_t*) node;
  past_deep_free (pf->body);
  //symbol_table_free (pf->symboltable);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_block_visitor (s_past_node_t* node,
		    past_fun_t prefix,
		    void* prefix_data,
		    past_fun_t suffix,
		    void* suffix_data)
{
  assert (past_node_is_a (node, past_block));
  PAST_DECLARE_TYPED(block, r, node);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(block);

static s_past_node_t*
past_block_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_block));
  PAST_DECLARE_TYPED(block, b, node);
  s_past_node_t* ret = past_node_block_create (past_clone (b->body));
  PAST_DECLARE_TYPED(block, pb, ret);
  pb->symboltable = b->symboltable;
  pb->artificial_bb = b->artificial_bb;
  return ret;
}

s_past_block_t* past_block_create (s_past_node_t* body)
{
  s_past_block_t* n = XMALLOC(s_past_block_t, 1);
  past_node_init (&(n->node), past_block, past_block_visitor, past_block_clone);
  n->body = body;
  n->symboltable = NULL;
  n->artificial_bb = 0;
  set_parent_sibling_nodes (n->body, (s_past_node_t*) n);
  return n;
}

s_past_node_t* past_node_block_create (s_past_node_t* body)
{
  return &past_block_create (body)->node;
}


/**
 * past_if
 *
 *
 */
void
past_if_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_if));
  s_past_if_t* pf = (s_past_if_t*) node;
  past_deep_free (pf->condition);
  past_deep_free (pf->then_clause);
  past_deep_free (pf->else_clause);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_if_visitor (s_past_node_t* node,
		 past_fun_t prefix,
		 void* prefix_data,
		 past_fun_t suffix,
		 void* suffix_data)
{
  assert (past_node_is_a (node, past_if));
  PAST_DECLARE_TYPED(if, r, node);
  past_visitor (r->condition, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->then_clause, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->else_clause, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(if);

static s_past_node_t*
past_if_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_if));
  PAST_DECLARE_TYPED(if, b, node);
  return past_node_if_create (past_clone (b->condition),
			      past_clone (b->then_clause),
			      past_clone (b->else_clause));
}

s_past_if_t* past_if_create (s_past_node_t* cond,
			     s_past_node_t* then_clause,
			     s_past_node_t* else_clause)
{
  s_past_if_t* n = XMALLOC(s_past_if_t, 1);
  past_node_init (&(n->node), past_if, past_if_visitor, past_if_clone);
  n->condition = cond;
  n->then_clause = then_clause;
  n->else_clause = else_clause;
  set_parent_sibling_nodes (n->condition, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->then_clause, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->else_clause, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_if_create (s_past_node_t* cond,
				    s_past_node_t* then_clause,
				    s_past_node_t* else_clause)
{
  return &past_if_create (cond, then_clause, else_clause)->node;
}


/**
 * past_affineguard
 *
 *
 */
void
past_affineguard_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_affineguard));
  s_past_affineguard_t* pf = (s_past_affineguard_t*) node;
  past_deep_free (pf->condition);
  past_deep_free (pf->then_clause);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_affineguard_visitor (s_past_node_t* node,
			  past_fun_t prefix,
			  void* prefix_data,
			  past_fun_t suffix,
			  void* suffix_data)
{
  assert (past_node_is_a (node, past_affineguard));
  PAST_DECLARE_TYPED(affineguard, r, node);
  past_visitor (r->condition, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->then_clause, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(affineguard);

static s_past_node_t*
past_affineguard_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_affineguard));
  PAST_DECLARE_TYPED(affineguard, b, node);
  return past_node_affineguard_create (past_clone (b->condition),
				       past_clone (b->then_clause));
}

s_past_affineguard_t* past_affineguard_create (s_past_node_t* cond,
					       s_past_node_t* then_clause)
{
  s_past_affineguard_t* n = XMALLOC(s_past_affineguard_t, 1);
  past_node_init (&(n->node), past_affineguard, past_affineguard_visitor,
		  past_affineguard_clone);
  n->condition = cond;
  n->then_clause = then_clause;
  set_parent_sibling_nodes (n->condition, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->then_clause, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_affineguard_create (s_past_node_t* cond,
					     s_past_node_t* then_clause)
{
  return &past_affineguard_create (cond, then_clause)->node;
}


/**
 * past_cloogstmt
 *
 *
 */
void
past_cloogstmt_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_cloogstmt));
  s_past_cloogstmt_t* pf = (s_past_cloogstmt_t*) node;
  if (pf->stmt_name)
    XFREE(pf->stmt_name);
  past_deep_free (pf->substitutions);
  past_deep_free (pf->references);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_cloogstmt_visitor (s_past_node_t* node,
			 past_fun_t prefix,
			 void* prefix_data,
			 past_fun_t suffix,
			 void* suffix_data)
{
  assert (past_node_is_a (node, past_cloogstmt));
  s_past_cloogstmt_t* pf = (s_past_cloogstmt_t*) node;
  past_visitor (pf->substitutions, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(cloogstmt);

static s_past_node_t*
past_cloogstmt_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_cloogstmt));
  PAST_DECLARE_TYPED(cloogstmt, b, node);
  s_past_node_t* ret =
    past_node_cloogstmt_create (b->cloogdomain, b->cloogstatement,
				(s_past_varref_t*)
				b->stmt_name->node.clone
				(&(b->stmt_name->node)),
				b->stmt_number,
				past_clone (b->substitutions));
  return ret;
}

s_past_cloogstmt_t* past_cloogstmt_create (void* cloogdomain,
					   void* cloogstatement,
					   s_past_varref_t* stmt_name,
					   int stmt_number,
					   s_past_node_t* substitutions)
{
  s_past_cloogstmt_t* n = XMALLOC(s_past_cloogstmt_t, 1);
  past_node_init (&(n->node), past_cloogstmt, past_cloogstmt_visitor,
		  past_cloogstmt_clone);
  n->cloogdomain = cloogdomain;
  n->cloogstatement = cloogstatement;
  n->stmt_name = stmt_name;
  n->stmt_number = stmt_number;
  n->substitutions = substitutions;
  n->references = NULL;
  set_parent_sibling_nodes (n->substitutions, (s_past_node_t*) n);
  set_parent_sibling_nodes ((s_past_node_t*) n->stmt_name, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_cloogstmt_create (void* cloogdomain,
					   void* cloogstatement,
					   s_past_varref_t* stmt_name,
					   int stmt_number,
					   s_past_node_t* substitutions)
{
  return &past_cloogstmt_create (cloogdomain, cloogstatement, stmt_name,
				 stmt_number, substitutions)->node;
}


/**
 * past_statement
 *
 *
 */
void
past_statement_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_statement));
  s_past_statement_t* pf = (s_past_statement_t*) node;
  past_deep_free (pf->body);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_statement_visitor (s_past_node_t* node,
			past_fun_t prefix,
			void* prefix_data,
			past_fun_t suffix,
			void* suffix_data)
{
  assert (past_node_is_a (node, past_statement));
  PAST_DECLARE_TYPED(statement, r, node);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(statement);

static s_past_node_t*
past_statement_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_statement));
  PAST_DECLARE_TYPED(statement, b, node);
  return past_node_statement_create (past_clone (b->body));
}

s_past_statement_t* past_statement_create (s_past_node_t* body)
{
  s_past_statement_t* n = XMALLOC(s_past_statement_t, 1);
  past_node_init (&(n->node), past_statement, past_statement_visitor,
		  past_statement_clone);
  n->body = body;
  set_parent_sibling_nodes (n->body, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_statement_create (s_past_node_t* body)
{
  return &past_statement_create (body)->node;
}


/**
 * past_funcall
 *
 *
 */
void
past_funcall_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_funcall));
  s_past_funcall_t* pf = (s_past_funcall_t*) node;
  past_deep_free (pf->name);
  past_deep_free (pf->args_list);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_funcall_visitor (s_past_node_t* node,
		      past_fun_t prefix,
		      void* prefix_data,
		      past_fun_t suffix,
		      void* suffix_data)
{
  assert (past_node_is_a (node, past_funcall));
  PAST_DECLARE_TYPED(funcall, r, node);
  // Arguments are visited first, to reflect 3-address code exec. order.
  past_visitor (r->args_list, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->name, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(funcall);

static s_past_node_t*
past_funcall_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_funcall));
  PAST_DECLARE_TYPED(funcall, b, node);
  return past_node_funcall_create (past_clone (b->name),
				   past_clone (b->args_list));
}

s_past_funcall_t* past_funcall_create (s_past_node_t* name,
				       s_past_node_t* args_list)
{
  s_past_funcall_t* n = XMALLOC(s_past_funcall_t, 1);
  past_node_init (&(n->node), past_funcall, past_funcall_visitor,
		  past_funcall_clone);
  n->name = name;
  n->args_list = args_list;
  n->is_pure_function = 0;
  set_parent_sibling_nodes (n->name, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->args_list, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_funcall_create (s_past_node_t* name,
					 s_past_node_t* args_list)
{
  return &past_funcall_create (name, args_list)->node;
}


/**
 * past_fundecl
 *
 *
 */
void
past_fundecl_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_fundecl));
  s_past_fundecl_t* pf = (s_past_fundecl_t*) node;
  past_deep_free (pf->name);
  past_deep_free (pf->type);
  past_deep_free (pf->args_list);
  past_deep_free (pf->body);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_fundecl_visitor (s_past_node_t* node,
		      past_fun_t prefix,
		      void* prefix_data,
		      past_fun_t suffix,
		      void* suffix_data)
{
  assert (past_node_is_a (node, past_fundecl));
  PAST_DECLARE_TYPED(fundecl, r, node);
  past_visitor (r->type, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->name, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->args_list, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->body, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(fundecl);

static s_past_node_t*
past_fundecl_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_fundecl));
  PAST_DECLARE_TYPED(fundecl, b, node);
  return past_node_fundecl_create (past_clone (b->type),
				   past_clone (b->name),
				   past_clone (b->args_list),
				   past_clone (b->body));
}

s_past_fundecl_t* past_fundecl_create (s_past_node_t* type,
				       s_past_node_t* name,
				       s_past_node_t* args_list,
				       s_past_node_t* body)
{
  s_past_fundecl_t* n = XMALLOC(s_past_fundecl_t, 1);
  past_node_init (&(n->node), past_fundecl, past_fundecl_visitor,
		  past_fundecl_clone);
  n->name = name;
  n->type = type;
  n->args_list = args_list;
  n->body = body;

  return n;
}

s_past_node_t* past_node_fundecl_create (s_past_node_t* type,
					 s_past_node_t* name,
					 s_past_node_t* args_list,
					 s_past_node_t* body)
{
  return &past_fundecl_create (type, name, args_list, body)->node;
}


/**
 * past_vardecl
 *
 *
 */
void
past_vardecl_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_vardecl));
  s_past_vardecl_t* pf = (s_past_vardecl_t*) node;
  past_deep_free ((s_past_node_t*) pf->name);
  past_deep_free ((s_past_node_t*) pf->type);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_vardecl_visitor (s_past_node_t* node,
		      past_fun_t prefix,
		      void* prefix_data,
		      past_fun_t suffix,
		      void* suffix_data)
{
  assert (past_node_is_a (node, past_vardecl));
  PAST_DECLARE_TYPED(vardecl, r, node);
  // Do not visit the 'type' of the cast if it is of node type
  // 'past_type', just the variable. Otherwise visit it.
  if (! past_node_is_a (r->type, past_type))
    past_visitor (r->type, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->name, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(vardecl);

static s_past_node_t*
past_vardecl_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_vardecl));
  PAST_DECLARE_TYPED(vardecl, b, node);
  return past_node_vardecl_create (past_clone (b->type), past_clone (b->name));
}

s_past_vardecl_t* past_vardecl_create (s_past_node_t* type,
				       s_past_node_t* name)
{
  s_past_vardecl_t* n = XMALLOC(s_past_vardecl_t, 1);
  past_node_init (&(n->node), past_vardecl, past_vardecl_visitor,
		  past_vardecl_clone);
  n->name = name;
  n->type = type;

  set_parent_sibling_nodes (n->name, (s_past_node_t*) n);
  set_parent_sibling_nodes (n->type, (s_past_node_t*) n);

  return n;
}

s_past_node_t* past_node_vardecl_create (s_past_node_t* type,
					 s_past_node_t* name)
{
  return &past_vardecl_create (type, name)->node;
}



/**
 * past_ternary_cond
 *
 *
 */
void
past_ternary_cond_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_ternary_cond));
  s_past_ternary_cond_t* pf = (s_past_ternary_cond_t*) node;
  past_deep_free ((s_past_node_t*) pf->cond);
  past_deep_free ((s_past_node_t*) pf->true_clause);
  past_deep_free ((s_past_node_t*) pf->false_clause);
  past_node_freeattr (node);
  XFREE(pf);
}
static void
past_ternary_cond_visitor (s_past_node_t* node,
			   past_fun_t prefix,
			   void* prefix_data,
			   past_fun_t suffix,
			   void* suffix_data)
{
  assert (past_node_is_a (node, past_ternary_cond));
  PAST_DECLARE_TYPED(ternary_cond, r, node);
  past_visitor (r->cond, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->true_clause, prefix, prefix_data, suffix, suffix_data);
  past_visitor (r->false_clause, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(ternary_cond);

static s_past_node_t*
past_ternary_cond_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_ternary_cond));
  PAST_DECLARE_TYPED(ternary_cond, b, node);
  return past_node_ternary_cond_create (past_clone (b->cond),
					past_clone (b->true_clause),
					past_clone (b->false_clause));
}

s_past_ternary_cond_t* past_ternary_cond_create (s_past_node_t* cond,
						 s_past_node_t* true_clause,
						 s_past_node_t* false_clause)
{
  s_past_ternary_cond_t* n = XMALLOC(s_past_ternary_cond_t, 1);
  past_node_init (&(n->node), past_ternary_cond, past_ternary_cond_visitor,
		  past_ternary_cond_clone);
  n->cond = cond;
  n->true_clause = true_clause;
  n->false_clause = false_clause;

  return n;
}


s_past_node_t* past_node_ternary_cond_create (s_past_node_t* cond,
					      s_past_node_t* true_clause,
					      s_past_node_t* false_clause)
{
  return &(past_ternary_cond_create (cond, true_clause, false_clause)->node);
}


/**
 * past_cast
 *
 *
 */
void
past_cast_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_cast));
  s_past_cast_t* pc = (s_past_cast_t*) node;
  past_deep_free ((s_past_node_t*) pc->type);
  past_deep_free ((s_past_node_t*) pc->expr);
  past_node_freeattr (node);
  XFREE(pc);
}

static void
past_cast_visitor (s_past_node_t* node,
		    past_fun_t prefix,
		    void* prefix_data,
		    past_fun_t suffix,
		    void* suffix_data)
{
  assert (past_node_is_a (node, past_cast));
  PAST_DECLARE_TYPED(cast, c, node);
  // Do not visit the 'type' of the cast if it is of node type
  // 'past_type', just the expression casted. Otherwise visit it.
  if (! past_node_is_a (c->type, past_type))
    past_visitor (c->type, prefix, prefix_data, suffix, suffix_data);
  past_visitor (c->expr, prefix, prefix_data, suffix, suffix_data);
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(cast);

static s_past_node_t*
past_cast_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_cast));
  PAST_DECLARE_TYPED(cast, c, node);
  return past_node_cast_create (past_clone (c->type), past_clone (c->expr));
}

s_past_cast_t* past_cast_create (s_past_node_t* type, s_past_node_t* expr)
{
  s_past_cast_t* n = XMALLOC(s_past_cast_t, 1);
  past_node_init (&(n->node), past_cast, past_cast_visitor, past_cast_clone);
  n->type = type;
  n->expr = expr;
  return n;
}

s_past_node_t* past_node_cast_create (s_past_node_t* type,
				      s_past_node_t *expr)
{
  return &past_cast_create (type, expr)->node;
}



/**
 * past_generic
 *
 *
 */
void
past_generic_free (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_generic));
  s_past_generic_t* pc = (s_past_generic_t*) node;
  if (pc->char_data)
    XFREE(pc->char_data);
  past_node_freeattr (node);
  XFREE(pc);
}

static void
past_generic_visitor (s_past_node_t* node,
		      past_fun_t prefix,
		      void* prefix_data,
		      past_fun_t suffix,
		      void* suffix_data)
{
  assert (past_node_is_a (node, past_generic));
}
PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(generic);

static s_past_node_t*
past_generic_clone (s_past_node_t* node)
{
  assert (past_node_is_a (node, past_generic));
  PAST_DECLARE_TYPED(generic, c, node);
  s_past_generic_t* g = past_generic_create (strdup (c->char_data),
					     c->ptr_data);
  g->usr = c->usr;
  return &(g->node);
}

s_past_generic_t* past_generic_create (char* char_data, void* ptr_data)
{
  s_past_generic_t* n = XMALLOC(s_past_generic_t, 1);
  past_node_init (&(n->node), past_generic, past_generic_visitor, past_generic_clone);
  n->char_data = char_data;
  n->ptr_data = ptr_data;
  return n;
}

s_past_node_t* past_node_generic_create (char* char_data, void* ptr_data)
{
  return &past_generic_create (char_data, ptr_data)->node;
}



/******************************************************************************/
/******************************************************************************/
/******************************************************************************/

/**
 * cloning a node/tree (deep copy).
 *
 */
s_past_node_t* past_clone (s_past_node_t* s)
{
  if (! s)
    return NULL;

  s_past_node_t* ret = NULL;
  s_past_node_t* val;
  s_past_node_t** stmt = &val;

  for ( ; s; s = s->next)
    {
      *stmt = s->clone (s);
      if (ret == NULL)
	ret = *stmt;
      stmt = &((*stmt)->next);
    }
  *stmt = NULL;

  return ret;
}


/**
 *
 * Free node/tree (deep free).
 *
 *
 */
void
past_deep_free (s_past_node_t* node)
{
  s_past_node_t* next;
  while (node)
    {
      next = node->next;
      assert (node->type);
      node->type->freefun[0] (node);
      node = next;
    }
}


/**
 * Shallow copy.
 *
 */
s_past_node_t* past_copy (s_past_node_t* node)
{
  /// FIXME: Implement this.
  assert (0);
  return node;
}



/**
 * Set parent pointer for the full tree.
 *
 */
static
void set_parent_pref (s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_binary))
    {
      PAST_DECLARE_TYPED(binary, n, node);
      assert (n->lhs);
      assert (n->rhs);
      set_parent_sibling_nodes (n->lhs, node);
      set_parent_sibling_nodes (n->rhs, node);
    }
  if (past_node_is_a (node, past_ternary))
    {
      PAST_DECLARE_TYPED(ternary, n, node);
      assert (n->arg1);
      assert (n->arg2);
      assert (n->arg3);
      set_parent_sibling_nodes (n->arg1, node);
      set_parent_sibling_nodes (n->arg2, node);
      set_parent_sibling_nodes (n->arg3, node);
    }
  else if (past_node_is_a (node, past_unary))
    {
      PAST_DECLARE_TYPED(unary, n, node);
      assert (n->expr);
      set_parent_sibling_nodes (n->expr, node);
    }
  else if (past_node_is_a (node, past_for))
    {
      PAST_DECLARE_TYPED(for, n, node);
      if (n->body)
	set_parent_sibling_nodes (n->body, node);
      if (n->init)
	set_parent_sibling_nodes (n->init, node);
      if (n->test)
	set_parent_sibling_nodes (n->test, node);
      if (n->increment)
	set_parent_sibling_nodes (n->increment, node);
    }
  else if (past_node_is_a (node, past_if))
    {
      PAST_DECLARE_TYPED(if, n, node);
      if (n->condition)
	set_parent_sibling_nodes (n->condition, node);
      if (n->then_clause)
	set_parent_sibling_nodes (n->then_clause, node);
      if (n->else_clause)
	set_parent_sibling_nodes (n->else_clause, node);
    }
  else if (past_node_is_a (node, past_affineguard))
    {
      PAST_DECLARE_TYPED(affineguard, n, node);
      if (n->condition)
	set_parent_sibling_nodes (n->condition, node);
      if (n->then_clause)
	set_parent_sibling_nodes (n->then_clause, node);
    }
  else if (past_node_is_a (node, past_block))
    {
      PAST_DECLARE_TYPED(block, n, node);
      if (n->body)
	set_parent_sibling_nodes (n->body, node);
    }
  else if (past_node_is_a (node, past_type))
    {
      PAST_DECLARE_TYPED(type, n, node);
      if (n->texpr)
	set_parent_sibling_nodes (n->texpr, node);
    }
  else if (past_node_is_a (node, past_root))
    {
      PAST_DECLARE_TYPED(root, n, node);
      if (n->body)
	set_parent_sibling_nodes (n->body, node);
      node->parent = NULL;
    }
  else if (past_node_is_a (node, past_statement))
    {
      PAST_DECLARE_TYPED(statement, n, node);
      if (n->body)
	set_parent_sibling_nodes (n->body, node);
    }
  else if (past_node_is_a (node, past_funcall))
    {
      PAST_DECLARE_TYPED(funcall, n, node);
      if (n->name)
	set_parent_sibling_nodes (n->name, node);
      if (n->args_list)
	set_parent_sibling_nodes (n->args_list, node);
    }
  else if (past_node_is_a (node, past_fundecl))
    {
      PAST_DECLARE_TYPED(fundecl, n, node);
      if (n->type)
	set_parent_sibling_nodes (n->type, node);
      if (n->name)
	set_parent_sibling_nodes (n->name, node);
      if (n->args_list)
	set_parent_sibling_nodes (n->args_list, node);
      if (n->body)
	set_parent_sibling_nodes (n->body, node);
    }
  else if (past_node_is_a (node, past_vardecl))
    {
      PAST_DECLARE_TYPED(vardecl, n, node);
      if (n->type)
	set_parent_sibling_nodes (n->type, node);
      if (n->name)
	set_parent_sibling_nodes (n->name, node);
    }
  else if (past_node_is_a (node, past_ternary_cond))
    {
      PAST_DECLARE_TYPED(ternary_cond, n, node);
      if (n->cond)
	set_parent_sibling_nodes (n->cond, node);
      if (n->true_clause)
	set_parent_sibling_nodes (n->true_clause, node);
      if (n->false_clause)
	set_parent_sibling_nodes (n->false_clause, node);
    }
  else if (past_node_is_a (node, past_cast))
    {
      PAST_DECLARE_TYPED(cast, n, node);
      if (n->type)
	set_parent_sibling_nodes (n->type, node);
      if (n->expr)
	set_parent_sibling_nodes (n->expr, node);
    }
  else if (past_node_is_a (node, past_cloogstmt))
    {
      PAST_DECLARE_TYPED(cloogstmt, n, node);
      if (n->substitutions)
	set_parent_sibling_nodes (n->substitutions, node);
      if (n->references)
	set_parent_sibling_nodes (n->references, node);
      if (n->stmt_name)
	set_parent_sibling_nodes ((s_past_node_t*)n->stmt_name, node);
    }
}

void past_set_parent (s_past_node_t* root)
{
  past_visitor (root, set_parent_pref, NULL, NULL, NULL);
}


/**
 * Generic visitor.
 *
 */
void past_visitor (s_past_node_t* node,
		   past_fun_t prefix,
		   void* prefix_data,
		   past_fun_t suffix,
		   void* suffix_data)
{
  while (node)
    {
      if (prefix)
	prefix (node, prefix_data);
      node->visitor (node,
		     prefix, prefix_data,
		     suffix, suffix_data);
      // Allow for destructive postfix.
      s_past_node_t* next = node->next;
      if (suffix)
	suffix (node, suffix_data);
      node = next;
    }
}

static
void
find_node_in_siblings (s_past_node_t** node,
		       s_past_node_t* tofind,
		       s_past_node_t** dest)
{
  while (*node)
    {
      if (*node == tofind)
	{
	  *dest = (s_past_node_t*) node;
	  return;
	}
      node = &((*node)->next);
    }
}

static
void find_parent_ptr (s_past_node_t* node, void* data)
{
  s_past_node_t** args = (s_past_node_t**) data;
  if (past_node_is_a (node, past_ternary))
    {
      PAST_DECLARE_TYPED(ternary, n, node);
      assert (n->arg1);
      assert (n->arg2);
      assert (n->arg3);
      find_node_in_siblings (&(n->arg1), args[0], &(args[1]));
      find_node_in_siblings (&(n->arg2), args[0], &(args[1]));
      find_node_in_siblings (&(n->arg3), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_binary))
    {
      PAST_DECLARE_TYPED(binary, n, node);
      assert (n->lhs);
      assert (n->rhs);
      find_node_in_siblings (&(n->lhs), args[0], &(args[1]));
      find_node_in_siblings (&(n->rhs), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_unary))
    {
      PAST_DECLARE_TYPED(unary, n, node);
      assert (n->expr);
      find_node_in_siblings (&(n->expr), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_for))
    {
      PAST_DECLARE_TYPED(for, n, node);
      if (n->body)
	find_node_in_siblings (&(n->body), args[0], &(args[1]));
      if (n->init)
	find_node_in_siblings (&(n->init), args[0], &(args[1]));
      if (n->test)
	find_node_in_siblings (&(n->test), args[0], &(args[1]));
      if (n->increment)
	find_node_in_siblings (&(n->increment), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_if))
    {
      PAST_DECLARE_TYPED(if, n, node);
      if (n->condition)
	find_node_in_siblings (&(n->condition), args[0], &(args[1]));
      if (n->then_clause)
	find_node_in_siblings (&(n->then_clause), args[0], &(args[1]));
      if (n->else_clause)
	find_node_in_siblings (&(n->else_clause), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_affineguard))
    {
      PAST_DECLARE_TYPED(affineguard, n, node);
      if (n->condition)
	find_node_in_siblings (&(n->condition), args[0], &(args[1]));
      if (n->then_clause)
	find_node_in_siblings (&(n->then_clause), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_block))
    {
      PAST_DECLARE_TYPED(block, n, node);
      if (n->body)
	find_node_in_siblings (&(n->body), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_root))
    {
      PAST_DECLARE_TYPED(root, n, node);
      if (n->body)
	find_node_in_siblings (&(n->body), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_statement))
    {
      PAST_DECLARE_TYPED(statement, n, node);
      if (n->body)
	find_node_in_siblings (&(n->body), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_type))
    {
      PAST_DECLARE_TYPED(type, n, node);
      if (n->texpr)
	find_node_in_siblings (&(n->texpr), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_funcall))
    {
      PAST_DECLARE_TYPED(funcall, n, node);
      if (n->name && ((s_past_node_t*)(n->name)) == args[0])
	args[1] = (s_past_node_t*)&(n->name);
      if (n->args_list)
	find_node_in_siblings (&(n->args_list), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_fundecl))
    {
      PAST_DECLARE_TYPED(fundecl, n, node);
      if (n->name && ((s_past_node_t*)(n->name)) == args[0])
	args[1] = (s_past_node_t*)&(n->name);
      if (n->type && ((s_past_node_t*)(n->type)) == args[0])
	args[1] = (s_past_node_t*)&(n->type);
      if (n->args_list)
	find_node_in_siblings (&(n->args_list), args[0], &(args[1]));
      if (n->body)
	find_node_in_siblings (&(n->body), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_vardecl))
    {
      PAST_DECLARE_TYPED(vardecl, n, node);
      if (n->type)
	find_node_in_siblings (&(n->type), args[0], &(args[1]));
      if (n->name && ((s_past_node_t*)(n->name)) == args[0])
	args[1] = (s_past_node_t*)&(n->name);
    }
  else if (past_node_is_a (node, past_cloogstmt))
    {
      PAST_DECLARE_TYPED(cloogstmt, n, node);
      if (n->substitutions)
	find_node_in_siblings (&(n->substitutions), args[0], &(args[1]));
      if (n->references)
	find_node_in_siblings (&(n->references), args[0], &(args[1]));
      if (n->stmt_name && ((s_past_node_t*)(n->stmt_name)) == args[0])
	args[1] = (s_past_node_t*)&(n->stmt_name);
    }
  else if (past_node_is_a (node, past_ternary_cond))
    {
      PAST_DECLARE_TYPED(ternary_cond, n, node);
      if (n->cond)
	find_node_in_siblings (&(n->cond), args[0], &(args[1]));
      if (n->true_clause)
	find_node_in_siblings (&(n->true_clause), args[0], &(args[1]));
      if (n->false_clause)
	find_node_in_siblings (&(n->false_clause), args[0], &(args[1]));
    }
  else if (past_node_is_a (node, past_cast))
    {
      PAST_DECLARE_TYPED(cast, n, node);
      if (n->type)
	find_node_in_siblings (&(n->type), args[0], &(args[1]));
      if (n->expr)
	find_node_in_siblings (&(n->expr), args[0], &(args[1]));
    }
}


s_past_node_t**
past_node_get_addr (s_past_node_t* node)
{
  if (node->parent == NULL || past_node_is_a (node, past_root))
    return NULL;
  void* data[2];
  data[0] = node;
  data[1] = NULL;
  past_visitor (node->parent, find_parent_ptr, (void*) data, NULL, NULL);
  return (s_past_node_t**) data[1];
}

void past_replace_node (s_past_node_t* old,
			s_past_node_t* new)
{
  if (old->parent == NULL || old == new || past_node_is_a (old, past_root))
    return;

  s_past_node_t* parent = old->parent;
  s_past_node_t* next = old->next;
  s_past_node_t** addr = past_node_get_addr (old);
  assert (addr);
  *addr = new;
  if (new)
    {
      new->parent = parent;
      // Somehow the user decided to set up the siblings himself.
      if (new->next == next)
      	return;
      while (new->next)
      	new = new->next;
      new->next = next;
    }
}


s_past_node_t*
past_for_to_parfor (s_past_node_t* node)
{
  if (past_node_is_a (node, past_parfor))
    return node;
  if (past_node_is_a (node, past_for))
    {
      PAST_DECLARE_TYPED(for, pf, node);
      s_past_parfor_t* newpf = past_parfor_create
	(pf->init, pf->test, pf->iterator, pf->increment, pf->body);
      newpf->usr = pf->usr;
      newpf->type = pf->type;
      newpf->property = pf->property;
      past_replace_node (node, (s_past_node_t*) newpf);
      newpf->node.next = node->next;
      XFREE(node);
      return (s_past_node_t*)newpf;
    }

  return node;
}


void past_append_last (s_past_node_t* node,
		       s_past_node_t* toappend)
{
  if (! node || !toappend)
    return;
  while (node->next)
    node = node->next;
  node->next = toappend;
  toappend->parent = node->parent;
}


void past_append_first (s_past_node_t* node,
			s_past_node_t* toappend)
{
  if (! node || !toappend)
    return;

  s_past_node_t* tmp = toappend;
  while (tmp->next)
    tmp = tmp->next;
  tmp->next = node->next;
  node->next = toappend;
  toappend->parent = node->parent;
}


void past_prepend (s_past_node_t* node,
		   s_past_node_t* toprepend)
{
  if (! node || !toprepend)
    return;

  s_past_node_t** node_addr = past_node_get_addr (node);
  toprepend->parent = node->parent;
  s_past_node_t* tmp = toprepend;
  while (tmp->next)
    tmp = tmp->next;
  tmp->next = node;
  *node_addr = toprepend;
}


/**
 * Remove the subtree 'tree' from the full tree. Does not delete/deep
 * free 'tree'.
 * Note: if 'tree' is a past_root, no action is performed.
 * Return: 1 if the node was found and successfully removed, 0 otherwise.
 */
int past_remove_subtree (s_past_node_t* tree)
{
  if (! tree || past_node_is_a (tree, past_root))
    return 0;
  s_past_node_t** node_addr = past_node_get_addr (tree);
  if (! node_addr)
    return 0;
  *node_addr = (*node_addr)->next;
  return 1;
}
