/*
 * error.h: This file is part of the PAST project.
 * 
 * PAST: the PoCC Abstract Syntax Tree
 * 
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * 
 */
#ifndef PAST_ERROR_H
# define PAST_ERROR_H 

#include <past/common.h>

BEGIN_C_DECLS

extern const char *program_name;
extern void	set_program_name (const char *argv0);

extern void	past_warning (const char *message);
extern void	past_error (const char *message);
extern void	past_fatal (const char *message);

END_C_DECLS


#endif // PAST_ERROR_H
