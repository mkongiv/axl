/*
 * past.h: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#ifndef PAST_PAST_H
# define PAST_PAST_H

# include <past/common.h>
# include <past/past_node.h>
# include <past/symbols.h>

BEGIN_C_DECLS


/**
 *
 *
 */
struct past_root_t
{
  s_past_node_t		node;
  //
  s_symbol_table_t*    	symboltable;
  s_past_node_t*	body;
};
typedef struct past_root_t s_past_root_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(root);


/**
 * Variable reference.
 *
 */
struct past_varref_t
{
  s_past_node_t		node;
  //
  s_symbol_t*		symbol;
  // User field, not maintained.
  void*			usr;
};
typedef struct past_varref_t s_past_varref_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(varref);


/**
 * Type node, to encapsulate types in variable declarations.
 *
 */
struct past_type_t
{
  s_past_node_t		node;
  //
  s_past_node_t*  	texpr;
  // User field, not maintained.
  void*			usr;
};
typedef struct past_type_t s_past_type_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(type);


/**
 * A few predefined scalar types.
 *
 */
enum e_past_value_type
{
  e_past_value_unknown = 0,
  e_past_value_bool = 1,
  e_past_value_char = 2,
  e_past_value_uchar = 3,
  e_past_value_int = 4,
  e_past_value_uint = 5,
  e_past_value_longint = 6,
  e_past_value_ulongint = 7,
  e_past_value_longlongint = 8,
  e_past_value_ulonglongint = 9,
  e_past_value_float = 10,
  e_past_value_double = 11,
  e_past_value_longdouble = 12,
  e_past_value_longlong = 13,
  e_past_value_ptr = 14,
  e_past_value_hexuint = 15,
  e_past_value_short = 16,
  e_past_value_ushort = 17,
  e_past_value_wchar = 18,
  e_past_value_enum = 19,
};
typedef enum e_past_value_type e_past_value_type_t;

union u_past_value_data
{
  char boolval;
  char charval;
  unsigned char ucharval;
  int intval;
  unsigned int uintval;
  long int longintval;
  unsigned long int ulongintval;
  long long int longlongintval;
  unsigned long long int ulonglongintval;
  float floatval;
  double doubleval;
  long double longdoubleval;
  long long longlongval;
  void* ptrval;
  unsigned int hexuintval;
  short shortval;
  unsigned short ushortval;
  char wcharval;
  int enumval;
};
typedef union u_past_value_data u_past_value_data_t;


/**
 * Store a value, e.g., 42.
 *
 *
 */
struct past_value_t
{
  s_past_node_t		node;
  //
  int			type; // by default, should be of e_past_value_type_t.
  u_past_value_data_t	value;// Use ptrval for user-defined types.
};
typedef struct past_value_t s_past_value_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(value);


/**
 * Store a string littelal, e.g., "42"
 *
 *
 */
struct past_string_t
{
  s_past_node_t		node;
  //
  char*			data;
};
typedef struct past_string_t s_past_string_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(string);


/**
 * Data types, for unary and binary operators.
 *
 */
enum e_past_op_type
{
  e_past_unknown_op_type = 0,
  e_past_scalar_op_type = 1,
  e_past_sse_single_op_type = 2,
  e_past_sse_double_op_type = 3,
  e_past_avx_single_op_type = 4,
  e_past_avx_double_op_type = 5,
  e_past_avx2_single_op_type = 6,
  e_past_avx2_double_op_type = 7
};
typedef enum e_past_op_type e_past_op_type_t;

/**
 * Generic ternary node (not to be confused with ternary operator ? :
 * ), e.g., a Fused-Multiply-Accumulate.
 *
 */
struct past_ternary_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	arg1;
  s_past_node_t*	arg2;
  s_past_node_t*	arg3;
  //
  e_past_op_type_t	op_type;
};
typedef struct past_ternary_t s_past_ternary_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(ternary);
// Following are sub-classes of ternary:
// x + y * z:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(fma);
// x - y * z:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(fms);


/**
 * Generic binary node.
 *
 */
struct past_binary_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	lhs;
  s_past_node_t*	rhs;
  //
  e_past_op_type_t	op_type;
};
typedef struct past_binary_t s_past_binary_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(binary);
// Following are sub-classes of binary:
// x + y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(add);
// x - y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(sub);
// x * y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(mul);
// x / y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(div);
// x % y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(mod);
// min(x,y):
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(min);
// max(x,y):
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(max);
// ceild(x,y) that is ceil(x / y) with y an int value
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(ceild);
// floord(x,y) that is floor(x / y) with y an int value
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(floord);
// x && y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(and);
// x || y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(or);
// x == y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(equal);
// x != y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(notequal);
// x = y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(assign);
// x >= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(geq);
// x <= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(leq);
// x > y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(gt);
// x < y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(lt);
// x[y]:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(arrayref);
// x ^ y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(xor);
// x & y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(band);
// x | y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(bor);
// x << y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(lshift);
// x >> y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(rshift);
// x += y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(addassign);
// x -= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(subassign);
// x *= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(mulassign);
// x /= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(divassign);
// x %= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(modassign);
// x &= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(andassign);
// x |= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(orassign);
// x ^= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(xorassign);
// x <<= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(lshiftassign);
// x >>= y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(rshiftassign);
// x.y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(dot);
// x->y:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(arrow);


/**
 * Generic unary node.
 *
 */
struct past_unary_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	expr;
  //
  e_past_op_type_t	op_type;
};
typedef struct past_unary_t s_past_unary_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(unary);
// Following are sub-classes of unary:
// pre-increment: ++x
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(inc_before);
// post-increment: x++
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(inc_after);
// pre-decrement: --x
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(dec_before);
// post-decrement: x--
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(dec_after);
// Unary minus: -x
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(unaminus);
// sizeof: sizeof(x)
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(opsizeof);
// Unary plus: +x
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(unaplus);
// Address: &x
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(addressof);
// Dereference: *x
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(derefof);
// binary complement: ~x
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(bcomp);
// Reference type: x&
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(referencetype);
// Pointer type: x*
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(pointertype);
// round: round(x)
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(round);
// floor: floor(x)
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(floor);
// ceil: ceil(x)
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(ceil);
// square root: sqrt(x)
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(sqrt);
// !x:
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(not);


/**
 * Loop types.
 *
 */
enum e_past_loop_type
{
  e_past_unknown_loop = 0,
  e_past_tile_loop = 1,
  e_past_point_loop = 2,
  e_past_vector_loop = 3,
  e_past_openmp_loop = 4,
  e_past_otl_loop = 5,
  e_past_fulltile_loop = 6,
};
typedef enum e_past_loop_type e_past_loop_type_t;


/**
 * Loop properties.
 *
 */
enum e_past_loop_property
{
  e_past_unset_prop = 0,
  e_past_seq_loop = 1,
  e_past_fco_loop = 2,
  e_past_parallel_loop = 3,
};
typedef enum e_past_loop_property e_past_loop_property_t;

/**
 * past_for
 *
 */
struct past_for_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	init;
  s_past_node_t*	test;
  s_symbol_t*		iterator;
  s_past_node_t*	increment;
  s_past_node_t*	body;
  int			type; // Should be of type e_past_loop_type_t
  int			property; // Should be of type e_past_loop_property_t
  void*			usr;
};
typedef struct past_for_t s_past_for_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(for);

/**
 * past_for <- past_parfor
 *
 */
struct past_parfor_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	init;
  s_past_node_t*	test;
  s_symbol_t*		iterator;
  s_past_node_t*	increment;
  s_past_node_t*	body;
  int			type; // Should be of type e_past_loop_type_t
  int			property; // Should be of type e_past_loop_property_t
  void*			usr;
  s_symbol_t**		private_vars;
};
typedef struct past_parfor_t s_past_parfor_t;
// parfor is a sub-type of for.
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(parfor);


/**
 * basic block
 *
 */
struct past_block_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	body;
  s_symbol_table_t*    	symboltable; // Optional, for local symbol
				     // tables (local scope).
  int			artificial_bb;  // Set to 1 if the BB was
					// generated to enable the
					// handling of a list of
					// statement as a single
					// sub-tree, and is meant to
					// be deleted once this
					// particular subtree is done
					// being processed.
};
typedef struct past_block_t s_past_block_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(block);


/**
 * past_while, e.g., while (cond) { body }
 *
 */
struct past_while_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	condition;
  s_past_node_t*	body;
  void*			usr; //unmanaged.
};
typedef struct past_while_t s_past_while_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(while);


/**
 * past_do_while, e.g., do { body } while (cond)
 *
 */
struct past_do_while_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	condition;
  s_past_node_t*	body;
  void*			usr; //unmanaged.
};
typedef struct past_do_while_t s_past_do_while_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(do_while);



/**
 * generic if
 *
 */
struct past_if_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	condition;
  s_past_node_t*	then_clause;
  s_past_node_t*	else_clause;
};
typedef struct past_if_t s_past_if_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(if);


/**
 * special if when the clause is affine
 *
 */
struct past_affineguard_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	condition;
  s_past_node_t*	then_clause;
};
typedef struct past_affineguard_t s_past_affineguard_t;
// affineguard is not a subtype of if, as it is a restriction.
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(affineguard);


/**
 * special statement coming from CLooG translation.
 *
 */
struct past_cloogstmt_t
{
  s_past_node_t		node;
  //
  void*			cloogdomain; // CloogDomain
  void*			cloogstatement; // CloogStatement
  s_past_varref_t*	stmt_name;
  int			stmt_number;
  s_past_node_t*	substitutions; // list of iterator substitutions
  s_past_node_t*	references; // chained list of access function trees.
};
typedef struct past_cloogstmt_t s_past_cloogstmt_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(cloogstmt);


/**
 * Generic statement node, pprinted with ; at the end.
 *
 */
struct past_statement_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	body;
};
typedef struct past_statement_t s_past_statement_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(statement);


/**
 * Function call.
 *
 */
struct past_funcall_t
{
  s_past_node_t		node;
  //
  s_past_node_t*  	name;
  s_past_node_t*	args_list;
  int			is_pure_function;
};
typedef struct past_funcall_t s_past_funcall_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(funcall);

/**
 * Function declaration.
 *
 */
struct past_fundecl_t
{
  s_past_node_t		node;
  //
  s_past_node_t*  	name;
  s_past_node_t*  	type;
  s_past_node_t*	args_list;
  s_past_node_t*	body;
};
typedef struct past_fundecl_t s_past_fundecl_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(fundecl);

/**
 * Variable declaration (will print 'type var').
 *
 * To initialize, build a past_assign with the vardecl as LHS.
 *
 */
struct past_vardecl_t
{
  s_past_node_t		node;
  //
  s_past_node_t*  	type;
  s_past_node_t*  	name;
};
typedef struct past_vardecl_t s_past_vardecl_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(vardecl);


/**
 * Ternary operator
 *
 */
struct past_ternary_cond_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	cond;
  s_past_node_t*	true_clause;
  s_past_node_t*	false_clause;
};
typedef struct past_ternary_cond_t s_past_ternary_cond_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(ternary_cond);


/**
 * cast node.
 *
 */
struct past_cast_t
{
  s_past_node_t		node;
  //
  s_past_node_t*	type;
  s_past_node_t*        expr;
};
typedef struct past_cast_t s_past_cast_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(cast);


/**
 * generic, uninterpreted node.
 *
 */
struct past_generic_t
{
  s_past_node_t		node;
  // managed.
  char*			char_data;
  // not managed.
  void*			ptr_data;
  // additional unmanaged pointer.
  void*			usr;
};
typedef struct past_generic_t s_past_generic_t;
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(generic);



/******************************************************************************/
/******************************* Node creation ********************************/
/******************************************************************************/

extern
s_past_root_t* past_root_create (s_symbol_table_t* symboltable,
				 s_past_node_t* body);
extern
s_past_node_t* past_node_root_create (s_symbol_table_t* symboltable,
				      s_past_node_t* body);

extern
s_past_varref_t* past_varref_create (s_symbol_t* symbol);
extern
s_past_node_t* past_node_varref_create (s_symbol_t* symbol);

extern
s_past_type_t* past_type_create (s_past_node_t* texpr);
extern
s_past_node_t* past_node_type_create (s_past_node_t* texpr);

extern
s_past_type_t* past_type_create (s_past_node_t* texpr);
extern
s_past_node_t* past_node_type_create (s_past_node_t* texpr);

extern
s_past_value_t* past_value_create (int type, u_past_value_data_t val);
extern
s_past_node_t* past_node_value_create (int type, u_past_value_data_t val);
extern
s_past_value_t* past_value_create_from_int (int val);
extern
s_past_node_t* past_node_value_create_from_int (int val);

extern
s_past_string_t* past_string_create (char* data);
extern
s_past_node_t* past_node_string_create (char* data);

extern
s_past_for_t* past_for_create (s_past_node_t* init,
			       s_past_node_t* test,
			       s_symbol_t* iterator,
			       s_past_node_t* increment,
			       s_past_node_t* body);
extern
s_past_node_t* past_node_for_create (s_past_node_t* init,
				     s_past_node_t* test,
				     s_symbol_t* iterator,
				     s_past_node_t* increment,
				     s_past_node_t* body);

extern
s_past_parfor_t* past_parfor_create (s_past_node_t* init,
				     s_past_node_t* test,
				     s_symbol_t* iterator,
				     s_past_node_t* increment,
				     s_past_node_t* body);
extern
s_past_node_t* past_node_parfor_create (s_past_node_t* init,
					s_past_node_t* test,
					s_symbol_t* iterator,
					s_past_node_t* increment,
					s_past_node_t* body);

extern
s_past_ternary_t* past_ternary_create (cs_past_node_type_t* type,
				       s_past_node_t* arg1,
				       s_past_node_t* arg2,
				       s_past_node_t* arg3);
extern
s_past_node_t* past_node_ternary_create (cs_past_node_type_t* type,
					 s_past_node_t* arg1,
					 s_past_node_t* arg2,
					 s_past_node_t* arg3);

extern
s_past_binary_t* past_binary_create (cs_past_node_type_t* type,
				     s_past_node_t* lhs,
				     s_past_node_t* rhs);
extern
s_past_node_t* past_node_binary_create (cs_past_node_type_t* type,
					s_past_node_t* lhs,
					s_past_node_t* rhs);

extern
s_past_unary_t* past_unary_create (cs_past_node_type_t* type,
				   s_past_node_t* expr);
extern
s_past_node_t* past_node_unary_create (cs_past_node_type_t* type,
				       s_past_node_t* expr);

extern
s_past_block_t* past_block_create (s_past_node_t* body);
extern
s_past_node_t* past_node_block_create (s_past_node_t* body);

extern
s_past_while_t* past_while_create (s_past_node_t* condition,
				   s_past_node_t* body);
extern
s_past_node_t* past_node_while_create (s_past_node_t* condition,
				       s_past_node_t* body);

extern
s_past_do_while_t* past_do_while_create (s_past_node_t* condition,
					 s_past_node_t* body);
extern
s_past_node_t* past_node_do_while_create (s_past_node_t* condition,
					  s_past_node_t* body);

extern
s_past_if_t* past_if_create (s_past_node_t* cond,
			     s_past_node_t* then_clause,
			     s_past_node_t* else_clause);
extern
s_past_node_t* past_node_if_create (s_past_node_t* cond,
				    s_past_node_t* then_clause,
				    s_past_node_t* else_clause);

extern
s_past_affineguard_t* past_affineguard_create (s_past_node_t* cond,
					       s_past_node_t* then_clause);
extern
s_past_node_t* past_node_affineguard_create (s_past_node_t* cond,
					     s_past_node_t* then_clause);

extern
s_past_cloogstmt_t* past_cloogstmt_create (void* cloogdomain,
					   void* cloogstatement,
					   s_past_varref_t* stmt_name,
					   int stmt_number,
					   s_past_node_t* substitutions);
extern
s_past_node_t* past_node_cloogstmt_create (void* cloogdomain,
					   void* cloogstatement,
					   s_past_varref_t* stmt_name,
					   int stmt_number,
					   s_past_node_t* substitutions);

extern
s_past_statement_t* past_statement_create (s_past_node_t* body);
extern
s_past_node_t* past_node_statement_create (s_past_node_t* body);

extern
s_past_funcall_t* past_funcall_create (s_past_node_t* name,
				       s_past_node_t* args_list);
extern
s_past_node_t* past_node_funcall_create (s_past_node_t* name,
					 s_past_node_t* args_list);

extern
s_past_fundecl_t* past_fundecl_create (s_past_node_t* name,
				       s_past_node_t* type,
				       s_past_node_t* args_list,
				       s_past_node_t* body);
extern
s_past_node_t* past_node_fundecl_create (s_past_node_t* type,
					 s_past_node_t* name,
					 s_past_node_t* args_list,
					 s_past_node_t* body);

extern
s_past_vardecl_t* past_vardecl_create (s_past_node_t* type,
				       s_past_node_t* name);
extern
s_past_node_t* past_node_vardecl_create (s_past_node_t* type,
					 s_past_node_t* name);

extern
s_past_ternary_cond_t* past_ternary_cond_create (s_past_node_t* cond,
						 s_past_node_t* true_clause,
						 s_past_node_t* false_clause);
extern
s_past_node_t* past_node_ternary_cond_create (s_past_node_t* cond,
						 s_past_node_t* true_clause,
						 s_past_node_t* false_clause);

extern
s_past_cast_t* past_cast_create (s_past_node_t* casttype,
				 s_past_node_t* expr);
extern
s_past_node_t* past_node_cast_create (s_past_node_t* casttype,
				      s_past_node_t* expr);

extern
s_past_generic_t* past_generic_create (char* char_data, void* ptr_data);
extern
s_past_node_t* past_node_generic_create (char* char_data, void* ptr_data);

extern
void past_node_freeattr (s_past_node_t* node);


/******************************************************************************/
/****************************** Node processing *******************************/
/******************************************************************************/


#define PAST_GET_NODE(n) (&((n)->node))

/**
 * Check the type of a node.
 *
 */
extern
int
past_node_is_a (s_past_node_t* node, cs_past_node_type_t* type);
#define PAST_NODE_IS_A(node, type) past_node_is_a(node, type)
#define PAST_DECLARE_TYPED(type, typednode, node)      	\
  s_past_##type##_t* typednode = (s_past_##type##_t*) node


/**
 * Deep copy.
 *
 */
extern
s_past_node_t* past_clone (s_past_node_t* node);

/**
 * Shallow copy.
 *
 */
extern
s_past_node_t* past_copy (s_past_node_t* node);

/**
 * Deep free.
 *
 */
extern
void past_deep_free (s_past_node_t* node);

/**
 * Sets the parent pointer in a tree.
 *
 */
extern
void past_set_parent (s_past_node_t* root);

/**
 * Generic visitor.
 *
 */
extern
void past_visitor (s_past_node_t* node,
		   past_fun_t prefix,
		   void* prefix_data,
		   past_fun_t suffix,
		   void* suffix_data);

/**
 * Replace a node, assuming old->parent is set and old is not a past_root.
 *
 *
 */
extern
void past_replace_node (s_past_node_t* oldnode,
			s_past_node_t* newnode);

/**
 * Get the address of a node in the hierarchy.
 *
 *
 */
extern
s_past_node_t** past_node_get_addr (s_past_node_t* node);


/**
 * Convert a past_for node into a past_parfor node. If the node parent
 * is set, the new node is correctly inserted in the hierarchy.
 * Returns the newly created node, and deletes the current node.
 */
s_past_node_t*
past_for_to_parfor (s_past_node_t* node);

/**
 * Append node 'toappend' as the last sibling of node 'node'.
 *
 */
extern
void past_append_last (s_past_node_t* node,
		       s_past_node_t* toappend);

/**
 * Append node 'toappend' as the first sibling of node 'node'.
 * Do not confuse with 'prepend'!
 */
extern
void past_append_first (s_past_node_t* node,
			s_past_node_t* toappend);

/**
 * Prepend node 'toprepend' before node 'node'.
 *
 */
extern
void past_prepend (s_past_node_t* node,
		   s_past_node_t* toprepend);


/**
 * Remove the subtree 'tree' from the full tree. Does not delete/deep
 * free 'tree'.
 * Note: if 'tree' is a past_root, no action is performed.
 * Return: 1 if the node was found and successfully removed, 0 otherwise.
 */
extern
int past_remove_subtree (s_past_node_t* tree);



END_C_DECLS


#endif // PAST_PAST_H
