/*
 * past_api.h: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#ifndef PAST_PAST_API_H
# define PAST_PAST_API_H

# include <past/common.h>
# include <past/symbols.h>
# include <past/past.h>

BEGIN_C_DECLS

/**
 * Count the number of statements (past_cloogstmt and past_statement)
 * in a tree.
 *
 */
extern
int
past_count_statements (s_past_node_t* root);

/**
 * Count the number of nodes of type 'type' in a tree.
 *
 */
extern
int
past_count_nodetype (s_past_node_t* root, cs_past_node_type_t* type);

/**
 * Collect all nodes of type 'type' in a tree, prefix order.
 *
 */
extern
s_past_node_t**
past_collect_nodetype (s_past_node_t* root, cs_past_node_type_t* type);

/**
 * Collect all nodes of type 'type' in a tree, postfix order.
 *
 */
extern
s_past_node_t**
past_collect_nodetype_postfix (s_past_node_t* root, cs_past_node_type_t* type);

/**
 * Returns true of node 'node' is contained in the tree 'root'.
 *
 */
int
past_contain_node (s_past_node_t* node, s_past_node_t* tree);

/**
 * Return the expression describing the array name (deepest LHS).
 *
 */
s_past_node_t* past_get_array_name (s_past_node_t* node);

/**
 * Return true if the nodes in the tree are only of the type in the
 * NULL-terminated type list 'types_ok'.
 *
 */
extern
int
past_node_type_in_set (s_past_node_t* node, cs_past_node_type_t** type_list);

/**
 * Return a statement/cloogstmt surrounded by 'depth' loop(s) in the
 * (sub-)tree dominated by 'root'.
 *
 */
extern
s_past_node_t*
past_find_statement_at_depth (s_past_node_t* root, int depth);

/**
 * Return the maximal loop depth in the (sub-)tree dominated by 'root'.
 *
 */
extern
int
past_max_loop_depth (s_past_node_t* root);

/**
 * Return the loop depth of a node, relative to the whole tree.
 *
 */
extern
int
past_loop_depth (s_past_node_t* root);

/**
 * Returns true if the loops in the tree dominated by 'node' contains
 * single perfectly-nested loop nest.
 *
 */
extern
int
past_is_perfectly_nested_loop_nest (s_past_node_t* node);

/**
 * Returns true if there is no triangular loop in the tree dominated
 * by node.
 *
 */
extern
int
past_has_only_rectangular_loops (s_past_node_t* node);

/**
 * Count the number of for loops in the (sub-)tree dominated by 'root'.
 *
 */
extern
int
past_count_for_loops (s_past_node_t* root);

/**
 * Count the number of for loops surrounding/enclosing 'root'.
 *
 */
extern
int
past_count_enclosing_for_loops (s_past_node_t* root);

/**
 * Return a NULL-terminated array of the outer loops in the (sub-)tree
 * dominated by 'root'.
 *
 */
extern
s_past_node_t**
past_outer_loops (s_past_node_t* root);

/**
 * Return a NULL-terminated array of the inner loops in the (sub-)tree
 * dominated by 'root'.
 *
 */
extern
s_past_node_t**
past_inner_loops (s_past_node_t* root);

/**
 * Return true if the (sub-)tree dominated by 'root' contains a loop.
 *
 */
extern
int
past_contain_loop (s_past_node_t* root);

/**
 * Return true if the node is an outer loop in the whole tree.
 *
 */
extern
int
past_is_outer_for_loop (s_past_node_t* node);

/**
 * Return true if the node is an inner loop in the whole tree.
 *
 */
extern
int
past_is_inner_for_loop (s_past_node_t* node);

/**
 * Checks if a loop is of the form (for i = expr1; i <(=) expr2; op(i))
 * where op(i) means i has stride +1. It sets lb to expr1, ub to
 * expr2, and comp_type to <(=). It returns 1 if the loop fits this
 * template, 0 otherwise.
 *
 */
extern
int
past_get_canonical_for_loop_elts (s_past_node_t* forloop,
				  s_past_node_t** lb,
				  s_past_node_t** ub,
				  cs_past_node_type_t** comp_type);

/**
 * Return true if the type is integral.
 *
 */
extern
int
past_type_is_integral (s_past_node_t* node);


/**
 * Rebuild the symbol table, and attach it to the root node.
 *
 */
extern
void
past_rebuild_symbol_table (s_past_node_t* node);

/**
 * Fill-in the 'declaration' pointer of symbols to the corresponding
 * variable declaration in the tree, if any.
 *
 */
void
past_update_symbols_with_declaration (s_past_node_t* root);

/**
 * Optimize 'for' loop bounds, by hoisting them as much as possible.
 *
 */
extern
void
past_optimize_loop_bounds (s_past_node_t* root);

/**
 * Super-optimize 'for' loop bounds, by hoisting them as much as possible.
 *
 */
extern
void
past_super_optimize_loop_bounds (s_past_node_t* root);


/**
 * Replace all array references by an API-specified function
 * call. Returns a possibly modified root for the tree.
 *
 * E.g:
 * A[i+42][j] = ... is replaced by *__past_arrayref_write_2d(A, i+42, j) = ...
 *
 */
extern
s_past_node_t*
past_encapsulate_arrayref_in_func (s_past_node_t* root);

/**
 * Return the immediate enclosing node of type 'type', NULL if it does
 * not exists.
 *
 */
extern
s_past_node_t*
past_get_enclosing_node (s_past_node_t* node, cs_past_node_type_t* type);

/**
 * Return the immediate enclosing node of type 'type' in the subtree
 * dominated by 'root_subtree', NULL if it does not exists.
 *
 */
s_past_node_t* past_get_enclosing_node_subtree (s_past_node_t* node,
						s_past_node_t* root_subtree,
						cs_past_node_type_t* type);

/**
 * Return a null-terminated set of unique symbols being read in the
 * tree.
 *
 */
extern
s_symbol_t**
past_collect_read_symbols (s_past_node_t* node);

/**
 * Return a null-terminated set of unique symbols being written in the
 * tree.
 *
 */
extern
s_symbol_t**
past_collect_write_symbols (s_past_node_t* node);

/**
 * Return a null-terminated set of unique symbols being read-only in the
 * tree.
 *
 */
extern
s_symbol_t**
past_collect_readonly_symbols (s_past_node_t* node);

/**
 * Return a null-terminated set of unique array symbols in the tree.
 *
 */
extern
s_symbol_t**
past_collect_array_symbols (s_past_node_t* node);

/**
 * Return a null-terminated set of unique symbols being written in the
 * tree, minus the loop iterators.
 *
 */
extern
s_symbol_t** past_collect_write_symbols_noloopiter (s_past_node_t* node);

/**
 * Check if a varref symbol is read or written.
 *
 */
extern
int past_varref_is_write_reference (s_past_varref_t* var);

/**
 * Check if a varref symbol is written but not read.
 *
 */
extern
int past_varref_is_writeonly_reference (s_past_varref_t* var);


/**
 * Return a null-terminated set of unique symbols being read in any
 * affine expression in the tree. By construction those should be
 * integers.
 *
 */
extern
s_symbol_t**
past_collect_affineexpr_symbols (s_past_node_t* node);

/**
 * Return a null-terminated set of unique loop iterator symbols
 * assigned in the tree.
 *
 */
extern
s_symbol_t**
past_collect_written_loopiterators_symbols (s_past_node_t* node);

/**
 * Return true if the for stride is +1.
 *
 */
extern
int past_for_is_stride_one (s_past_for_t* f);

/**
 * Replace all inner-most SIMD loop by an API-specified function call.
 *
 * E.g:
 * for (i = 0; i < N; i += 2)
 *   A[k][i] *= alpha;
 * is replaced by:
 * __past_loop_1(&i, N, k, A, alpha)
 *
 * And a new tree is created and contains:
 *
 * void __past_loop_1(int* i_ptr, int N, int k, DATA_TYPE PAST_DECL_A A,
 *                    DATA_TYPE alpha) {
 *  int i = *i_ptr;
 *  for (i = 0; i < N; i += 2)
 *     A[k][i] *= alpha;
 *  *i_ptr = i;
 * }
 *
 */
extern
s_past_node_t*
past_encapsulate_simd_loops_in_func (s_past_node_t** root);

/**
 * Replace all inner-most SIMD loop by an API-specified function call.
 *
 * E.g:
 * for (i = 0; i < N; i += 2)
 *   A[k][i] *= alpha;
 * is replaced by:
 * __past_loop_1(N, k, alpha, A, &i)
 *
 * And a separate file 'filename' is created and contains:
 *
 * void __past_loop_1(int N, int k, DATA_TYPE alpha, DATA_TYPE PAST_DECL_A(A),
 *                    int* __local_i) {
 *  int i = *__local_i;
 *  for (i = 0; i < N; i += 2)
 *     A[k][i] *= alpha;
 *  *__local_i = i;
 * }
 *
 */
extern
void
past_encapsulate_simd_loops_in_func_file (s_past_node_t* root,
					  char* filename);

/**
 * Returns 1 if the two trees represent the same structure, 0 otherwise.
 *
 */
extern
int
past_tree_are_equal (s_past_node_t* t1, s_past_node_t* t2);

/**
 * Check if the PAST tree is well-formed (pointer checks).
 *
 */
extern
int
past_consistency_check (s_past_node_t* root, int verbose);

/**
 * Fixup the AST structure.
 *
 */
extern
void
past_ast_fixup_structure (s_past_node_t* node);

/**
 * Parser to convert a string into a PAST tree.
 * Note: works only for statements.
 *
 */
extern
s_past_node_t* past_expression_parser(char* str);


END_C_DECLS


#endif // PAST_PAST_API_H
