/*
 * options.h: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * 
 */
#ifndef PAST_OPTIONS_H
# define PAST_OPTIONS_H

# include <stdio.h>
# include <past/past.h>


BEGIN_C_DECLS

struct s_past_options
{
  int	pprint_encapsulate_arrayref; /* Set to 1 to encapsulate all
				      * array references A[i]... in a
				      * function call
				      * _past_array_read/write_xd(A,i,...)
				      * with x corresponding to the
				      * dimensionality of the array.
				      */
  int	pprint_simdfunc_separation; /* Set to 1 to replace inner-most
				     * loop with non-unit stride (aka
				     * SIMD loops) by a function call,
				     * and put the corresponding
				     * function implementation in a
				     * separate file.
				     */
};
typedef struct s_past_options s_past_options_t;


extern
s_past_options_t* past_options_malloc ();

extern
void past_options_free (s_past_options_t* opts);


END_C_DECLS


#endif // PAST_OPTIONS_H
