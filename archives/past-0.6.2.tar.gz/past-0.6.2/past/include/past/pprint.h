/*
 * pprint.h: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * 
 */
#ifndef PAST_PPRINT_H
# define PAST_PPRINT_H

# include <stdio.h>
# include <past/past.h>
# include <past/options.h>


BEGIN_C_DECLS

typedef void (*past_metainfo_fun_t) (struct past_node_t* node, FILE* outfile);

/**
 * User-defined pretty-print function. Must return 1 if 'node' was
 * pretty-printed, 0 otherwise.
 *
 */
typedef int (*past_pprint_extensions_fun_t) (FILE* out, int indent,
					     s_past_node_t* node,
					     s_symbol_table_t* symboltable,
					     past_metainfo_fun_t mprint,
					     s_past_options_t* opts);
/**
 * Generic node C pretty-printer.
 *
 *
 */
extern
void
past_pprint_node (FILE* out, int indent,
		  s_past_node_t* node, s_symbol_table_t* symboltable,
		  past_metainfo_fun_t mprint,
		  past_pprint_extensions_fun_t past_pprint_ext,
		  s_past_options_t* opts);

/**
 * Default C pretty-printer.
 *
 *
 */
extern
void
past_pprint (FILE* out, s_past_node_t* root);


/**
 * C pretty-printer using explicitly defined options.
 *
 *
 */
extern
void
past_pprint_options (FILE* out, s_past_node_t* root, s_past_options_t* opts);


/**
 * C pretty-printer using 'mprint' to print meta-info, if any.
 * prototype: void mprint (s_past_node_t* node, FILE* out).
 *
 */
extern
void
past_pprint_metainfo (FILE* out, s_past_node_t* root,
		      past_metainfo_fun_t mprint);

/**
 * C pretty-printer using 'mprint' to print meta-info, if any.
 * prototype: void mprint (s_past_node_t* node, FILE* out).
 * Uses 'past_pprint_ext' to print user-defined nodes, if any.
 *
 */
extern
void
past_pprint_extended_metainfo (FILE* out, s_past_node_t* root,
			       past_metainfo_fun_t mprint,
			       past_pprint_extensions_fun_t past_pprint_ext);

END_C_DECLS


#endif // PAST_PPRINT_H
