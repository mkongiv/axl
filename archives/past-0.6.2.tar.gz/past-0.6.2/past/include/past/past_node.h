/*
 * past_node.h: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#ifndef PAST_PAST_NODE_H
# define PAST_PAST_NODE_H

# include <past/common.h>

BEGIN_C_DECLS


/**
 * Type the nodes based on their free function (declared as a global).
 *
 */
/** Explicitely set a hierarchy with at most 5 levels. **/
#define PAST_NODE_HIERARCHY_HEIGHT 6

struct past_node_t;
struct past_node_type_t
{
  void (*freefun[PAST_NODE_HIERARCHY_HEIGHT])(struct past_node_t*);
};
typedef const struct past_node_type_t cs_past_node_type_t;
typedef void (*past_fun_t) (struct past_node_t* node, void* data);
typedef struct past_node_t* (*past_clone_fun_t) (struct past_node_t* node);


typedef void (*past_visitor_fun_t) (struct past_node_t* root,
				    past_fun_t prefix,
				    void* prefix_data,
				    past_fun_t suffix,
				    void* suffix_data);



struct past_node_t {
  cs_past_node_type_t*	type; // Unique id for the node type (eg, past_root).
  past_visitor_fun_t	visitor; // pointer to the visitor function.
  past_clone_fun_t	clone; // pointer to the clone function.
  struct past_node_t*	parent; // Parent pointer.
  struct past_node_t*	next; // Linked list of siblings.
  void*			metainfo; // Managed (ie, freed) user pointer.
  void*			decoration; // Unmanaged user pointer, for decoration.
  void*			usr; // Unmanaged user pointer, for user-specific dev.
};
typedef struct past_node_t s_past_node_t;


/**
 * Convenience macros. To register a node of type 'mytype':
 * - in the header (.h) file, use PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(mytype)
 * - in the unit (.c) file, use PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(mytype)
 *   after declaring the free function associated to 'type', which
 *   MUST be declared 'static void past_mytype_free(s_past_node_t*)'.
 *   Similarely, the generic visitor MUST be declared 'static void
 *   past_mytype_visitor(s_past_node_t*, ...)'.
 *
 * if 'type' is a subclass of a super class 'super', it should be
 * registered in the unit file with
 * PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_2(type, super)
 *
 */
#define PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(type)	\
extern void past_##type##_free(s_past_node_t* n);	\
extern cs_past_node_type_t* const past_##type;
#define PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_1(type)	       	\
cs_past_node_type_t s_past_##type = { past_##type##_free, past_node_free, NULL }; \
cs_past_node_type_t* const past_##type = &s_past_##type;
#define PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_2(type,superclass)	       	\
cs_past_node_type_t s_past_##type = { past_##type##_free, past_##superclass##_free, past_node_free, NULL }; \
cs_past_node_type_t* const past_##type = &s_past_##type;
#define PAST_DECLARE_NODE_IN_HIERARCHY_UNIT_3(type,super1,super2)     	\
cs_past_node_type_t s_past_##type = { past_##type##_free, past_##super1##_free, past_##super2##_free, past_node_free, NULL }; \
cs_past_node_type_t* const past_##type = &s_past_##type;

/**
 * Top hierarchy node type.
 */
PAST_DECLARE_NODE_IN_HIERARCHY_HEADER(node);

END_C_DECLS


#endif // PAST_PAST_NODE_H
