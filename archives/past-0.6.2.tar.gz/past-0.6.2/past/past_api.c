/*
 * past_api.c: This file is part of the PAST project.
 *
 * PAST: the PoCC Abstract Syntax Tree
 *
 * Copyright (C) 2014 the Ohio State University
 *
 * This program can be redistributed and/or modified under the terms
 * of the license specified in the LICENSE.txt file at the root of the
 * project.
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <past/config.h>
#endif

#include <assert.h>
#include <past/common.h>
#include <past/past_api.h>
#include <past/pprint.h>




static
void traverse_count_nodetype(s_past_node_t* node, void* args)
{
  cs_past_node_type_t* type = (cs_past_node_type_t*) ((void**)args)[0];
  if (past_node_is_a (node, type))
    {
      int* count = ((void**)args)[1];
      (*count)++;
    }
}

/**
 * Count the number of nodes of type 'type' in a tree.
 *
 */
int
past_count_nodetype(s_past_node_t* root, cs_past_node_type_t* type)
{
  int num_nodes = 0;
  if (root)
    {
      void* args[2];
      args[0] = (void*)type;
      args[1] = &num_nodes;
      s_past_node_t* next = root->next;
      root->next = NULL;
      past_visitor (root, traverse_count_nodetype, (void*)args, NULL, NULL);
      root->next = next;
    }

  return num_nodes;
}

static
void traverse_contain_node(s_past_node_t* node, void* args)
{
  if (node == ((void**)args)[0])
    *((int*)((void**)args)[1]) = 1;
}

/**
 * Returns true of node 'node' is contained in the tree 'root'.
 *
 */
int
past_contain_node(s_past_node_t* node, s_past_node_t* root)
{
  int has_node = 0;
  if (root)
    {
      void* args[2];
      args[0] = (void*)node;
      args[1] = &has_node;
      s_past_node_t* next = root->next;
      root->next = NULL;
      past_visitor (root, traverse_contain_node, (void*)args, NULL, NULL);
      root->next = next;
    }

  return has_node;
}


static
void traverse_collect_nodetype(s_past_node_t* node, void* args)
{
  cs_past_node_type_t* type = (cs_past_node_type_t*) ((void**)args)[0];
  if (past_node_is_a (node, type))
    {
      s_past_node_t** res = ((void**)args)[1];
      int i;
      for (i = 0; res[i]; ++i)
	;
      res[i] = node;
    }
}
/**
 * Collect all nodes of type 'type' in a tree, prefix order.
 *
 */
s_past_node_t**
past_collect_nodetype(s_past_node_t* root, cs_past_node_type_t* type)
{
  if (! root)
    return NULL;
  int num_nodes = past_count_nodetype (root, type);
  s_past_node_t** res = XMALLOC(s_past_node_t*, num_nodes + 1);
  int i;
  for (i = 0; i < num_nodes + 1; ++i)
    res[i] = NULL;
  void* args[2];
  args[0] = (void*)type;
  args[1] = res;
  s_past_node_t* next = root->next;
  root->next = NULL;
  past_visitor (root, traverse_collect_nodetype, (void*)args, NULL, NULL);
  root->next = next;

  return res;
}

/**
 * Collect all nodes of type 'type' in a tree, postfix order.
 *
 */
s_past_node_t**
past_collect_nodetype_postfix(s_past_node_t* root, cs_past_node_type_t* type)
{
  if (! root)
    return NULL;
  int num_nodes = past_count_nodetype (root, type);
  s_past_node_t** res = XMALLOC(s_past_node_t*, num_nodes + 1);
  int i;
  for (i = 0; i < num_nodes + 1; ++i)
    res[i] = NULL;
  void* args[2];
  args[0] = (void*)type;
  args[1] = res;
  s_past_node_t* next = root->next;
  root->next = NULL;
  past_visitor (root, NULL, NULL, traverse_collect_nodetype, (void*)args);
  root->next = next;

  return res;
}


/**
 * Return true if the nodes in the tree are only of the type in the
 * NULL-terminated type list 'types_ok'.
 *
 */
int
past_node_type_in_set(s_past_node_t* node, cs_past_node_type_t** type_list)
{
  s_past_node_t** nodes = past_collect_nodetype (node, past_node);
  int i, j;
  for (i = 0; nodes && nodes[i]; ++i)
    {
      for (j = 0; type_list && type_list[j]; ++j)
	if (past_node_is_a (nodes[i], type_list[j]))
	  break;
      if (! type_list || ! type_list[j])
	{
	  XFREE(nodes);
	  return 0;
	}
    }
  XFREE(nodes);
  return 1;
}

/**
 * Count the number of for loops in a tree.
 *
 */
int
past_count_for_loops(s_past_node_t* root)
{
  return past_count_nodetype (root, past_for);
}

/**
 * Count the number of for loops surrounding/enclosing 'root'.
 *
 */
int
past_count_enclosing_for_loops(s_past_node_t* root)
{
  if (! root)
    return 0;
  int num_outer_loops = 0;
  s_past_node_t* stmt = root->parent;
  while (stmt)
    {
      if (past_node_is_a (stmt, past_for))
	++num_outer_loops;
      stmt = stmt->parent;
    }

  return num_outer_loops;
}


/**
 * Count the number of statements (past_cloogstmt and past_statement)
 * in a tree.
 *
 */
int
past_count_statements(s_past_node_t* root)
{
  return past_count_nodetype (root, past_cloogstmt) +
    past_count_nodetype (root, past_statement);
}

static
int
past_loop_depth_sub(s_past_node_t* root, s_past_node_t* top)
{
  if (!root || root == top)
    return 0;

  s_past_node_t* node;
  int depth = 0;
  do
    {
      if (past_node_is_a (root, past_for))
	++depth;
      if (root == top)
	break;
      root = root->parent;
    }
  while (root);

  return depth;
}

static
void traverse_max_loop_depth(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_cloogstmt) ||
      past_node_is_a (node, past_statement))
    {
      s_past_node_t* top = ((void**)data)[0];
      int* maxdepth = ((void**)data)[1];
      int depth = past_loop_depth_sub (node, top);
      if (depth > *maxdepth)
	*maxdepth = depth;
    }
}

/**
 * Return the maximal loop depth.
 *
 */
int
past_max_loop_depth(s_past_node_t* root)
{
  int maxdepth = 0;
  void* args[2];
  args[0] = root;
  args[1] = &maxdepth;
  s_past_node_t* next = root->next;
  root->next = NULL;
  past_visitor (root, traverse_max_loop_depth, (void*) args, NULL, NULL);
  root->next = next;

  return maxdepth;
}


/**
 * Return the loop depth of a node.
 *
 */
int
past_loop_depth(s_past_node_t* root)
{
  return past_loop_depth_sub (root, NULL);
}

static
void traverse_find_statement_at_depth(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_cloogstmt) ||
      past_node_is_a (node, past_statement))
    {
      s_past_node_t* found = ((void**)data)[2];
      if (! found)
	{
	  s_past_node_t* top = ((void**)data)[0];
	  int* maxdepth = ((void**)data)[1];
	  int depth = past_loop_depth_sub (node, top);
	  if (depth == *maxdepth)
	    ((void**)data)[2] = node;
	}
    }
}

/**
 * Return a statement/cloogstmt surrounded by 'depth' loop.
 *
 */
s_past_node_t*
past_find_statement_at_depth(s_past_node_t* root, int depth)
{
  void* args[3];
  args[0] = root;
  args[1] = &depth;
  args[2] = NULL;
  s_past_node_t* next = root->next;
  root->next = NULL;
  past_visitor (root, traverse_find_statement_at_depth, (void*)args,
		NULL, NULL);
  root->next = next;

  return args[2];
}

static
void traverse_past_outer_loops(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_for))
    {
      int i;
      s_past_node_t* top = ((void**)data)[0];
      s_past_node_t** outer = ((void**)data)[1];
      s_past_node_t* n;
      int is_outer = 1;
      if (node != top)
	for (n = node->parent; n; n = n->parent)
	  {
	    if (past_node_is_a (n, past_for))
	      {
		is_outer = 0;
		break;
	      }
	    if (n == top)
	      break;
	  }
      if (is_outer)
	{
	  for (i = 0; outer[i]; ++i)
	    ;
	  outer[i] = node;
	}
    }
}

static
void traverse_past_inner_loops(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_for))
    if (past_is_inner_for_loop (node))
      {
	int i;
	void** args = (void**)data;
	s_past_node_t** inner = args[1];
	for (i = 0; inner[i]; ++i)
	  ;
	inner[i] = node;
      }
}

static
s_past_node_t**
past_innerouter_loops(s_past_node_t* root, past_fun_t prefixfun)
{
  int num_for = past_count_for_loops (root);
  s_past_node_t** loops = NULL;
  if (root)
    {
      loops = XMALLOC(s_past_node_t*, num_for + 1);
      int i;
      for (i = 0; i <= num_for; ++i)
	loops[i] = NULL;
      void* args[2];
      args[0] = root;
      args[1] = loops;
      s_past_node_t* next = root->next;
      root->next = NULL;
      past_visitor (root, prefixfun, (void*)args, NULL, NULL);
      root->next = next;
      for (i = 0; loops[i]; ++i)
	;
      if (i < num_for)
	{
	  s_past_node_t** nloops = XMALLOC(s_past_node_t*, i + 1);
	  for (i = 0; loops[i]; ++i)
	    nloops[i] = loops[i];
	  nloops[i] = NULL;
	  XFREE(loops);
	  loops = nloops;
	}
    }
  else
    {
      loops = XMALLOC(s_past_node_t*, 1);
      loops[0] = NULL;
    }

  return loops;
}


/**
 * Return a NULL-terminated array of the inner loops.
 *
 */
s_past_node_t**
past_inner_loops(s_past_node_t* root)
{
  return past_innerouter_loops (root, traverse_past_inner_loops);
}


/**
 * Return a NULL-terminated array of the outer loops.
 *
 */
s_past_node_t**
past_outer_loops(s_past_node_t* root)
{
  return past_innerouter_loops (root, traverse_past_outer_loops);
}


static
void traverse_past_contain_loop(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_for))
      *((int*)data) = 1;
}

/**
 * Return true if the tree contains a loop.
 *
 */
int
past_contain_loop(s_past_node_t* root)
{
  int has_loop = 0;
  if (root)
    {
      s_past_node_t* next = root->next;
      root->next = NULL;
      past_visitor (root, traverse_past_contain_loop, &has_loop, NULL, NULL);
      root->next = next;
    }

  return has_loop;
}


/**
 * Return true if the node is an outer loop.
 *
 */
int
past_is_outer_for_loop(s_past_node_t* node)
{
  if (! past_node_is_a (node, past_for))
    return 0;
  for (node = node->parent; node; node = node->parent)
    if (past_node_is_a (node, past_for))
      return 0;

  return 1;
}


/**
 * Return true if the node is an inner loop.
 *
 */
int
past_is_inner_for_loop(s_past_node_t* node)
{
  if (! past_node_is_a (node, past_for))
    return 0;
  PAST_DECLARE_TYPED(for, pf, node);
  int num_for = 0;
  s_past_node_t* tmp;
  for (tmp = pf->body; tmp; tmp = tmp->next)
    num_for += past_count_for_loops (tmp);
  return num_for == 0;
}

/**
 * Checks if a loop is of the form (for i = expr1; i <(=) expr2; op(i))
 * where op(i) means i has stride +1. It sets lb to expr1, ub to
 * expr2, and comp_type to <(=). It returns 1 if the loop fits this
 * template, 0 otherwise.
 *
 */
int
past_get_canonical_for_loop_elts(s_past_node_t* forloop,
				 s_past_node_t** lb,
				 s_past_node_t** ub,
				 cs_past_node_type_t** comp_type)
{
  if (! past_node_is_a (forloop, past_for))
    {
      *lb = NULL;
      *ub = NULL;
      *comp_type = NULL;
      return 0;
    }
  PAST_DECLARE_TYPED(for, pfin, forloop);
  // Get the initialization in the original for loop. Must be a single
  // i = ... init clause.
  PAST_DECLARE_TYPED(binary, pbinit, pfin->init);
  if (! past_node_is_a (pfin->init, past_assign))
    {
      past_pprint (stdout, pfin->init);
      *lb = NULL;
      *ub = NULL;
      *comp_type = NULL;
      return 0;
    }
  PAST_DECLARE_TYPED(varref, pvinit, pbinit->lhs);
  if (! past_node_is_a (pbinit->lhs, past_varref) ||
      ! symbol_equal (pvinit->symbol, pfin->iterator))
    {
      *lb = NULL;
      *ub = NULL;
      *comp_type = NULL;
      return 0;
    }
  *lb = pbinit->rhs;

  // Get the conditional in the original for loop. Must be a single le
  // or leq, the rest is not supported for the moment.
  if ((! past_node_is_a (pfin->test, past_lt) &&
       ! past_node_is_a (pfin->test, past_leq)) ||
      (past_count_nodetype (pfin->test, past_lt) +
       past_count_nodetype (pfin->test, past_leq) != 1))
    {
      *lb = NULL;
      *ub = NULL;
      *comp_type = NULL;
      return 0;
    }
  PAST_DECLARE_TYPED(binary, pb, pfin->test);
  PAST_DECLARE_TYPED(varref, pv, pb->lhs);
  if (! past_node_is_a (pb->lhs, past_varref) ||
      ! symbol_equal (pv->symbol, pfin->iterator))
    {
      *lb = NULL;
      *ub = NULL;
      *comp_type = NULL;
      return 0;
    }
  *ub = pb->rhs;
  if (past_count_nodetype (pfin->test, past_leq) != 0)
    *comp_type = past_leq;
  else
    *comp_type = past_lt;

  if (past_node_is_a (pfin->increment, past_addassign))
    {
      PAST_DECLARE_TYPED(binary, pbinc, pfin->increment);
      PAST_DECLARE_TYPED(varref, pvinc, pbinc->lhs);
      PAST_DECLARE_TYPED(value, pvalinc, pbinc->rhs);
      if (! past_node_is_a (pbinc->lhs, past_varref) ||
	  ! symbol_equal (pfin->iterator, pvinc->symbol) ||
	  ! past_node_is_a (pbinc->rhs, past_value) ||
	  ! pvalinc->value.intval == 1)
	{
	  *lb = NULL;
	  *ub = NULL;
	  *comp_type = NULL;
	  return 0;
	}
    }
  else if (past_node_is_a (pfin->increment, past_unary))
    {
      PAST_DECLARE_TYPED(unary, pun, pfin->increment);
      PAST_DECLARE_TYPED(varref, pvinc, pun->expr);
      if ((! past_node_is_a (pfin->increment, past_inc_before) &&
	   ! past_node_is_a (pfin->increment, past_inc_after)) ||
	  ! past_node_is_a (pun->expr, past_varref) ||
	  ! symbol_equal (pvinc->symbol, pfin->iterator))
	{
	  *lb = NULL;
	  *ub = NULL;
	  *comp_type = NULL;
	  return 0;
	}
    }

    return 1;
}


/**
 * Return true if the type is integral.
 *
 */
extern
int
past_type_is_integral(s_past_node_t* node)
{
  if (! past_node_is_a (node, past_type))
    return 0;
  PAST_DECLARE_TYPED(type, pt, node);
  if (! past_node_is_a (pt->texpr, past_varref))
    return 0;
  PAST_DECLARE_TYPED(varref, pv, pt->texpr);
  if (! strcmp (pv->symbol->name_str, "int") ||
      ! strcmp (pv->symbol->name_str, "char") ||
      ! strcmp (pv->symbol->name_str, "short") ||
      ! strcmp (pv->symbol->name_str, "long") ||
      ! strcmp (pv->symbol->name_str, "long long") ||
      ! strcmp (pv->symbol->name_str, "unsigned int") ||
      ! strcmp (pv->symbol->name_str, "unsigned char") ||
      ! strcmp (pv->symbol->name_str, "unsigned short") ||
      ! strcmp (pv->symbol->name_str, "unsigned long") ||
      ! strcmp (pv->symbol->name_str, "unsigned long long"))
    return 1;
  return 0;
}

static
void traverse_rebuild_symt(s_past_node_t* node, void* args)
{
  if (past_node_is_a (node, past_varref))
    {
      PAST_DECLARE_TYPED(varref, pv, node);
      s_symbol_table_t* table = args;
      s_symbol_t* sym = symbol_add (table, pv->symbol);
      if (sym != pv->symbol)
      	symbol_remove (table, pv->symbol);
      pv->symbol = sym;
    }
  else if (past_node_is_a (node, past_for))
    {
      PAST_DECLARE_TYPED(for, pf, node);
      s_symbol_table_t* table = args;
      // Beware non-affine for may not have an iterator set.
      if (pf->iterator)
	{
	  s_symbol_t* sym = symbol_add (table, pf->iterator);
	  if (sym != pf->iterator)
	    symbol_remove (table, pf->iterator);
	  pf->iterator = sym;
	}
    }
}
/**
 * Rebuild the symbol table, and attach it to the root node.
 *
 */
void
past_rebuild_symbol_table(s_past_node_t* node)
{
  // Only past_root and past_block can hold a symbol table.
  if (! past_node_is_a (node, past_root) && ! past_node_is_a (node, past_block))
    return;
  s_past_node_t* body;
  s_symbol_table_t** symtable = NULL;
  if (past_node_is_a (node, past_root))
    {
      PAST_DECLARE_TYPED(root, pr, node);
      body = pr->body;
      symtable = &(pr->symboltable);
    }
  else
    {
      PAST_DECLARE_TYPED(block, pr, node);
      body = pr->body;
      symtable = &(pr->symboltable);
    }
  if (symtable == NULL)
    return;
  if (*symtable != NULL)
    XFREE(*symtable);
  *symtable = symbol_table_malloc ();
  // Create a new symbol table for the tree.
  past_visitor (body, traverse_rebuild_symt, *symtable, NULL, NULL);
  // Update the declaration pointers.
  past_update_symbols_with_declaration (body);
}


/**
 * Fill-in the 'declaration' pointer of symbols to the corresponding
 * variable declaration in the tree, if any.
 *
 */
void
past_update_symbols_with_declaration(s_past_node_t* root)
{
  // Update the symbols declaration pointer.
  s_past_node_t** vardecls = past_collect_nodetype (root, past_vardecl);
  int i, j;
  for (i = 0; vardecls && vardecls[i]; ++i)
    {
      PAST_DECLARE_TYPED(vardecl, pv, vardecls[i]);
      s_past_node_t** varrefs = past_collect_nodetype (pv->name, past_varref);
      assert (varrefs && varrefs[0] && varrefs[1] == NULL);
      PAST_DECLARE_TYPED(varref, v, varrefs[0]);
      v->symbol->declaration = vardecls[i];
      s_symbol_t* syms;
      if (v->symbol->sym_table)
	for (syms = v->symbol->sym_table->symbols; syms; syms = syms->next)
	  if (syms == v->symbol || symbol_parent_find (syms, v->symbol))
	    syms->declaration = vardecls[i];
    }
}

/**
 * Loop bound hoisting routines. See down for the entry point.
 *
 */
static
s_symbol_t* find_available_symbol(s_past_node_t* root,
				  s_past_node_t*** symbols)
{
  int i;
  char buffer[512];
  for (i = 0; symbols[i]; ++i)
    ;
  sprintf (buffer, "__loop_bound_%d", i);
  s_symbol_t* ret = symbol_add_from_char (NULL, buffer);
  ret->generated = 1;

  return ret;
}
static
void traverse_collect_symbs(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_varref))
    {
      int i;
      s_symbol_t** syms = data;
      PAST_DECLARE_TYPED(varref, pv, node);
      for (i = 0; syms[i] && !symbol_equal (syms[i], pv->symbol); ++i)
	;
      syms[i] = pv->symbol;
    }
}
static
void process_hoist_conditional(s_past_node_t* root,
			       s_past_node_t*** insert_at,
			       s_past_node_t** loopexpr,
			       s_past_node_t* node)
{
  // 1- Create a temporary varref.
  s_symbol_t* newvars = find_available_symbol (root, insert_at);
  s_past_node_t* vard = past_node_varref_create (newvars);
  s_past_node_t* type =
    past_node_varref_create (symbol_add_from_char (NULL, "int"));
  s_past_node_t* decl = past_node_vardecl_create (type, vard);
  s_past_node_t* newass = past_node_statement_create
    (past_node_binary_create (past_assign, decl, past_clone (*loopexpr)));
  s_symbol_t* s2 = symbol_add_from_char (NULL, newvars->name_str);
  s_past_node_t* var = past_node_varref_create (s2);
  s_past_node_t* lbexpr = *loopexpr;
  *loopexpr = var;
  // 2- Find the best place to put it.
  int nb_syms = past_count_nodetype (lbexpr, past_varref);
  s_symbol_t** syms = XMALLOC(s_symbol_t*, nb_syms + 1);
  int i;
  for (i = 0; i < nb_syms + 1; ++i)
    syms[i] = NULL;
  past_visitor (lbexpr, traverse_collect_symbs, syms, NULL, NULL);

  s_past_node_t* parent;
  s_past_node_t* before = node;
  for (parent = node->parent; parent; parent = parent->parent)
    {
      if (past_node_is_a (parent, past_for))
	{
	  PAST_DECLARE_TYPED(for, pf2, parent);
	  s_symbol_t* ls = pf2->iterator;
	  for (i = 0; syms[i] && !symbol_equal (syms[i], ls); ++i)
	    ;
	  if (! syms[i])
	    before = parent;
	  else
	    break;
	}
    }

  // 3- Store the insert_before.
  for (i = 0; insert_at[i]; ++i)
    ;
  insert_at[i] = XMALLOC(s_past_node_t*, 2);
  insert_at[i][0] = before;
  insert_at[i][1] = newass;
}
static
void traverse_is_complex_bound (s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_min) ||
      past_node_is_a (node, past_max) ||
      past_node_is_a (node, past_ceil) ||
      past_node_is_a (node, past_floor) ||
      past_node_is_a (node, past_funcall) ||
      past_node_is_a (node, past_ceild) ||
      past_node_is_a (node, past_floord) ||
      past_node_is_a (node, past_round) ||
      past_node_is_a (node, past_mul) ||
      past_node_is_a (node, past_add) ||
      past_node_is_a (node, past_sub) ||
      past_node_is_a (node, past_div) ||
      past_node_is_a (node, past_sqrt))
    {
      int* has_complex = data;
      *has_complex = 1;
    }
}
static
int is_complex_bound(s_past_node_t* node)
{
  int has_complex = 0;
  past_visitor (node, traverse_is_complex_bound, &has_complex, NULL, NULL);

  return has_complex;
}
static
void traverse_optimize_loop_bound(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_for))
    {
      PAST_DECLARE_TYPED(for, pf, node);
      if (pf->init)
	{
	  if (! past_node_is_a (pf->init, past_binary))
	    return;
	  PAST_DECLARE_TYPED(binary, pinit, pf->init);
	  if (! past_node_is_a (pinit->rhs, past_varref) &&
	      ! past_node_is_a (pinit->rhs, past_value))
	    {
	      // Hoist only bounds that contain min, max, floor, ceil, round.
	      if (is_complex_bound (pinit->rhs))
		{
		  void** args = (void**)data;
		  process_hoist_conditional (args[0], args[1], &(pinit->rhs),
					     node);
		}
	    }
	}
      if (pf->test)
	{
	  if (! past_node_is_a (pf->test, past_binary))
	    return;
	  PAST_DECLARE_TYPED(binary, ptest, pf->test);
	  // Process only simple bounds like 'i <= blabla'.
	  if (past_node_is_a (ptest->lhs, past_varref))
	    {
	      PAST_DECLARE_TYPED(varref, pv, ptest->lhs);
	      if (! symbol_equal (pv->symbol, pf->iterator))
		return;

	      // Hoist only 'complex' loop bounds.
	      if (past_node_is_a (ptest->rhs, past_varref) ||
		  past_node_is_a (ptest->rhs, past_value))
		return;
	      if (is_complex_bound (ptest->rhs))
		{
		  void** args = (void**)data;
		  process_hoist_conditional (args[0], args[1], &(ptest->rhs),
					     node);
		}
	    }
	}
    }
}
/**
 * Optimize 'for' loop bounds, by hoisting them as much as possible.
 *
 */
void
past_optimize_loop_bounds(s_past_node_t* root)
{
  int num_for_loops = past_count_for_loops (root);
  s_past_node_t*** insert_at = XMALLOC(s_past_node_t**, 2 * num_for_loops + 1);
  int i;
  for (i = 0; i < 2 * num_for_loops + 1; ++i)
    insert_at[i] = NULL;
  void* args[2]; args[0] = root; args[1] = insert_at;

  past_visitor (root, traverse_optimize_loop_bound, (void*)args, NULL, NULL);

  past_set_parent (root);
  for (i = 0; insert_at[i]; ++i)
    {
      past_replace_node (insert_at[i][0], insert_at[i][1]);
      insert_at[i][0]->next = insert_at[i][1]->next;
      insert_at[i][1]->next = insert_at[i][0];
      past_set_parent (root);
    }
}

/**
 * Functions related to super aggressive loop bound optimization.
 *
 */
/**
 * Ensure data is a NULL-terminated array of void* with at least 2 spots left.
 * Grow by increment of 10.
 *
 */
static
void* bufferize(void** data)
{
  int i;
  if (data == NULL)
    {
      data = XMALLOC(void*, 11);
      for (i = 0; i < 11; ++i)
	data[i] = NULL;
      return data;
    }
  for (i = 0; data[i]; ++i)
    ;
  if (((i + 1) % 10) == 0)
    {
      data = XREALLOC(void*, data, i + 11);
      int j;
      for (j = i; j < i + 11; ++j)
	data[j] = NULL;
    }
  return data;
}

/**
 * Returns a new varref name, which is not in newvars already, based
 * on the prototype 'proto'.
 *
 */
static
char* get_available_name(char*** newvars, char* proto, int* counter)
{
  int i;
  *newvars = bufferize((void**)*newvars);
  for (i = 0; (*newvars)[i]; ++i)
    ;
  (*newvars)[i] = XMALLOC(char, 512);
  sprintf ((*newvars)[i], "%s_%d", proto, (*counter)++);
  return (*newvars)[i];
}

/**
 * Collect all loop bound expressions, and split them into individual
 * varref assignemnts.
 *
 */
static
void traverse_split_loop_bound(s_past_node_t* node, void* data)
{
  void** mydata = (void**)data;
  if ((!past_node_is_a (node, past_max)) &&
      (!past_node_is_a (node, past_min)) &&
      (node == mydata[1] || past_node_is_a (node->parent, past_min)
       || past_node_is_a (node->parent, past_max)))
    {
      // Get a new temporary name.
      char* newname = get_available_name ((char***)&(mydata[2]),
					  "__tmp_loop_bound_",
					  (int*)(mydata[3]));
      // Create the assignment.
      s_past_node_t* fname =
	past_node_varref_create (symbol_add_from_char (NULL, newname));
      s_past_node_t* repl =
	past_node_binary_create (past_assign, fname,
				 past_clone (node));
      // Register it.
      mydata[4] = bufferize(mydata[4]);
      s_past_node_t** nodes = (s_past_node_t**) mydata[4];
      int i;
      for (i = 0; nodes[i]; ++i)
	;
      nodes[i] = repl;
    }
}

/**
 * Create a sequence of statements to compute a min/max, based on bit
 * operations.
 *
 */
static
s_past_node_t*
create_minmax_structure(s_past_node_t** nodes, int is_lb,
			s_past_node_t* loopbound)
{
  int i;
  if (nodes == NULL || nodes[0] == NULL)
    return NULL;
  if (! past_node_is_a (nodes[0], past_binary))
    return NULL;
  PAST_DECLARE_TYPED(binary, pb, nodes[0]);
  if (! past_node_is_a (loopbound, past_varref))
    return NULL;

  // Set up the declaration of the varref holding the result of the
  // min/max.
  s_past_node_t* type_int =
    past_node_varref_create (symbol_add_from_char (NULL, "int"));

  s_past_node_t* ret =
    past_node_statement_create
    (past_node_binary_create (past_assign,
			      past_node_vardecl_create
			      (type_int, past_clone (loopbound)),
			      past_clone (pb->lhs)));
  s_past_node_t** cur = &(ret->next);


  // Create the sequence of bit operations to compute a min/max.
  for (i = 1; nodes[i]; ++i)
    {
      if (! past_node_is_a (nodes[i], past_binary))
	return NULL;
      PAST_DECLARE_TYPED(binary, pb2, nodes[i]);
      // Determine the first arg. of the expression
      s_past_node_t* first;
      if (is_lb)
	first = loopbound;
      else
	first = pb2->lhs;
      s_past_node_t* stmt =
	past_node_statement_create
	(past_node_binary_create
	 (past_assign, past_clone (loopbound),
	  past_node_binary_create
	  (past_xor, past_clone (first),
	   past_node_binary_create
	   (past_band,
	    past_node_binary_create
	    (past_xor, past_clone (loopbound), past_clone (pb2->lhs)),
	    past_node_unary_create
	    (past_unaminus,
	     past_node_binary_create
	     (past_lt, past_clone (loopbound), past_clone (pb2->lhs)))))));
      *cur = stmt;
      cur = &((*cur)->next);
    }

  return ret;
}

/**
 * Hoist as high as possible the computation of loop bound
 * expressions.
 *
 */
static
void insert_at_highest_place(s_past_node_t* l,
			     s_past_node_t* e)
{
  s_past_node_t* type_int =
    past_node_varref_create (symbol_add_from_char (NULL, "int"));
  s_past_node_t* n =
    past_node_statement_create (past_node_vardecl_create (type_int, e));
  // 1. collect symbols in the expression.
  s_past_node_t** vars = past_collect_nodetype (e, past_varref);
  // 2. collect all parent loops.
  int depth = past_loop_depth (l);
  s_past_node_t* forloops[depth + 1];
  s_symbol_t* foriter[depth + 1];
  s_past_node_t* tmp = l;
  int count = 0;
  while (tmp)
    {
      if (past_node_is_a(tmp, past_for))
	{
	  PAST_DECLARE_TYPED(for, pf, tmp);
	  foriter[count] = pf->iterator;
	  forloops[count++] = tmp;
	}
      tmp = tmp->parent;
    }
  foriter[count] = NULL;
  forloops[count] = NULL;
  // 3. Find the optimal place.
  int i, j;
  for (i = 0; foriter[i]; ++i)
    {
      for (j = 0; vars[j]; ++j)
	{
	  PAST_DECLARE_TYPED(varref, v2, vars[j]);
	  if (symbol_equal (foriter[i], v2->symbol))
	    break;
	}
      if (vars[j])
	break;
    }
  // 4. Insert.
  n->next = forloops[i - 1];
  past_replace_node (forloops[i - 1], n);
}



/**
 * Optimize 'for' loop bounds, by hoisting them as much as possible.
 *
 */
void
past_super_optimize_loop_bounds(s_past_node_t* root)
{
  // Be safe.
  past_set_parent (root);

  // Collect all for loops
  int num_for_loops = past_count_for_loops (root);
  s_past_node_t** forloops = past_collect_nodetype (root, past_for);
  int i, cases;

  int counter = 0;
  void* args[5]; args[0] = NULL; args[2] = NULL;
  int buf_size = 100;
  // Array to store all loop bound expressions created.
  s_past_node_t** all_exprs = XMALLOC(s_past_node_t*, buf_size);
  for (i = 0; i < buf_size; ++i)
    all_exprs[i] = NULL;
  // For each loop, aggressively hoist the loop bounds.
  for (i = 0; i < num_for_loops; ++i)
    {
      for (cases = 0; cases <= 1; ++cases)
	{
	  PAST_DECLARE_TYPED(for, pf, forloops[i]);
	  // Retrieve the lb or ub of a loop.
	  s_past_node_t** expr = NULL;
	  if (cases == 0)
	    {
	      s_past_node_t* init = pf->init;
	      if (! past_node_is_a(init, past_assign))
		continue;
	      PAST_DECLARE_TYPED(binary, pb, init);
	      expr = &(pb->rhs);
	    }
	  else
	    {
	      s_past_node_t* test = pf->test;
	      if (! past_node_is_a(test, past_leq))
		continue;
	      PAST_DECLARE_TYPED(binary, pb, test);
	      expr = &(pb->rhs);
	    }
	  // bit flag set to 1 for upper loop bounds.
	  if (cases)
	    args[0] = (void*)0x1;
	  args[1] = *expr;
	  args[3] = &counter;
	  args[4] = NULL;
	  // Collect all sub-expressions in a loop bound, and create
	  // assign statements for each of them.
	  past_visitor (*expr, traverse_split_loop_bound, (void*)args,
			NULL, NULL);
	  int j;
	  s_past_node_t** nodes = args[4];
	  char* newname = get_available_name ((char***)&(args[2]),
					      "__final_loop_bound_",
					      (int*)(args[3]));
	  s_past_node_t* fname =
	    past_node_varref_create (symbol_add_from_char (NULL, newname));
	  // Create a set of statements to compute a min/max expression.
	  s_past_node_t* minmaxstruct =
	    create_minmax_structure (nodes, 1 - cases, fname);
	  s_past_node_t* start = NULL;
	  s_past_node_t** full_struct = &start;
	  // Insert the loop bound sub-expression computation as high
	  // as possible.
	  for (j = 0; nodes && nodes[j]; ++j)
	    insert_at_highest_place (forloops[i], nodes[j]);
	  // Concatenate the current loop to the minmax struct, and
	  // finalize the new sub-AST.
	  *full_struct = minmaxstruct;
	  while ((*full_struct)->next)
	    full_struct = &((*full_struct)->next);
	  full_struct = &((*full_struct)->next);
	  /// FIXME: LNP: Weird!
	  /* 	  past_deep_free (*expr); */
	  *expr = fname;
	  *full_struct = forloops[i];
	  // Replace the AST.
	  past_set_parent (start);
	  past_replace_node (forloops[i], start);
	  past_set_parent (root);

	  // Backup the pointers on nodes created.
	  for (j = 0; all_exprs[j]; ++j)
	    ;
	  int pos = j;
	  for (j = 0; nodes[j]; ++j)
	    {
	      if ((pos + 2) % buf_size == 0)
		{
		  buf_size += 100;
		  all_exprs = XREALLOC(s_past_node_t*, all_exprs, buf_size);
		  int k;
		  for (k = pos; k < buf_size; ++k)
		    all_exprs[k] = NULL;
		}
	      all_exprs[pos++] = nodes[j];
	    }

	  XFREE(nodes);
	}
    }

  // perform basic CSE.
  past_set_parent(root);
  int c, j, k;
  s_past_node_t* parent_loop = NULL;
  for (i = 0; all_exprs[i]; ++i)
    ;
  s_past_node_t* buffer[i + 1];
  // For each loop, recover the set of plane computation, and eliminate
  // redundant computation.
  for (i = -1; i < num_for_loops; ++i)
    {
      // Collect all expressions in this loop body.
      c = 0;
      for (j = 0; all_exprs[j]; ++j)
	{
	  s_past_node_t* pl = past_get_enclosing_node (all_exprs[j], past_for);
	  // -1 is the "loop id" for the root node (no loop).
	  if (i == -1 || pl == forloops[i])
	    buffer[c++] = all_exprs[j];
	}
      buffer[c] = NULL;

      // Remove all redundant expressions.
      for (j = 0; buffer[j]; ++j)
	{
	  // Demangle the first expression.
	  if (! past_node_is_a (buffer[j], past_assign))
	    continue;
	  PAST_DECLARE_TYPED(binary, pa1, buffer[j]);
	  for (k = j + 1; buffer[k]; ++k)
	    {
	      if (! past_node_is_a (buffer[k], past_assign))
		continue;

	      PAST_DECLARE_TYPED(binary, pa2, buffer[k]);
	      if (past_tree_are_equal (pa1->rhs, pa2->rhs))
		{
		  past_deep_free (pa2->rhs);
		  pa2->rhs = past_clone (pa1->lhs);
		}
	    }
	}
    }
  past_set_parent (root);
}



/**
 * Return the immediate enclosing node of type 'type', NULL if it does
 * not exists.
 *
 */
s_past_node_t* past_get_enclosing_node(s_past_node_t* node,
				       cs_past_node_type_t* type)
{
  if (! node)
    return NULL;
  node = node->parent;
  while (node && ! past_node_is_a (node, type))
    node = node->parent;

  return node;
}

/**
 * Return the immediate enclosing node of type 'type' in the subtree
 * dominated by 'root_subtree', NULL if it does not exists.
 *
 */
s_past_node_t* past_get_enclosing_node_subtree(s_past_node_t* node,
					       s_past_node_t* root_subtree,
					       cs_past_node_type_t* type)
{
  if (! node || node == root_subtree)
    return NULL;
  node = node->parent;
  while (node && ! past_node_is_a (node, type) && node != root_subtree)
    node = node->parent;
  if (node != root_subtree)
    return node;
  return NULL;
}


/**
 * Return the expression describing the array name (deepest LHS).
 *
 */
s_past_node_t* past_get_array_name(s_past_node_t* node)
{
  if (! node || ! past_node_is_a (node, past_arrayref))
    return NULL;
  while (node)
    {
      if (! past_node_is_a (node, past_binary))
	return NULL;
      PAST_DECLARE_TYPED(binary, pb, node);
      if (! past_node_is_a (pb->lhs, past_arrayref))
	return pb->lhs;
      node = pb->lhs;
    }

  return NULL;
}


/**
 * FIXME: Create sub-hierarchy with write and read nodes.
 */
static int is_write_node (s_past_node_t* node)
{
  if (node->type == past_inc_before ||
      node->type == past_inc_after ||
      node->type == past_dec_before ||
      node->type == past_dec_after ||
      node->type == past_vardecl ||
      node->type == past_assign ||
      node->type == past_addassign ||
      node->type == past_subassign ||
      node->type == past_mulassign ||
      node->type == past_divassign ||
      node->type == past_modassign ||
      node->type == past_andassign ||
      node->type == past_orassign ||
      node->type == past_xorassign ||
      node->type == past_lshiftassign ||
      node->type == past_rshiftassign)
      return 1;
  else
      return 0;
}
/**
 * Check if a varref symbol is read or written.
 *
 */
int past_varref_is_write_reference(s_past_varref_t* var)
{
  s_past_node_t* parent = var->node.parent;
  s_past_node_t* last = &(var->node);
  while (parent && !is_write_node (parent))
    {
      if (past_node_is_a (parent, past_arrayref))
	{
	  PAST_DECLARE_TYPED(binary, pa, parent);
	  if (pa->rhs == last)
	    return 0;
	}
      last = parent;
      parent = parent->parent;
    }
  if (parent && past_node_is_a (parent, past_binary))
    {
      PAST_DECLARE_TYPED(binary, pb, parent);
      if (pb->lhs == last)
	return 1;
      return 0;
    }

  return parent != NULL;
}


/**
 * FIXME: Create sub-hierarchy with write and read nodes.
 */
static int is_writenoread_node(s_past_node_t* node)
{
  if (node->type == past_inc_before ||
      node->type == past_inc_after ||
      node->type == past_dec_before ||
      node->type == past_dec_after ||
      node->type == past_vardecl ||
      node->type == past_assign)
      return 1;
  else
      return 0;
}
/**
 * Check if a varref symbol is written but not read.
 *
 */
int past_varref_is_writeonly_reference(s_past_varref_t* var)
{
  s_past_node_t* parent = var->node.parent;
  s_past_node_t* last = &(var->node);
  while (parent && !is_writenoread_node (parent))
    {
      if (past_node_is_a (parent, past_arrayref))
	{
	  PAST_DECLARE_TYPED(binary, pa, parent);
	  if (pa->rhs == last)
	    return 0;
	}
      last = parent;
      parent = parent->parent;
    }
  if (parent && past_node_is_a (parent, past_binary))
    {
      PAST_DECLARE_TYPED(binary, pb, parent);
      if (pb->lhs == last)
	return 1;
      return 0;
    }

  return parent != NULL;
}


static
void
traverse_past_encaps(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_arrayref))
    {
      // postfix rewriting.
      if (past_node_is_a (node->parent, past_arrayref))
	return;
      // 1- count the array depth.
      int dim = 0;
      s_past_node_t* tmp = node;
      s_past_binary_t* bin;
      while (past_node_is_a (tmp, past_arrayref))
	{
	  bin = (s_past_binary_t*)tmp;
	  tmp = bin->lhs;
	  ++dim;
	}
      // 2- Collect the index expressions, and original arrayref pointers.
      s_past_node_t* exprs[dim];
      s_past_node_t* aref[dim];
      s_past_node_t* tmp2 = node;
      int count = dim - 1;
      while (past_node_is_a (tmp2, past_arrayref))
	{
	  aref[count] = tmp2;
	  PAST_DECLARE_TYPED(binary, tp, tmp2);
	  exprs[count--] = tp->rhs;
	  tmp2 = tp->lhs;
	}
      // 3- Collect the array name.
      assert (past_node_is_a (bin->lhs, past_varref));
      s_past_varref_t* var = (s_past_varref_t*)bin->lhs;

      // 4- See if it is a read or a write reference.
      int is_write = past_varref_is_write_reference (var);

      // 5- Create the replacement node. Prototype function call:
      // __past_arrayref_{read,write}_{x}d(...)
      char call[64];
      sprintf (call, "__past_arrayref_%s_%dd",
	       is_write ? "write" : "read", dim);
      s_past_node_t* args = NULL;
      s_past_node_t* cur;
      for (count = 0; count < dim; ++count)
	if (args == NULL)
	  cur = args = exprs[count];
	else
	  cur = cur->next = exprs[count];
      s_past_node_t* fname =
	past_node_varref_create (symbol_add_from_char (NULL, call));
      s_past_node_t* repl =
	past_node_funcall_create (fname, args);
      if (is_write)
	repl = past_node_unary_create (past_derefof, repl);

      // 6- Replace the current node by the function call.
      past_replace_node (node, repl);

      // 7- Delete the trailing arrayref nodes.
      for (count = 0; count < dim; ++count)
	XFREE(aref[count]);
    }
}
/**
 * Replace all array references by an API-specified function call.
 *
 * E.g:
 * A[i+42][j] = ... is replaced by *__past_arrayref_write_2d(A, i+42, j) = ...
 *
 */
s_past_node_t* past_encapsulate_arrayref_in_func(s_past_node_t* root)
{
  if (past_node_is_a (root, past_arrayref))
    {
      s_past_node_t* fkroot = past_node_root_create (NULL, root);
      past_visitor (fkroot, NULL, NULL, traverse_past_encaps, NULL);
      PAST_DECLARE_TYPED(root, r, fkroot);
      root = r->body;
      XFREE(fkroot);
    }
  else if (root)
    past_visitor (root, NULL, NULL, traverse_past_encaps, NULL);

  return root;
}


static
s_symbol_t** past_collect_rw_symbols(s_past_node_t* node,
				     int read_syms, int array_syms,
				     int affineexpr_syms,
				     int noloopiter)
{
  int num_var = past_count_nodetype (node, past_varref);
  s_symbol_t** ret = XMALLOC(s_symbol_t*, num_var + 1);
  s_symbol_t** allsyms = XMALLOC(s_symbol_t*, num_var + 1);

  s_past_node_t** nodes = past_collect_nodetype (node, past_varref);
  int i, j;
  for (i = 0; i < num_var; ++i)
    {
      ret[i] = NULL;
      PAST_DECLARE_TYPED(varref, pv, nodes[i]);
      allsyms[i] = pv->symbol;
    }
  ret[i] = allsyms[i] = NULL;

  for (i = 0; nodes[i]; ++i)
    {
      PAST_DECLARE_TYPED(varref, var, nodes[i]);
      s_symbol_t* s = var->symbol;
      // Skip symbols which are parent of another symbol.
      for (j = 0; allsyms[j]; ++j)
	if (symbol_parent_find (allsyms[j], s))
	  break;
      if (allsyms[j])
	continue;

      // Ensure the symbol is not already in the set.
      for (j = 0; ret[j]; ++j)
      	if (symbol_equal (ret[j], s))
      	  break;
      if (ret[j])
      	continue;
      if (noloopiter)
	{
	  // skip reference of the 'increment' clause of the for loop.
	  s_past_node_t* parent = nodes[i]->parent;
	  while (parent && ! past_node_is_a (parent, past_for))
	    parent = parent->parent;
	  if (parent)
	    {
	      PAST_DECLARE_TYPED(for, pf, parent);
	      if (symbol_equal (pf->iterator, var->symbol))
		continue;
	    }
	}

      // Check the properties of the reference.
      int is_write = past_varref_is_write_reference (var);
      int is_read = ! past_varref_is_writeonly_reference (var);
      int is_array = 0;
      if (nodes[i]->parent && past_node_is_a (nodes[i]->parent, past_arrayref))
      	{
      	  PAST_DECLARE_TYPED(binary, ar, nodes[i]->parent);
      	  if (ar->lhs == nodes[i])
	    is_array = 1;
      	}
      int is_affineexpr = 0;
      s_past_node_t* tmp = past_get_enclosing_node (nodes[i], past_arrayref);
      if (tmp)
	{
	  PAST_DECLARE_TYPED(binary, pb, tmp);
	  if (pb->lhs == nodes[i])
	    is_affineexpr = 0;
	  else is_affineexpr = 1;
	}
      else
	is_affineexpr = past_get_enclosing_node
	  (nodes[i], past_statement) == NULL;

      // Add the symbol if necessary.
      if (is_read && read_syms && !array_syms && !affineexpr_syms)
	ret[j] = s;
      else if (is_write && !read_syms && !array_syms && !affineexpr_syms)
	ret[j] = s;
      else if (is_array && array_syms && !affineexpr_syms)
	ret[j] = s;
      else if (is_affineexpr && !array_syms && affineexpr_syms)
	ret[j] = s;
    }
  XFREE(nodes);

  return ret;
}

/**
 * Return a null-terminated set of unique symbols being read in any
 * affine expression in the tree. By construction those should be
 * integers.
 *
 */
s_symbol_t** past_collect_affineexpr_symbols(s_past_node_t* node)
{
  return past_collect_rw_symbols (node, 0, 0, 1, 0);
}

/**
 * Return a null-terminated set of unique symbols being read in the
 * tree.
 *
 */
s_symbol_t** past_collect_read_symbols(s_past_node_t* node)
{
  return past_collect_rw_symbols (node, 1, 0, 0, 0);
}

/**
 * Return a null-terminated set of unique symbols being written in the
 * tree.
 *
 */
s_symbol_t** past_collect_write_symbols(s_past_node_t* node)
{
  return past_collect_rw_symbols (node, 0, 0, 0, 0);
}

/**
 * Return a null-terminated set of unique symbols being written in the
 * tree, minus the loop iterators.
 *
 */
s_symbol_t** past_collect_write_symbols_noloopiter(s_past_node_t* node)
{
  return past_collect_rw_symbols (node, 0, 0, 0, 1);
}

/**
 * Return a null-terminated set of unique symbols being read-only in the
 * tree.
 *
 */
s_symbol_t** past_collect_readonly_symbols(s_past_node_t* node)
{
  s_symbol_t** symsr = past_collect_read_symbols (node);
  s_symbol_t** symsw = past_collect_write_symbols (node);
  int i, j;
  for (i = 0; symsr && symsr[i]; ++i)
    ;
  s_symbol_t** ret = XMALLOC(s_symbol_t*, i + 1);
  int pos = 0;
  for (i = 0; symsr && symsr[i]; ++i)
    {
      for (j = 0; symsw && symsw[j]; ++j)
	if (symbol_equal(symsr[i], symsw[j]))
	  break;
      if (! symsw[j])
	ret[pos++] = symsr[i];
    }
  ret[pos] = NULL;
  XFREE(symsr);
  XFREE(symsw);
  return ret;
}

/**
 * Return a null-terminated set of unique array symbols in the tree.
 *
 */
s_symbol_t** past_collect_array_symbols(s_past_node_t* node)
{
  return past_collect_rw_symbols (node, 0, 1, 0, 0);
}

/**
 * Return a null-terminated set of unique loop iterator symbols
 * assigned in the tree.
 *
 */
s_symbol_t** past_collect_written_loopiterators_symbols(s_past_node_t* node)
{
  s_past_node_t** loops = past_collect_nodetype (node, past_for);
  int num_loops = past_count_nodetype (node, past_for);
  s_symbol_t** res = XMALLOC(s_symbol_t*, num_loops + 1);
  int i, j;
  for (i = 0; i <= num_loops; ++i)
    res[i] = NULL;
  for (i = 0; loops && loops[i]; ++i)
    {
      PAST_DECLARE_TYPED(for, pf, loops[i]);
      s_symbol_t* s = pf->iterator;
      for (j = 0; j < i && res[j] != s; ++j)
	;
      res[j] = s;
    }
  XFREE(loops);

  return res;
}

static
int is_included(s_symbol_t* s, s_symbol_t** syms)
{
  int i;
  for (i = 0; syms && syms[i]; ++i)
    if (s == syms[i])
      return 1;
  return 0;
}

/**
 * Return true if the for stride is +1.
 *
 */
int past_for_is_stride_one(s_past_for_t* f)
{
  s_past_node_t* inc = f->increment;
  if (past_node_is_a (inc, past_inc_before) ||
      past_node_is_a(inc, past_inc_after))
    return 1;
  if (past_node_is_a (inc, past_binary))
    {
      PAST_DECLARE_TYPED(binary, pb, inc);
      if (! past_node_is_a (pb->lhs, past_varref))
	return 0;
      PAST_DECLARE_TYPED(varref, pv, pb->lhs);
      if (! symbol_equal (pv->symbol, f->iterator))
	return 0;
      if (past_node_is_a (pb->rhs, past_binary))
	{
	  if (! past_node_is_a (pb->rhs, past_add))
	    return 0;
	  PAST_DECLARE_TYPED(binary, pb2, pb->rhs);
	  if (! past_node_is_a (pb2->lhs, past_varref))
	    return 0;
	  PAST_DECLARE_TYPED(varref, pv2, pb2->lhs);
	  if (! symbol_equal (pv2->symbol, f->iterator))
	    return 0;
	  if (! past_node_is_a (pb2->rhs, past_value))
	    return 0;
	  PAST_DECLARE_TYPED(value, pvv, pb2->rhs);
	  if (pvv->value.intval != 1)
	    return 0;
	  return 1;
	}
      else
	{
	  if (! past_node_is_a (inc, past_addassign))
	    return 0;
	  if (! past_node_is_a (pb->rhs, past_value))
	    return 0;
	  PAST_DECLARE_TYPED(value, pvv, pb->rhs);
	  if (pvv->value.intval != 1)
	    return 0;
	  return 1;
	}
    }
  return 0;
}


static
void
traverse_past_array_dimensions(s_past_node_t * s, void * data )
{
  int * pdim = ((void**)data)[1];
  if ( *pdim ) return;
  if ( past_node_is_a ( s, past_varref ) )
    {
      char * aname =  ((void**)data)[0];
      PAST_DECLARE_TYPED ( varref, pv, s );
      if ( strcmp ( aname, pv->symbol->name_str ) ) return;
      *pdim = 0;
      s_past_node_t * p;
      for ( p = s->parent; past_node_is_a ( p, past_arrayref ); p = p->parent ) (*pdim)++;
    }
}

int
past_get_array_dimensions(s_past_node_t * node, s_symbol_t * array )
{
  int i;
  int d = 0;
  char * aname = array->name_str;
  void * data[2];
  data[0] = aname;
  data[1] = &d;
  past_visitor ( node, traverse_past_array_dimensions, data, NULL, NULL );
  return d;
}

//static
void
traverse_past_simdf(s_past_node_t* node, void* data)
{
  if (past_node_is_a (node, past_parfor))
    {
      s_past_node_t** il = past_inner_loops (node);
      if (il && il[0] == node)
	{
	  // Ensure it is a SIMD loop, or a decorated loop.
	  PAST_DECLARE_TYPED(for, pf, node);
	  /// FIXME: Temporary assume that any SIMD loop is not
	  /// stride-1 and/or decorated with some random decoration.
	  if (node->decoration == NULL && past_for_is_stride_one (pf))
	    return;

	  // Recover the data.
	  s_past_node_t** fundecls = ((void**)data)[0];
	  int* loop_cnt = ((void**)data)[1];
    int* update = ((void**)data)[2];

	  // 1- Collect all read, written and array symbols.
	  s_past_node_t* lnext = node->next;
	  node->next = NULL;
	  s_symbol_t** read = past_collect_read_symbols (node);
	  s_symbol_t** write = past_collect_write_symbols (node);
	  s_symbol_t** arrays = past_collect_array_symbols (node);
	  s_symbol_t** affineexpr = past_collect_affineexpr_symbols (node);
	  s_symbol_t** loopiters =
	    past_collect_written_loopiterators_symbols (node);
	  node->next = lnext;

	  // 2- Create the function call.
	  char call[64];
	  sprintf (call, "__past_loop_%d", (*loop_cnt));
    if (*update) (*loop_cnt)++;
	  s_past_node_t* fname =
	    past_node_varref_create (symbol_add_from_char (NULL, call));
	  // Create arguments. All written non-array references are passed by
	  // address.
	  s_past_node_t* args = NULL;
	  s_past_node_t* cur;
	  int i;
	  for (i = 0; read[i]; ++i)
	    {
	      // Skip references also written.
	      if (is_included (read[i], write))
		continue;
	      //printf ("R sym: %s\n", read[i]->name_str);
	      s_past_node_t* vref =
		past_node_varref_create (read[i]);
	      if (args == NULL)
		cur = args = vref;
	      else
		cur = cur->next = vref;
	    }
	  for (i = 0; write[i]; ++i)
	    {
	      //printf ("W sym: %s\n", write[i]->name_str);
	      s_past_node_t* vref =
		past_node_varref_create (write[i]);
	      if (! is_included (write[i], arrays))
		vref = past_node_unary_create (past_addressof, vref);

	      if (args == NULL)
		cur = args = vref;
	      else
		cur = cur->next = vref;
	    }
	  // Create function call, and replace.
	  s_past_node_t* fcall =
			past_node_statement_create (
	      past_node_funcall_create (fname, args));
	  past_replace_node (node, fcall);
	  fcall->next = node->next;
	  node->next = NULL;

	  // 3- Create function prototype.
	  s_past_node_t* datatype = past_node_varref_create
	    (symbol_add_from_char (NULL, "DATA_TYPE"));
	  s_past_node_t* inttype = past_node_varref_create
	    (symbol_add_from_char (NULL, "int"));
	  s_past_node_t* type;
	  args = NULL;
	  for (i = 0; read[i]; ++i)
	    {
	      // Skip references also written.
	      if (is_included (read[i], write))
		continue;

	      s_past_node_t* vref = NULL;
	      // Compute the scalar type.
	      if (is_included (read[i], affineexpr))
		type = past_clone (inttype);
	      else
		type = past_clone (datatype);
	      // 3.a- Arrays.
	      if (is_included (read[i], arrays))
		{
		  // For array A[..], create 'DATA_TYPE DECL_ARRAY_A(A)'
		  vref = past_node_varref_create (read[i]);
		  char macro[64];
		  sprintf (macro, "DECL_ARRAY_%s", (char*)read[i]->name_str);
		  s_past_node_t* mcall = past_node_varref_create
		    (symbol_add_from_char (NULL, macro));
		  vref = past_node_funcall_create
		    (mcall, vref);
		  vref = past_node_vardecl_create (type, vref);
		}
	      // 3.b- Any other.
	      else
		{
		  vref = past_node_varref_create (read[i]);
		  vref = past_node_vardecl_create (type, vref);
		}
	      if (args == NULL)
		cur = args = vref;
	      else
		cur = cur->next = vref;
	    }
	  for (i = 0; write[i]; ++i)
	    {
	      s_past_node_t* vref = NULL;
	      // Compute the scalar type.
	      if (is_included (write[i], affineexpr))
		type = past_clone (inttype);
	      else
		type = past_clone (datatype);
	      // 3.a- Arrays.
	      if (is_included (write[i], arrays))
		{
		  // For array A[..], create 'DATA_TYPE DECL_ARRAY_A(A)'
		  vref = past_node_varref_create (write[i]);
		  char macro[64];
		  sprintf (macro, "DECL_ARRAY_%dD",
			   past_get_array_dimensions(node,write[i]));
		  s_past_node_t* mcall = past_node_varref_create
		    (symbol_add_from_char (NULL, macro));
		  vref = past_node_funcall_create
		    (mcall, vref);
		  vref = past_node_vardecl_create (type, vref);
		}
	      // 3.b- Any other (use local name to avoid pointers
	      // inside the loop body).
	      else
		{
		  char buff[256];
		  sprintf (buff, "__local_%s", (char*)write[i]->name_str);
		  vref = past_node_varref_create
		    (symbol_add_from_char (NULL, buff));
		  vref = past_node_unary_create (past_derefof, vref);
		  vref = past_node_vardecl_create (type, vref);
		}
	      if (args == NULL)
		cur = args = vref;
	      else
		cur = cur->next = vref;
	    }
	  // Create the prototype of the definition.
	  s_past_node_t* voidtype =
	    past_node_varref_create (symbol_add_from_char (NULL, "void"));
	  s_past_fundecl_t* fundecl =
	    past_fundecl_create (voidtype, past_clone(fname), args, NULL);

	  // 4- Insert decl/copy statements for the written non-array
	  // symbols.
	  s_past_node_t* decls = NULL;
	  s_past_node_t* copies = NULL;
	  s_past_node_t* cur2 = NULL;
	  cur = NULL;
	  for (i = 0; write[i]; ++i)
	    {
	      if (! is_included (write[i], arrays))
		{
		  s_past_node_t* vref =
		    past_node_varref_create (write[i]);
		  // Compute the scalar type.
		  s_past_node_t* type;
		  if (is_included (read[i], affineexpr))
		    type = past_clone (inttype);
		  else
		    type = past_clone (datatype);
		  vref = past_node_vardecl_create (type, vref);
		  char buff[256];
		  sprintf (buff, "__local_%s", (char*)write[i]->name_str);
		  s_past_node_t* vref2 = past_node_varref_create
		    (symbol_add_from_char (NULL, buff));
		  vref2 = past_node_unary_create (past_derefof, vref2);
		  s_past_node_t* decl =
		    past_node_binary_create (past_assign, vref, vref2);
		  decl = past_node_statement_create (decl);
		  if (decls == NULL)
		    cur = decls = decl;
		  else
		    cur = cur->next = decl;
		  vref = past_node_varref_create (write[i]);
		  vref2 = past_clone (vref2);
		  s_past_node_t* copy =
		    past_node_binary_create (past_assign, vref2, vref);
		  copy = past_node_statement_create (copy);
		  if (copies == NULL)
		    cur2 = copies = copy;
		  else
		    cur2 = cur2->next = copy;
		}
	    }
	  // Finalize the function definition.
	  if (decls)
	    cur->next = node;
	  s_past_node_t* bb = past_node_block_create (decls);
	  s_past_node_t* block;
	  if (decls)
	    {
	      block = decls;
	      cur->next = node;
	    }
	  else
	    block = node;
	  node->next = copies;
	  fundecl->body = block;

	  // 5- Store the new definition in the list.
	  for (i = 0; fundecls[i]; ++i)
	    ;
	  fundecls[i] = (s_past_node_t*)fundecl;

	  // Be clean.
	  XFREE(read);
	  XFREE(write);
	  XFREE(arrays);
	  XFREE(affineexpr);
	  XFREE(loopiters);
	}
      else
	XFREE(il);
    }
}

/**
 * Replace all inner-most SIMD loop by an API-specified function call.
 *
 * E.g:
 * for (i = 0; i < N; i += 2)
 *   A[k][i] *= alpha;
 * is replaced by:
 * __past_loop_1(&i, N, k, A, alpha)
 *
 * And a new tree is created and contains:
 *
 * void __past_loop_1(int* i_ptr, int N, int k, DATA_TYPE PAST_DECL_A A,
 *                    DATA_TYPE alpha) {
 *  int i = *i_ptr;
 *  for (i = 0; i < N; i += 2)
 *     A[k][i] *= alpha;
 *  *i_ptr = i;
 * }
 *
 */
s_past_node_t*
past_encapsulate_simd_loops_in_func(s_past_node_t** root)
{
  if (!root || !*root)
    return NULL;
  int num_loops = past_count_nodetype (*root, past_for);
  s_past_node_t** fundecls = XMALLOC(s_past_node_t*, num_loops + 1);
  int i;
  for (i = 0; i < num_loops + 1; ++i)
    fundecls[i] = NULL;
  int loop_counter = 0;
  int update = 1;
  void* args[3]; args[0] = fundecls; args[1] = &loop_counter; args[2] = &update;
  if (past_node_is_a (*root, past_for))
    {
      s_past_node_t* fkroot = past_node_root_create (NULL, *root);
      past_rebuild_symbol_table (fkroot);
      past_visitor (fkroot, NULL, NULL, traverse_past_simdf, (void*)args);
      past_rebuild_symbol_table (fkroot);
      PAST_DECLARE_TYPED(root, r, fkroot);
      XFREE(r->symboltable->symbols);
      XFREE(r->symboltable);
      *root = r->body;
      XFREE(fkroot);
    }
  else
    {
      past_rebuild_symbol_table (*root);
      past_visitor (*root, NULL, NULL, traverse_past_simdf, (void*)args);
      past_rebuild_symbol_table (*root);
    }

  for (i = 0; fundecls[i]; ++i)
    fundecls[i]->next = fundecls[i + 1];

  return fundecls[0];
}

/**
 * Replace all inner-most SIMD loop by an API-specified function call.
 *
 * E.g:
 * for (i = 0; i < N; i += 2)
 *   A[k][i] *= alpha;
 * is replaced by:
 * __past_loop_1(N, k, alpha, A, &i)
 *
 * And a separate file 'filename' is created and contains:
 *
 * void __past_loop_1(int N, int k, DATA_TYPE alpha, DATA_TYPE PAST_DECL_A(A),
 *                    int* __local_i) {
 *  int i = *__local_i;
 *  for (i = 0; i < N; i += 2)
 *     A[k][i] *= alpha;
 *  *__local_i = i;
 * }
 *
 */
void
past_encapsulate_simd_loops_in_func_file(s_past_node_t* root,
					 char* filename)
{
  FILE* loop_file = fopen (filename, "w");
  s_past_node_t* fundecls = past_encapsulate_simd_loops_in_func (&root);
  s_past_node_t* r = past_node_root_create (NULL, fundecls);
  past_pprint (loop_file, r);
  past_deep_free (r);
  fclose (loop_file);
}

/**
 * Returns 1 if the two trees represent the same structure, 0 otherwise.
 *
 */
int
past_tree_are_equal(s_past_node_t* t1, s_past_node_t* t2)
{
  // DFS on the first tree.
  s_past_node_t** nt1 = past_collect_nodetype (t1, past_node);
  // DFS on the second tree.
  s_past_node_t** nt2 = past_collect_nodetype (t2, past_node);

  int i;
  for (i = 0; nt1[i] && nt2[i]; ++i)
    {
      // Type check.
      if (nt1[i]->type != nt2[i]->type)
	break;
      // Value check.
      if (past_node_is_a (nt1[i], past_varref))
	{
	  PAST_DECLARE_TYPED(varref, pv1, nt1[i]);
	  PAST_DECLARE_TYPED(varref, pv2, nt2[i]);
	  if (! symbol_equal (pv1->symbol, pv2->symbol))
	    break;
	}
      else if (past_node_is_a (nt1[i], past_value))
	{
	  PAST_DECLARE_TYPED(value, pv1, nt1[i]);
	  PAST_DECLARE_TYPED(value, pv2, nt2[i]);
	  if (pv1->value.longdoubleval != pv2->value.longdoubleval)
	    break;
	}
      else if (past_node_is_a (nt1[i], past_string))
	{
	  PAST_DECLARE_TYPED(string, pv1, nt1[i]);
	  PAST_DECLARE_TYPED(string, pv2, nt2[i]);
	  if (strcmp (pv1->data, pv2->data))
	    break;
	}
      // Generic.
      else if (past_node_is_a (nt1[i], past_generic))
	{
	  PAST_DECLARE_TYPED(generic, pg1, nt1[i]);
	  PAST_DECLARE_TYPED(generic, pg2, nt2[i]);
	  int has_char_data =
	    (pg1->char_data != NULL) + (pg2->char_data != NULL);
	  int has_ptr_data =
	    (pg1->ptr_data != NULL) + (pg2->ptr_data != NULL);
	  if (has_char_data == 2)
	    if (strcmp (pg1->char_data, pg2->char_data))
	      break;
	  if (has_ptr_data == 2)
	    if (pg1->ptr_data != pg2->ptr_data)
	      break;
	}
    }
  if (nt1[i] || nt2[i])
    return 0;
  return 1;
}


/**
 * Check if the PAST tree is well-formed (pointer checks).
 *
 */
int
past_consistency_check(s_past_node_t* root, int verbose)
{
  if (verbose > 1)
    {
      printf ("[PAST] Checking consistency of tree:\n");
      past_pprint (stdout, root);
    }
  // Check consistency of pointers.
  int num_ptr_errors = 0;
  s_past_node_t** all_nodes = past_collect_nodetype (root, past_node);
  int i, j;
  for (i = 0; all_nodes && all_nodes[i]; ++i)
    for (j = i + 1; all_nodes && all_nodes[j]; ++j)
      if (all_nodes[i] == all_nodes[j])
	{
	  num_ptr_errors++;
	  if (verbose > 1)
	    {
	      printf ("[PAST][WARNING] node #%d (%p) duplicate with node #%d (%p):\n", i, all_nodes[i], j, all_nodes[j]);
	      past_pprint (stdout, all_nodes[i]);
	      printf ("\n");
	    }
	}

  if (verbose)
    {
      if (num_ptr_errors)
	fprintf (stderr,
		 "[PAST][ERROR] Consistency check fails: %d ptr errors\n",
		 num_ptr_errors);
    }

  return num_ptr_errors;
}



/**
 * Fixup the AST structure.
 *
 */
void
past_ast_fixup_structure(s_past_node_t* node)
{
  past_set_parent (node);
  // Put vardecls in statements.
  s_past_node_t** vardecls =
    past_collect_nodetype_postfix (node, past_vardecl);
  int i;
  for (i = 0; vardecls && vardecls[i]; ++i)
    {
      PAST_DECLARE_TYPED(vardecl, pv, vardecls[i]);
      if (! past_get_enclosing_node (vardecls[i], past_statement))
	{
	  s_past_node_t* stm = past_node_statement_create (NULL);
	  PAST_DECLARE_TYPED(statement, ps, stm);
	  s_past_node_t* stmnext = vardecls[i]->next;
	  vardecls[i]->next = NULL;
	  past_replace_node (vardecls[i], stm);
	  ps->body = vardecls[i];
	  ps->body->parent = stm;
	  stm->next = stmnext;
	}
    }
  XFREE(vardecls);
  past_set_parent (node);
  past_consistency_check (node, 0);

  // Put loop bodies in BBs.
  s_past_node_t** fors =
    past_collect_nodetype (node, past_for);
  for (i = 0; fors && fors[i]; ++i)
    {
      PAST_DECLARE_TYPED(for, pf, fors[i]);
      if (pf->body->next)
	{
	  s_past_node_t* bb = past_node_block_create (NULL);
	  s_past_node_t* stmnext = pf->body->next;
	  s_past_node_t* forbody = pf->body;
	  pf->body->next = NULL;
	  past_replace_node (pf->body, bb);
	  PAST_DECLARE_TYPED(block, pb, bb);
	  pb->body = forbody;
	  pb->body->next = stmnext;
	}
    }
  XFREE(fors);
  past_set_parent (node);
  past_consistency_check (node, 0);

  // Put conditional bodies in BBs.
  s_past_node_t** ifs =
    past_collect_nodetype (node, past_if);
  for (i = 0; ifs && ifs[i]; ++i)
    {
      PAST_DECLARE_TYPED(if, pf, ifs[i]);
      if (pf->then_clause->next)
	{
	  s_past_node_t* bb = past_node_block_create (NULL);
	  s_past_node_t* stmnext = pf->then_clause->next;
	  s_past_node_t* thenclause = pf->then_clause;
	  pf->then_clause->next = NULL;
	  past_replace_node (pf->then_clause, bb);
	  PAST_DECLARE_TYPED(block, pb, bb);
	  pb->body = thenclause;
	  pb->body->next = stmnext;
	}
      if (pf->else_clause->next)
	{
	  s_past_node_t* bb = past_node_block_create (NULL);
	  s_past_node_t* stmnext = pf->else_clause->next;
	  s_past_node_t* elseclause = pf->else_clause;
	  pf->else_clause->next = NULL;
	  past_replace_node (pf->else_clause, bb);
	  PAST_DECLARE_TYPED(block, pb, bb);
	  pb->body = elseclause;
	  pb->body->next = stmnext;
	}
    }
  XFREE(ifs);
  past_set_parent (node);
  past_consistency_check (node, 0);

  // Put affineguard bodies in BBs.
  s_past_node_t** afs =
    past_collect_nodetype (node, past_affineguard);
  for (i = 0; afs && afs[i]; ++i)
    {
      PAST_DECLARE_TYPED(if, pf, afs[i]);
      if (pf->then_clause->next)
	{
	  s_past_node_t* bb = past_node_block_create (NULL);
	  s_past_node_t* stmnext = pf->then_clause->next;
	  s_past_node_t* thenclause = pf->then_clause;
	  pf->then_clause->next = NULL;
	  past_replace_node (pf->then_clause, bb);
	  PAST_DECLARE_TYPED(block, pb, bb);
	  pb->body = thenclause;
	  pb->body->next = stmnext;
	}
    }
  XFREE(afs);
  past_set_parent (node);
  past_consistency_check (node, 0);
}



/**
 *
 *
 *
 */
void past_dce(s_past_node_t* node)
{
  // Collect read symbols.
  s_symbol_t** reads = past_collect_read_symbols (node);

  // Collect write symbols.
  s_symbol_t** writes = past_collect_read_symbols (node);

}


/**
 * Returns true if the loops in the tree dominated by 'node' contains
 * a single perfectly-nested loop nest (possibly with conditionals).
 *
 */
int
past_is_perfectly_nested_loop_nest(s_past_node_t* node)
{
  s_past_node_t* next = node->next;
  node->next = NULL;
  int nb_fors = past_count_nodetype (node, past_for);
  if ((past_max_loop_depth (node) != nb_fors) || nb_fors == 0)
    {
      node->next = next;
      return 0;
    }
  // Now check if there's any statement apart from the inner-most loop.
  s_past_node_t** inner = past_inner_loops (node);
  assert(inner && inner[0] && !inner[1]);
  s_past_node_t** stmts = past_collect_nodetype (node, past_statement);
  int i;
  int ret = 1;
  for (i = 0; stmts && stmts[i]; ++i)
    if (past_get_enclosing_node (stmts[i], past_for) != inner[0])
      {
	ret = 0;
	break;
      }
  XFREE(stmts);
  if (ret)
    {
      stmts = past_collect_nodetype (node, past_cloogstmt);
      for (i = 0; stmts && stmts[i]; ++i)
	if (past_get_enclosing_node (stmts[i], past_for) != inner[0])
	  {
	    ret = 0;
	    break;
	  }
    }
  XFREE(stmts);
  node->next = next;
  return ret;
}



/**
 * Returns true if there is no triangular loop in the tree dominated
 * by node.
 *
 */
int
past_has_only_rectangular_loops(s_past_node_t* node)
{
  s_past_node_t* next = node->next;
  node->next = NULL;
  // 1. Collect all loop iterators.
  s_symbol_t** its = past_collect_written_loopiterators_symbols (node);
  if (! its || !its[0])
    {
      node->next = next;
      // Return false if there is no loop at all!
      return 0;
    }
  // 2. Collect all for loops.
  s_past_node_t** forloops = past_collect_nodetype (node, past_for);
  int i, j, k;
  for (i = 0; forloops && forloops[i]; ++i)
    {
      // Ensure another loop iterator symbol than the current loop
      // iterator does not appear in any of the for loop expression.
      PAST_DECLARE_TYPED(for, pf, forloops[i]);
      int iter_idx;
      for (j = 0; its[j]; ++j)
	if (symbol_equal (its[j], pf->iterator))
	  break;
      iter_idx = j;
      assert (its[j]);
      s_symbol_t** bound_syms = past_collect_read_symbols (pf->init);
      for (j = 0; its[j]; ++j)
	for (k = 0; bound_syms && bound_syms[k]; ++k)
	  if (j != iter_idx && symbol_equal (its[j], bound_syms[k]))
	    {
	      XFREE(bound_syms);
	      XFREE(its);
	      node->next = next;
	      return 0;
	    }
      XFREE(bound_syms);
      bound_syms = past_collect_read_symbols (pf->test);
      for (j = 0; its[j]; ++j)
	for (k = 0; bound_syms && bound_syms[k]; ++k)
	  if (j != iter_idx && symbol_equal (its[j], bound_syms[k]))
	    {
	      XFREE(bound_syms);
	      XFREE(its);
	      node->next = next;
	      return 0;
	    }
      XFREE(bound_syms);
    }

  XFREE(its);
  node->next = next;
  return 1;
}
