#!/bin/sh
# bootstrap.sh: This file is part of the PAST project.
# 
# PAST: the PoCC Abstract Syntax Tree
#
# Copyright (C) 2014 the Ohio State University
#
# This program can be redistributed and/or modified under the terms
# of the license specified in the LICENSE.txt file at the root of the
# project.
#
# Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
# Author: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
#
#
aclocal -I config
libtoolize --force --copy
autoreconf -vfi
