/*
 * legal.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/legal.h>
#include <ponos/space.h>

#define PONOS_SPACE_FARKAS_NORMAL	1
#define PONOS_SPACE_FARKAS_COMM_BOUND	2

# include <fm/piptools-gmp.h>

/**
 * Debug function.
 *
 */
static
void debug_system (s_fm_system_t* s)
{
  PipQuast* sol = fm_piptools_pip (s, NULL, FM_PIPTOOLS_INT);
  pip_quast_print (stdout, sol, 0);
  pip_quast_free (sol);
}

/**
 * Debug function.
 *
 */
static
void debug_solution (s_fm_solution_t* so)
{
  s_fm_system_t* s = fm_solution_to_system (so);
  debug_system (s);
  fm_system_free (s);
}


/**
 * Convenience function to handle dynamically sized arrays.
 *
 */
static
s_ponos_var_t**
bufferize (s_ponos_var_t** array, int* dim)
{
  int i;
  for (i = 0; array[i]; ++i)
    ;
  if (((i + 2) % (*dim)) == 0)
    {
      (*dim) += 128;
      array = XREALLOC(s_ponos_var_t*, array, *dim);
      for (; i < (*dim); ++i)
	array[i] = NULL;
    }
  return array;
}


/**
 * Creates the full scheduling space, without any constraint.
 *
 * Space is organized as follows:
 * [ D1,1 D2,1 ... R1,1 R1,2 ... U1,1, U2,1...Un,2... iS1,1 jS1,1 iS2,1 ... iS1,2 ...]
 *
 * where in notation x,y x represents the id of the
 * dependence/statement, y represents the schedule dimension (0 to
 * max_sched_dim-1).
 *
 */
s_ponos_space_t*
ponos_legal_build_universe (scoplib_scop_p scop,
			    CandlDependence* deps,
			    int max_sched_dim,
			    s_ponos_options_t* options)
{
  int dim;
  s_ponos_var_t** all_vars = NULL;
  int num_par = scop->context->NbColumns - 2;
  int total_vars = 0;
  char buffer[512];
  int theta_var_lower_bound, theta_var_upper_bound;
  if (options->schedule_coefs_are_pos)
    theta_var_lower_bound = 0;
  else
    theta_var_lower_bound = -options->schedule_bound;
  theta_var_upper_bound = options->schedule_bound;
  for (dim = 0; dim < max_sched_dim; ++dim)
    {
      int i;
      // 1. Compute the schedule coefficients.
      int tot_sched_var = 0;
      scoplib_statement_p tmp;
      int stmt_count = 0;
      int dims_iter = 128;
      int dims_par = 128;
      int dims_cst = 128;

      s_ponos_var_t** vars_sched_it = XMALLOC(s_ponos_var_t*, dims_iter);
      s_ponos_var_t** vars_sched_par = XMALLOC(s_ponos_var_t*, dims_par);
      s_ponos_var_t** vars_sched_cst = XMALLOC(s_ponos_var_t*, dims_cst);
      for (i = 0; i < dims_iter; ++i)
	vars_sched_cst[i] = vars_sched_par[i] = vars_sched_it[i] =  NULL;
      int count_iter = 0;
      int count_par = 0;
      int count_cst = 0;
      for (tmp = scop->statement; tmp; tmp = tmp->next, stmt_count++)
	{
	  assert(tmp->domain->next == NULL);
	  int num_iter = tmp->domain->elt->NbColumns - 2 - num_par;
	  tot_sched_var += num_iter + num_par + 1;
	  for (i = 0; i < num_iter; ++i)
	    {
	      sprintf (buffer, "S%d_i%d_%d", stmt_count, i, dim);
	      s_ponos_var_t* v =
		ponos_space_var_create (buffer, PONOS_VAR_THETA_ITER,
					dim, i, count_iter, tmp);
	      ponos_space_var_set_bounds (v, theta_var_lower_bound,
					  theta_var_upper_bound);
	      vars_sched_it = bufferize (vars_sched_it, &dims_iter);
	      vars_sched_it[count_iter++] = v;
	    }
	  for (i = 0; i < num_par; ++i)
	    {
	      sprintf (buffer, "S%d_p%d_%d", stmt_count, i, dim);
	      s_ponos_var_t* v =
		ponos_space_var_create (buffer, PONOS_VAR_THETA_PARAM,
					dim, i, count_par, tmp);
	      ponos_space_var_set_bounds (v, theta_var_lower_bound,
					  theta_var_upper_bound);
	      vars_sched_par = bufferize (vars_sched_par, &dims_par);
	      vars_sched_par[count_par++] = v;
	    }
	  sprintf (buffer, "S%d_c_%d", stmt_count, dim);
	  s_ponos_var_t* v =
	    ponos_space_var_create (buffer, PONOS_VAR_THETA_CST,
				    dim, 0, count_cst, tmp);
	  ponos_space_var_set_bounds (v, theta_var_lower_bound,
				      theta_var_upper_bound);
	  vars_sched_cst = bufferize (vars_sched_cst, &dims_cst);
	  vars_sched_cst[count_cst++] = v;
	}

      // 2. Compute the decision variables.
      // For the moment, always put the full constraint with 2 bin. variable
      // per dependence (pldi'13). Other forms can be obtained by setting
      // those variable to 1 or 0.
      CandlDependence* tmpd;
      int dims_d = 128;
      s_ponos_var_t** vars_del = XMALLOC(s_ponos_var_t*, dims_d);
      for (i = 0; i < dims_d; ++i)
	vars_del[i] = NULL;
      int count_del = 0;
      int tot_del = 0;
      int dep_count = 0;
      for (tmpd = deps; tmpd; tmpd = tmpd->next, dep_count++)
	{
	  // Delta
	  {
	    sprintf (buffer, "D%d_%d", dep_count, dim);
	    s_ponos_var_t* v =
	      ponos_space_var_create (buffer, PONOS_VAR_DELTA,
				      dim, 0, count_del, tmpd);
	    ponos_space_var_set_bounds (v, 0, 1);
	    vars_del = bufferize (vars_del, &dims_d);
	    vars_del[count_del++] = v;
	    tot_del++;
	  }
	}
      int dims_r = 128;
      s_ponos_var_t** vars_rho = XMALLOC(s_ponos_var_t*, dims_r);
      for (i = 0; i < dims_r; ++i)
	vars_rho[i] = NULL;
      int count_rho = 0;
      int tot_rho = 0;
      if (dim < max_sched_dim - 1)
	{
	  dep_count = 0;
	  // Rho
	  for (tmpd = deps; tmpd; tmpd = tmpd->next, dep_count++)
	    {
	      sprintf (buffer, "R%d_%d", dep_count, dim);
	      s_ponos_var_t* v =
		ponos_space_var_create (buffer, PONOS_VAR_RHO,
					dim, 1, count_rho, tmpd);
	      ponos_space_var_set_bounds (v, 0, 1);
	      vars_rho = bufferize (vars_rho, &dims_r);
	      vars_rho[count_rho++] = v;
	      tot_rho++;
	    }
	}

      // Add un+w variables (one set per dimension).
      int dims_u = 128;
      int count_u = 0;
      s_ponos_var_t** vars_u = XMALLOC(s_ponos_var_t*, dims_u);
      for (i = 0; i < dims_u; ++i)
	vars_u[i] = NULL;
      for (i = 0; i <= num_par; ++i)
	{
	  sprintf (buffer, "U%d_%d", i, dim);
	  s_ponos_var_t* v =
	    ponos_space_var_create (buffer, PONOS_VAR_U_DIST,
				    dim, 0, i, NULL);
	  ponos_space_var_set_bounds (v, 0, options->legality_constant);
	  vars_u = bufferize (vars_u, &dims_u);
	  vars_u[count_u++] = v;
	}
      int tot_u = count_u;

      // Put together the full structure.
      // [ Deltas | Rhos | U | Iters | Params | Cst ]
      if (all_vars == NULL)
	all_vars = XMALLOC(s_ponos_var_t*,
			   (dep_count * 2 + tot_sched_var + tot_u)
			   * max_sched_dim + 1);

      int offset;
      // Add theta iter
      offset = dim * count_iter;
      for (i = 0; i < count_iter; ++i)
	{
	  all_vars[i + offset] = vars_sched_it[i];
	  all_vars[i + offset]->abs_pos = i + offset;
	  ++total_vars;
	}
      // Add theta param
      offset = (count_iter) * max_sched_dim + dim * count_par;
      for (i = 0; i < count_par; ++i)
	{
	  all_vars[i + offset] = vars_sched_par[i];
	  all_vars[i + offset]->abs_pos = i + offset;
	  ++total_vars;
	}
      // Add theta cst
      offset = (count_iter + count_par) * max_sched_dim
	+ dim * count_cst;
      for (i = 0; i < count_cst; ++i)
	{
	  all_vars[i + offset] = vars_sched_cst[i];
	  all_vars[i + offset]->abs_pos = i + offset;
	  ++total_vars;
	}
      // Add delta.
      offset = (count_iter + count_par + count_cst) * max_sched_dim
	+ dim * dep_count;
      for (i = 0; i < dep_count; ++i)
	{
	  all_vars[i + offset] = vars_del[i];
	  all_vars[i + offset]->abs_pos = i + offset;
	  ++total_vars;
	}
      // Add rho
      if (dim < max_sched_dim - 1)
	{
	  offset = (count_iter + count_par + count_cst
		    + dep_count) * max_sched_dim + dim * dep_count;
	  for (i = 0; i < dep_count; ++i)
	    {
	      all_vars[i + offset] = vars_rho[i];
	      all_vars[i + offset]->abs_pos = i + offset;
	      ++total_vars;
	    }
	}
      // Add u
      offset = (count_iter + count_par + count_cst + dep_count) * max_sched_dim
	+ (dep_count * (max_sched_dim - 1)) + dim * tot_u;
      for (i = 0; i < tot_u; ++i)
	{
	  all_vars[i + offset] = vars_u[i];
	  all_vars[i + offset]->abs_pos = i + offset;
	  ++total_vars;
	}
      // Be clean.
      XFREE(vars_sched_it);
      XFREE(vars_sched_par);
      XFREE(vars_sched_cst);
      XFREE(vars_del);
      XFREE(vars_rho);
      XFREE(vars_u);
    }
  all_vars[total_vars] = NULL;
  s_ponos_space_t* ret = ponos_space_malloc ();
  ret->vars = all_vars;
  ret->num_vars = total_vars;
  ret->num_pars = num_par;
  ret->space = fm_solution_alloc (ret->num_vars);

  return ret;
}


/**
 * Build a local system using the Farkas lemma.
 *
 * From a dependence, it produces the local space with the associated
 * variables with the same representation as when building the
 * universe system.
 * In addition, temporary dimensions are added for the Farkas multipliers.
 *
 * The legality constraint built is:
 *
 * \begin{eqnarray}
 *   \textit{(i)} && \forall \mathcal{D}_{R,S},~\forall p,
 *   ~\delta_{p}^{\mathcal{D}_{R,S}} \in \{0,1\}
 *   \nonumber \					\
 *   \textit{(ii)} &&  \forall \mathcal{D}_{R,S},
 *   ~\sum_{p = 1}^{m} \delta_p^{\mathcal{D}_{R,S}} \ge 1
 *   \label{eq:alldepssolved} \				\
 *   \textit{(iii)} &&  \forall \mathcal{D}_{R,S},
 *   ~\forall p \in \{1,\ldots,m\},
 *   ~\forall \left\langle \vec{x}_R, \vec{x}_S
 *   \right\rangle \in \mathcal{D}_{R,S}, \label{eq:convexcondforlegality} \ \
 *   && \quad \Theta_p^S(\vec x_S) - \Theta_p^R(\vec x_R) \ge - \sum_{k=1}^{p-1} (\delta_{k}^{\mathcal{D}_{R,S}}  -\rho_{k}^{\mathcal{D}_{R,S}}) . (K . \vec n + K) +  \delta_{p}^{\mathcal{D}_{R,S}} \nonumber
 * \end{eqnarray}
 *
 * In plain English: two binary decision variables, delta and rho, are
 * introduced per dimension x dependence. The legality condition
 * implemented is, for a given dependence 'dep' and a dimension 'dim',
 *
 * ThetaS(x) - ThetaR(y) >= \sum_{i=0}^{dim-1}(delta_i^{dep} -
 *                                rho_i^{dep}).(K.\vec n + K) +delta_{dim}^{dep}
 *
 */
s_ponos_space_t*
ponos_legal_build_farkas_one_dependence (s_ponos_space_t* global,
					 CandlDependence* dep,
					 int dim,
					 int dep_id,
					 int* num_farkas_multipliers,
					 int mode,
					 s_ponos_options_t* options)
{
  if (options->debug)
    {
      // print the dependence info.
      CandlDependence* td = dep->next;
      dep->next = NULL;
      candl_dependence_pprint (stdout, dep);
      dep->next = td;
    }

  int K = options->legality_constant;
  int X = options->schedule_bound;
  int theta_var_lower_bound, theta_var_upper_bound;
  if (options->schedule_coefs_are_pos)
    theta_var_lower_bound = 0;
  else
    theta_var_lower_bound = -options->schedule_bound;
  theta_var_upper_bound = options->schedule_bound;

  CandlStatement* s1 = dep->source;
  CandlStatement* s2 = dep->target;
  // Permute the statements, to have always S1 S2 and never S2 S1.
  if (s1->label > s2->label)
    {
      CandlStatement* tmp = s1;
      s1 = s2;
      s2 = tmp;
    }

  int num_par = global->num_pars;
  int tot_vars = s1->depth + num_par + 1 + 2 * (dim + 1) + (num_par + 1);
  if (s1 != s2)
    tot_vars += s2->depth + num_par + 1;
  int i;
  s_ponos_var_t** vars = XMALLOC(s_ponos_var_t*, tot_vars + 1);
  assert(vars);
  int pos = 0;
  int num_rows_system = 0;
  char buffer[512];
  // Create Deltas.
  for (i = 0; i <= dim; ++i)
    {
      sprintf (buffer, "D%d_%d", dep_id, i);
      s_ponos_var_t* v =
	ponos_space_var_create (buffer, PONOS_VAR_DELTA, dim, 0, pos, dep);
      ponos_space_var_set_bounds (v, 0, 1);
      vars[pos++] = v;
    }
  // Create Rhos.
  for (i = 0; i < dim; ++i)
    {
      sprintf (buffer, "R%d_%d", dep_id, i);
      s_ponos_var_t* v =
	ponos_space_var_create (buffer, PONOS_VAR_RHO, dim, 1, pos, dep);
      ponos_space_var_set_bounds (v, 0, 1);
      vars[pos++] = v;
    }
  // Create Us.
  for (i = 0; i <= num_par; ++i)
    {
      sprintf (buffer, "U%d_%d", i, dim);
      s_ponos_var_t* v =
	ponos_space_var_create (buffer, PONOS_VAR_U_DIST, dim, 1, pos, NULL);
      ponos_space_var_set_bounds (v, 0, options->legality_constant);
      vars[pos++] = v;
    }
  // Create S1 iters.
  for (i = 0; i < s1->depth; ++i)
    {
      sprintf (buffer, "S%d_i%d_%d", s1->label, i, dim);
      s_ponos_var_t* v =
	ponos_space_var_create (buffer, PONOS_VAR_THETA_ITER, dim, i, pos, s1);
      ponos_space_var_set_bounds (v, theta_var_lower_bound,
				  theta_var_upper_bound);
      vars[pos++] = v;
    }
  // If S1 != S2, create S2 iters.
  if (s1 != s2)
    {
      for (i = 0; i < s2->depth; ++i)
	{
	  sprintf (buffer, "S%d_i%d_%d", s2->label, i, dim);
	  s_ponos_var_t* v =
	    ponos_space_var_create (buffer, PONOS_VAR_THETA_ITER, dim,
				    i, pos, s2);
	  ponos_space_var_set_bounds (v, theta_var_lower_bound,
				      theta_var_upper_bound);
	  vars[pos++] = v;
	}
    }
  // Create S1 params.
  for (i = 0; i < num_par; ++i)
    {
      sprintf (buffer, "S%d_p%d_%d", s1->label, i, dim);
      s_ponos_var_t* v =
	ponos_space_var_create (buffer, PONOS_VAR_THETA_PARAM, dim,
				i, pos, s1);
      ponos_space_var_set_bounds (v, theta_var_lower_bound,
				  theta_var_upper_bound);
      vars[pos++] = v;
    }
  // If S1 != S2, create S2 params.
  if (s1 != s2)
    {
      for (i = 0; i < num_par; ++i)
	{
	  sprintf (buffer, "S%d_p%d_%d", s2->label, i, dim);

	  s_ponos_var_t* v =
	    ponos_space_var_create (buffer, PONOS_VAR_THETA_PARAM, dim,
				    i, pos, s2);
	  ponos_space_var_set_bounds (v, theta_var_lower_bound,
				      theta_var_upper_bound);
	  vars[pos++] = v;
	}
    }
  // Create S1 cst.
  {
    sprintf (buffer, "S%d_c_%d", s1->label, dim);
    s_ponos_var_t* v =
      ponos_space_var_create (buffer, PONOS_VAR_THETA_CST, dim,
			      0, pos, s1);
    ponos_space_var_set_bounds (v, theta_var_lower_bound,
				theta_var_upper_bound);
    vars[pos++] = v;
  }
  // If S1 != S2, create S2 cst.
  if (s1 != s2)
    {
      sprintf (buffer, "S%d_c_%d", s2->label, dim);
      s_ponos_var_t* v =
	ponos_space_var_create (buffer, PONOS_VAR_THETA_CST, dim,
				0, pos, s2);
      ponos_space_var_set_bounds (v, theta_var_lower_bound,
				  theta_var_upper_bound);
      vars[pos++] = v;
    }
  vars[pos] = NULL;

  // Create the space.
  s_ponos_space_t* local = ponos_space_malloc ();
  local->vars = vars;
  local->num_vars = pos;
  local->num_pars = num_par;
  local->space = NULL;
  num_rows_system = pos;

  // Ok, time to compute.

  // 1. Create a fm_system of the good size.
  // First, need to count the farkas multipliers.
  CandlMatrix* m = dep->domain;
  // a. count the number of equalities in the dependence polyhedron.
  int num_eq = 0;
  for (i = 0; i < m->NbRows; ++i)
    {
      if (CANDL_get_si(m->p[i][0]) == 0)
	++num_eq;
    }
  // One farkas multiplier per true inequality in the dep. polyhedron,
  // plus lambda0, plus 1 lambda for each new parameter inequality introduced.
  int num_farkas_mult = m->NbRows + num_eq + 1 + num_par;
  int num_cols = local->num_vars + num_farkas_mult + 2;

  // b. count the number of rows in the system.
  // one row per equality farkas <-> sched coef
  // 2 rows per system coef, to bound the coefs
  // 1 row per lamda, for >= cst.
  // 1 row per rho, delta >= rho.
  // 1 row per U, u >= 0.
  int num_rows = num_rows_system * 2 + m->NbColumns - 1 + num_farkas_mult +
    (dim) - (num_par + 1);

  s_fm_system_t* s = fm_system_alloc (num_rows, num_cols);

  // c. Extend the dependence domain to inequalities only.
  CandlMatrix* nm =
    candl_matrix_malloc (m->NbRows + num_eq + num_par, m->NbColumns);
  int j;
  int row = 0;
  for (i = 0; i < m->NbRows; ++i, ++row)
    {
      CANDL_set_si(nm->p[row][0], 1);
      for (j = 1; j < m->NbColumns; ++j)
	CANDL_assign(nm->p[row][j], m->p[i][j]);
      if (CANDL_get_si(m->p[i][0]) == 0)
	{
	  ++row;
	  CANDL_set_si(nm->p[row][0], 1);
	  for (j = 1; j < m->NbColumns; ++j)
	    {
	      CANDL_assign(nm->p[row][j], m->p[i][j]);
	      CANDL_oppose(nm->p[row][j],nm->p[row][j]);
	    }
	}
    }
  // d. Add info that all parameters are non-negative in the dep. polyhedron.
  for (i = 0; i < num_par; ++i)
    CANDL_set_si(nm->p[row++][nm->NbColumns - 1 - num_par + i], 1);

  // 2. Fill in the system from the transpose of the normalized dependence.
  z_type_t val; Z_INIT(val);
  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, 1);
  z_type_t mone; Z_INIT(mone); Z_ASSIGN_SI(mone, -1);
  z_type_t zX; Z_INIT(zX); Z_ASSIGN_SI(zX, X);
  z_type_t mzX; Z_INIT(mzX); Z_ASSIGN_SI(mzX, -X);
  z_type_t zK; Z_INIT(zK); Z_ASSIGN_SI(zK, K);
  z_type_t mzK; Z_INIT(mzK); Z_ASSIGN_SI(mzK, -K);
  if (options->debug)
    {
      printf ("BASE:\n");
      candl_matrix_print (stdout, m);
      printf ("NORMALIZED:\n");
      candl_matrix_print (stdout, nm);
    }
  for (i = 1; i < nm->NbColumns; ++i)
    {
      // It is an equality.
      fm_vector_set_eq(s->lines[i - 1]);
      // Copy the farkas multipliers part.
      int pos;
      for (j = 0; j < nm->NbRows; ++j)
	{
	  int intval = CANDL_get_si(nm->p[j][i]);
	  intval *= -1;
	  Z_ASSIGN_SI(val, intval);
	  pos = local->num_vars + 1 + j + 1;
	  fm_vector_assign_int_idx(s->lines[i - 1], val, pos);
	}
      // Add the schedule coefficient equality part.
      if (i - 1 < dep->source->depth)
	{
	  // Source iterator case.
	  // offset: 1 + num_delta + num_rhos + num_u
	  pos = 1 + ((dim) * 2 + 1) + (num_par + 1);
	  if (dep->source != s1 && s1 != s2)
	    {
	      // source and target are inverted in the representation.
	      pos += s1->depth;
	    }
	  pos += i - 1;
	  if (mode == PONOS_SPACE_FARKAS_COMM_BOUND)
	    fm_vector_assign_int_idx(s->lines[i - 1], one, pos);
	  else
	    fm_vector_assign_int_idx(s->lines[i - 1], mone, pos);
	}
      else if (i - 1 < (s1->depth + s2->depth))
	{
	  // target iterator case.
	  // offset: 1 + num_delta + num_rhos + num_u
	  pos = 1 + ((dim) * 2 + 1) + (num_par + 1);
	  if (dep->target == s2 && s1 != s2)
	    pos += s1->depth;
	  pos += i - 1 - dep->source->depth;
	  if (mode == PONOS_SPACE_FARKAS_COMM_BOUND)
	    fm_vector_assign_int_idx(s->lines[i - 1], mone, pos);
	  else
	    fm_vector_assign_int_idx(s->lines[i - 1], one, pos);
	}
      else if (num_par && (i - 1 < (s1->depth + s2->depth + num_par)))
	{
	  // parameters case.
	  if (s1 != s2)
	    {
	      // offset: 1 + num_delta + num_rhos + num_u
	      pos = 1 + ((dim) * 2 + 1) + (num_par + 1);
	      pos += s1->depth + s2->depth;
	      pos += i - 1 - dep->source->depth - dep->target->depth;

	      if (mode == PONOS_SPACE_FARKAS_COMM_BOUND)
		{
		  Z_ASSIGN_SI(one, -1);
		  Z_ASSIGN_SI(mone, 1);
		}

	      // tgt - src.
	      if (dep->source == s1)
		{
		  // s1 | s2
		  fm_vector_assign_int_idx(s->lines[i - 1], one, pos + num_par);
		  fm_vector_assign_int_idx(s->lines[i - 1], mone, pos);
		}
	      else
		{
		  // s2 | s1
		  fm_vector_assign_int_idx(s->lines[i - 1], mone,
					   pos + num_par);
		  fm_vector_assign_int_idx(s->lines[i - 1], one, pos);
		}
	      Z_ASSIGN_SI(one, 1);
	      Z_ASSIGN_SI(mone, -1);
	    }
	  // Add the binary decision variables.
	  // Add sum_{k=0}^{dim-1}(\delta_k - \rho_k).K.\vec{n}
	  if (mode == PONOS_SPACE_FARKAS_NORMAL)
	    for (j = 0; j < dim; ++j)
	      {
		//sum_{k=0}^{dim-1}(\delta_k).K.n
		fm_vector_assign_int_idx(s->lines[i - 1], zK, j + 1);
		//-sum_{k=0}^{dim-1}(\rho_k).K.n
		fm_vector_assign_int_idx(s->lines[i - 1], mzK,
					 j + 1 + (dim + 1));
	      }
	  if (mode == PONOS_SPACE_FARKAS_COMM_BOUND)
	    {
	      // offset: 1 + num_delta + num_rhos + u_0 (w)
	      int offset = 1 + (dim * 2) + 1 + 1;
	      offset += i - 1 - dep->source->depth - dep->target->depth;
	      //for (j = 0; j < num_par; ++j)
		//\vec u.n
		//fm_vector_assign_int_idx(s->lines[i - 1], one, j + offset);
	      fm_vector_assign_int_idx(s->lines[i - 1], one, offset);
	    }
	}
      else
	{
	  // constant case.
	  if (s1 != s2)
	    {
	      // offset: 1 + num_delta + num_rhos + num_u
	      pos = 1 + (dim * 2 + 1) + (num_par + 1);
	      pos += s1->depth + s2->depth + 2 * num_par;

	      if (mode == PONOS_SPACE_FARKAS_COMM_BOUND)
		{
		  Z_ASSIGN_SI(one, -1);
		  Z_ASSIGN_SI(mone, 1);
		}

	      // tgt - src
	      if (dep->source == s1)
		{
		  // s1 | s2
		  fm_vector_assign_int_idx(s->lines[i - 1], one, pos + 1);
		  fm_vector_assign_int_idx(s->lines[i - 1], mone, pos);
		}
	      else
		{
		  // s2 | s1
		  fm_vector_assign_int_idx(s->lines[i - 1], mone, pos + 1);
		  fm_vector_assign_int_idx(s->lines[i - 1], one, pos);
		}
	      Z_ASSIGN_SI(one, 1);
	      Z_ASSIGN_SI(mone, -1);
	    }
	  // Add -lambda_0
	  pos = local->num_vars + 1;
	  fm_vector_assign_int_idx(s->lines[i - 1], mone, pos);

	  // Add the binary decision variables.
	  // Add sum_{k=0}^{dim-1}(\delta_k - \rho_k).K - \delta_dim
	  if (mode == PONOS_SPACE_FARKAS_NORMAL)
	    {
	      for (j = 0; j < dim; ++j)
		{
		  //sum_{k=0}^{dim-1}(\delta_k).K
		  fm_vector_assign_int_idx(s->lines[i - 1], zK, j + 1);
		  //-sum_{k=0}^{dim-1}(\rho_k).K
		  fm_vector_assign_int_idx(s->lines[i - 1], mzK,
					   j + 1 + (dim + 1));
		}
	      // -\delta_dim
	      fm_vector_assign_int_idx(s->lines[i - 1], mone, j + 1);
	    }
	  if (mode == PONOS_SPACE_FARKAS_COMM_BOUND)
	    {
	      // add w
	      // offset 1: 1 + num_delta + num_rho
	      int offset = 1 + (dim * 2) + 1;
	      fm_vector_assign_int_idx(s->lines[i - 1], one, offset);
	    }
	}
    }

  // 3. Add bounds on coefficents.
  row = i - 1;
  // for all dim -1, delta >= rho
  Z_ASSIGN_SI(one, 1);
  Z_ASSIGN_SI(mone, -1);
  for (i = 0; i < dim; ++i)
    {
      fm_vector_set_ineq (s->lines[row]);
      fm_vector_assign_int_idx(s->lines[row], one, i + 1);
      fm_vector_assign_int_idx(s->lines[row], mone, i + 1 + (dim + 1));
      ++row;
    }
  // All Boolean variables are between 0 and 1.
  for (i = 0; i < (2 * dim) + 1; ++i)
    {
      // >= 0
      fm_vector_set_ineq (s->lines[row]);
      fm_vector_assign_int_idx(s->lines[row], one, i + 1);
      row++;
      // <= 1
      fm_vector_set_ineq (s->lines[row]);
      fm_vector_assign_int_idx(s->lines[row], mone, i + 1);
      fm_vector_assign_int_idx(s->lines[row], one, s->nb_cols - 1);
      row++;
    }
  // All Us are non-negative..
  for (i = (2 * dim) + 1; i < (2 * dim) + 1 + (num_par + 1); ++i)
    {
      // >= 0
      fm_vector_set_ineq (s->lines[row]);
      fm_vector_assign_int_idx(s->lines[row], one, i + 1);
      row++;
    }
  // All schedule coefs are also bounded, between -X and X.
  for (i = (2 * dim) + 1 + (num_par + 1);
       i < s->nb_cols - 2 - num_farkas_mult; ++i)
    {
      // >= -X
      fm_vector_set_ineq (s->lines[row]);
      fm_vector_assign_int_idx(s->lines[row], one, i + 1);
      if (! options->schedule_coefs_are_pos)
	fm_vector_assign_int_idx(s->lines[row], zX, s->nb_cols - 1);
      row++;
      // <= X
      fm_vector_set_ineq (s->lines[row]);
      fm_vector_assign_int_idx(s->lines[row], mone, i + 1);
      fm_vector_assign_int_idx(s->lines[row++], zX, s->nb_cols - 1);
    }
  // All farkas multipliers are  >= 0
/*   printf ("num_cols=%d, num_rows=%d\n", s->nb_cols, s->nb_lines); */
/*   printf ("i=%d\n", i); */
  for (i = s->nb_cols - 2 - num_farkas_mult; i < s->nb_cols - 2; ++i)
    {
      fm_vector_set_ineq (s->lines[row]);
      fm_vector_assign_int_idx(s->lines[row], one, i + 1);
      row++;
    }

  if (options->debug)
    {
      if (mode == PONOS_SPACE_FARKAS_COMM_BOUND)
	printf ("mode=PONOS_SPACE_FARKAS_COMM_BOUND\n");
      else
	printf ("mode=PONOS_SPACE_FARKAS_NORMAL\n");
      printf ("Final local system:\n");
      fm_system_print (stdout, s);
    }

  // Be clean.
  Z_CLEAR(val);
  Z_CLEAR(one);
  Z_CLEAR(mone);
  Z_CLEAR(zX);
  Z_CLEAR(mzX);
  Z_CLEAR(zK);
  Z_CLEAR(mzK);
  candl_matrix_free (nm);

  // Finalize the outputs.
  local->space = fm_system_to_solution (s);
  *num_farkas_multipliers = num_farkas_mult;

  return local;
}



/**
 * Project out the Farkas multipliers in a local system.
 *
 *
 */
s_ponos_space_t*
ponos_legal_eliminate_farkas_multipliers (s_ponos_space_t* space,
					  int num_farkas_multipliers,
					  s_ponos_options_t* options)
{
  s_fm_system_t* to_solve = NULL;
  s_fm_compsol_t* cs_tosolve;
  s_fm_solution_t* solution;
  to_solve = fm_solution_to_system (space->space);
  int dimension = to_solve->nb_cols - num_farkas_multipliers - 2;
  // Preliminary consistency check.
  if (! fm_piptools_gmp_check_int (to_solve))
    {
      //fm_system_print (stdout, to_solve);
      printf ("[Ponos][WARNING] Empty solution set\n");
      fm_system_free (to_solve);
      exit (1);
      return NULL;
    }

  if (options->maxscale_solver)
    {
      s_fm_system_t* ts = to_solve;
/*       solution = fm_solver */
/* 	(ts, FM_SOLVER_FAST | FM_SOLVER_REDREC_IRIGOIN | */
/* 	 FM_SOLVER_AUTO_SIMPLIFY); */
      // Just do what's needed.
      solution = fm_solver_solution_to
	(ts, FM_SOLVER_FAST | FM_SOLVER_REDREC_IRIGOIN |
	 FM_SOLVER_AUTO_SIMPLIFY, dimension);
      fm_solution_cut (solution, dimension);
    }
  else
    {
      cs_tosolve = fm_compsol_init_sys (to_solve);
      fm_system_free (to_solve);
      to_solve = fm_solution_to_system (cs_tosolve->poly);
      fm_solution_free (cs_tosolve->poly);
      if (options->noredundancy_solver)
	  cs_tosolve->poly = fm_solver
	    (to_solve, FM_SOLVER_FAST | FM_SOLVER_REDREC_IRIGOIN);
      else
	cs_tosolve->poly = fm_solver
	  (to_solve, FM_SOLVER_FAST | FM_SOLVER_AUTO_SIMPLIFY |
	   FM_SOLVER_REDREC_IRIGOIN);
      solution = fm_compsol_expand (cs_tosolve);
      fm_solution_cut (solution, dimension);
      fm_compsol_free (cs_tosolve);
    }

  fm_solution_free (space->space);
  space->space = solution;
  fm_system_free (to_solve);

  if (options->debug == 2)
    {
      debug_solution (solution);
      ponos_space_print (stdout, space);
    }

  return space;
}


/**
 * Convenience function to match a variable in a local space with its
 * equivalent on the global space, based on the unique name of
 * variables.
 *
 */
static
int
compute_global_pos (s_ponos_space_t* g,
		    s_ponos_space_t* l,
		    int idx)
{
  if (g == NULL || l == NULL || idx < 0 || idx >= l->num_vars)
    {
      printf ("idx=%d\n", idx);
      ponos_space_print_vars (stdout, g);
      ponos_space_print_vars (stdout, l);
      assert(! "ERROR: wrong idx");
      exit (42);
      return -1;
    }
  char* name_l = l->vars[idx]->name;
  int i;
  for (i = 0; i < g->num_vars && strcmp (g->vars[i]->name, name_l); ++i)
    ;
  if (i == g->num_vars)
    return -1;
  return i;
}


/**
 * Merge a local space in a global space.
 *
 */
static
void
ponos_legal_merge (s_ponos_space_t* global_space,
		   s_ponos_space_t* local_space,
		   s_fm_system_t* gs_syst)
{
  s_fm_system_t* gs = gs_syst;
  s_fm_system_t* ls = fm_solution_to_system (local_space->space);

  int i, j;
  for (i = 0; i < ls->nb_lines; ++i)
    {
      s_fm_vector_t* v = fm_vector_alloc (gs->nb_cols);

      // eq/ineq.
      if (Z_CMP_SI(ls->lines[i]->vector[0].num, ==, 1))
	fm_vector_set_ineq (v);

      // body.
      for (j = 1; j < ls->nb_cols - 1; ++j)
	{
	  int pos_gs = compute_global_pos (global_space, local_space, j - 1);
	  assert (pos_gs != -1);
	  fm_vector_assign_idx (v, &(ls->lines[i]->vector[j]), pos_gs + 1);
	}
      // cst.
      fm_vector_assign_idx (v, &(ls->lines[i]->vector[ls->nb_cols - 1]),
			    gs->nb_cols - 1);
      fm_system_add_line (gs, v);
    }
  fm_system_free (ls);
}
static
void
ponos_legal_merge_finalize (s_ponos_space_t* global_space,
			    s_fm_system_t* g_syst)
{
  fm_solution_free (global_space->space);
  global_space->space = fm_system_to_solution (g_syst);
  fm_system_free (g_syst);
/*   ponos_space_pprint_cst (stdout, global_space); */
}


/**
 * Add \sum_{i=1}^{max_dim} delta_p^dep = 1, for all deps.
 *
 */
static
void
ponos_legal_add_satisfaction (s_ponos_space_t* space,
			      CandlDependence* deps,
			      int num_deps,
			      int num_dims,
			      s_ponos_options_t* options)
{
  int i, j;

  CandlDependence* tmp;
  // \sum \delta = 1
  for (tmp = deps; tmp; tmp = tmp->next)
    {
      int all_ids[num_dims + 1];
      for (i = 0; i < num_dims; ++i)
	{
	  int* ids =
	    ponos_space_get_coefs_dim_stmt (space, (void*)tmp, i, PONOS_VAR_DELTA);
	  all_ids[i] = ids[0];
	  XFREE(ids);
	}
      all_ids[i] = -1;
      ponos_space_create_summation (space, -1, all_ids,
				    PONOS_CONSTRAINT_EQUAL,
				    PONOS_OBJECTIVE_MINIMIZE, 1);
    }
}


/**
 *
 *
 *
 */
static
void
ponos_legal_make_2dp1 (s_ponos_space_t* space,
		       int max_sched_dim,
		       s_ponos_options_t* options)
{
  int i, j;
  // For each even rows (0, 2, ...), force theta coefs. to be 0.
  for (i = 0; i < max_sched_dim; i += 2)
    {
      // Get all theta coefficients attachted to iterators and parameters.
      int* coefs = ponos_space_get_coefs_dim (space, i,
					      PONOS_VAR_THETA_ITER |
					      PONOS_VAR_THETA_PARAM);
      if (coefs)
	{
	  for (j = 0; coefs[j] != -1; ++j)
	    {
	      ponos_space_set_variable_to_value
		(space, coefs[j], 0, PONOS_CONSTRAINT_EQUAL);
	    }
	  XFREE(coefs);
	}
    }
}

/**
 * Remove obviously equal dependence polyhedra.
 *
 *
 *
 */
static
CandlDependence* ponos_legal_prune_depgraph(CandlDependence* deps)
{
  CandlDependence* tmp;
  CandlDependence* root = NULL;
  CandlDependence* cur;
  CandlDependence* tmp2;
  for (tmp = deps; tmp; tmp = tmp->next)
    {
      if (root == NULL)
	{
	  root = candl_dependence_malloc();
	  root->domain = tmp->domain;
	  root->source = tmp->source;
	  root->target = tmp->target;
	  root->type = tmp->type;
	  root->depth = tmp->depth;
	  root->ref_source = tmp->ref_source;
	  root->ref_target = tmp->ref_target;
	  root->usr = tmp->usr;
	  cur = root;
	  continue;
	}
      for (tmp2 = root; tmp2; tmp2 = tmp2->next)
	if (tmp->source == tmp2->source && tmp->target == tmp2->target &&
	    fm_piptools_pipmatrix_equal (tmp->domain, tmp2->domain))
	  break;
      if (tmp2 == NULL)
	{
	  cur->next = candl_dependence_malloc();
	  cur = cur->next;
	  cur->domain = tmp->domain;
	  cur->source = tmp->source;
	  cur->target = tmp->target;
	  cur->type = tmp->type;
	  cur->depth = tmp->depth;
	  cur->ref_source = tmp->ref_source;
	  cur->ref_target = tmp->ref_target;
	  cur->usr = tmp->usr;
	}
    }

  return root;
}


/**
 * Build all semantics-preserving constraints for a program.
 *
 * Output space is organized as follows:
 * [ iS0,1 jS0,1 iS1,1..iS0,2..pS0,1..cSn,d D1,1 D2,1..R1,1 R1,2..U_0_1..Un_d ]
 *
 * Where D are delta variables, R are rho variables, iSxx are the
 * schedule coefficents. They are organized as
 *  iS0,1 iS1,1 iS0,2, iS1,2 pS0,1 pS1,1 ... cS0,1 cS1,1...
 *
 * where i means "iterator" coefficient, S0 means statement 1, S0,1
 * means coefficients of the first chedule row, p means "parameter"
 * coefficients and c means "constant" coefficients.
 *
 */
s_ponos_space_t*
ponos_legal_build_semantics_constraints (scoplib_scop_p scop,
					 CandlDependence* deps,
					 s_ponos_options_t* options)
{
  // Prune the dependence graph.
  int num_deps_base = candl_num_dependences(deps);
  deps = ponos_legal_prune_depgraph (deps);
  if (! options->quiet)
    {
      fprintf (stdout, "[Ponos][INFO] Removed %d useless dependence polyhedra\n",
	       num_deps_base - candl_num_dependences (deps));
      if (options->debug)
	candl_dependence_pprint (stdout, deps);
    }

  // allocate the base system.
  int max_sched_dim = options->schedule_size;
  if (options->build_2d_plus_one)
    {
      // find the max. dimensionality of statements.
      int max_depth = 0;
      scoplib_statement_p stm;
      for (stm = scop->statement; stm; stm = stm->next)
	if (stm->nb_iterators > max_depth)
	  max_depth = stm->nb_iterators;
      max_sched_dim = 2 * max_depth + 1;
      if (! options->quiet)
	printf ("[Ponos][INFO] Setting schedule dimension to %d for 2d+1 encoding\n",
		max_sched_dim);
    }
  s_ponos_space_t* global_space =
    ponos_legal_build_universe (scop, deps, max_sched_dim, options);
  global_space->num_sched_dim = max_sched_dim;

  int i, j;
  int num_deps = 0;
  CandlDependence* tmp;
  // Store a matrix view of the global system.
  s_fm_system_t* g_syst = fm_solution_to_system (global_space->space);
  // Iterate over all deps and all dims.
  for (i = 0, tmp = deps; tmp; ++i, tmp = tmp->next)
    {
      // For the moment, be dumb: do not reuse the space between dimensions.
      /// TODO: compute once, replicate multi.
      for (j = 0; j < max_sched_dim; ++j)
	{
	  printf (".");
	  fflush (stdout);
	  // 1.a- build the local system for one dependence (legality).
	  int num_farkas_mult = 0;
	  s_ponos_space_t* l_spaceN = ponos_legal_build_farkas_one_dependence
	    (global_space, tmp, j, i, &num_farkas_mult,
	     PONOS_SPACE_FARKAS_NORMAL, options);
	  // 1.b- build the local system for one dependence (comm. volume).
	  s_ponos_space_t* l_spaceU = ponos_legal_build_farkas_one_dependence
	    (global_space, tmp, j, i, &num_farkas_mult,
	     PONOS_SPACE_FARKAS_COMM_BOUND, options);
	  // 2- Eliminate farkas multipliers
	  l_spaceN = ponos_legal_eliminate_farkas_multipliers
	    (l_spaceN, num_farkas_mult, options);
	  l_spaceU = ponos_legal_eliminate_farkas_multipliers
	    (l_spaceU, num_farkas_mult, options);

	  // 3- Merge into the full space
	  ponos_legal_merge (global_space, l_spaceN, g_syst);
	  ponos_legal_merge (global_space, l_spaceU, g_syst);

	  // Be clean.
	  ponos_space_free (l_spaceN);
	  ponos_space_free (l_spaceU);
	}
    }
  printf ("\n");

  // replace the global_space solution by the global system matrix.
  ponos_legal_merge_finalize (global_space, g_syst);

  // Add condition on the delta variable.
  ponos_legal_add_satisfaction (global_space, deps, i, max_sched_dim, options);

  // Force 2d+1, if asked.
  if (options->build_2d_plus_one)
    ponos_legal_make_2dp1 (global_space, max_sched_dim, options);

  // Normalize the space and detect implicit equalities.
    if (options->legal_space_normalization)
      {
	if (! options->quiet)
	  printf ("[Ponos] Perform FM normalization of the space\n");
	s_fm_compsol_t* cs = fm_compsol_init_sol (global_space->space);
	fm_solution_free (global_space->space);
	global_space->space = fm_compsol_expand (cs);
	fm_compsol_free (cs);
      }

  // Store the associated scop.
  global_space->scop = scop;

  if (options->debug)
    {
      ponos_space_print (stdout, global_space);
      printf ("[Ponos] Sanity checking the legal space with PIP\n");
      s_fm_system_t* s1 = fm_solution_to_system (global_space->space);
      int i;
      fm_system_equalities_find (s1);
      printf ("system: %d cols, %d rows\n", s1->nb_cols, s1->nb_lines);
      ponos_space_pprint_cst (stdout, global_space);
      fm_system_print (stdout, s1);
      if (fm_piptools_check_int (s1))
	printf ("==> OK\n");
      else
	{
	  printf ("==> NOT OK\n");
	  printf ("==> You must decrease K and/or the coef. range\n");
	  exit (1);
	}
      fm_system_free (s1);
    }

  return global_space;
}
