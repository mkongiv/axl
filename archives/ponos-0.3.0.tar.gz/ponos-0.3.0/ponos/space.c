/*
 * space.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/space.h>


/**
 * Pretty-print a vector (compatible with Cplex lp format).
 *
 */
void
ponos_space_pretty_print_vector (FILE* stream,
				 s_ponos_space_t* space,
				 s_fm_vector_t* vec)
{
  int i;
  char oper[] = { '\0', '\0'};
  s_fm_vector_t* v = fm_vector_alloc (vec->size);
  fm_vector_to_z (v, vec);
  for (i = 1; i < v->size; ++i)
    {
      if (Z_CMP_SI(v->vector[i].num, !=, 0) || i == v->size - 1)
	{
	  if (oper[0] == '+')
	    fprintf (stream, " ");
	  if (i < v->size - 1)
	    {
	      if (Z_CMP_SI(v->vector[i].num, ==, 1))
		fprintf (stream, "%s%s", oper, space->vars[i - 1]->name);
	      else if (Z_CMP_SI(v->vector[i].num, ==, -1))
		fprintf (stream, "-%s", space->vars[i - 1]->name);
	      else
		{
		  if (Z_GET_SI(v->vector[i].num) >= 0)
		    fprintf (stream, "%s%Ld%s", oper,
			     Z_GET_SI(v->vector[i].num),
			     space->vars[i - 1]->name);
		  else
		    fprintf (stream, "%Ld%s", Z_GET_SI(v->vector[i].num),
			     space->vars[i - 1]->name);
		}
	    }
	  else
	    fprintf (stream, "%Ld", -Z_GET_SI(v->vector[i].num));
	  if (Z_CMP_SI(v->vector[i].denum, !=, 1))
	    fprintf (stream, "/%Ld", Z_GET_SI(v->vector[i].denum));
	  oper[0] = '+';
	}
      if (i == v->size - 2)
	{
	  if (Z_CMP_SI(v->vector[0].num, ==, 0))
	    fprintf (stream, " =");
	  else
	    fprintf (stream, " >=");
	}

    }
  fprintf (stream, "\n");
  fm_vector_free (v);
}


/**
 * Return a fresh variable.
 *
 */
s_ponos_var_t*
ponos_space_var_create (char* name, int var_type, int dim,
			int local_pos, int global_pos,
			void* data)
{
  assert(name != NULL);
  assert(var_type > 0);
  assert(dim >= 0);
  assert(local_pos >= 0);
  assert(global_pos >= 0);

  s_ponos_var_t* v = XMALLOC(s_ponos_var_t, 1);
  char* cpy;
  int i;
  for (i = 0; name[i]; ++i)
    ;
  cpy = XMALLOC(char, i + 1);
  for (i = 0; name[i]; ++i)
    cpy[i] = name[i];
  cpy[i] = '\0';
  v->name = cpy;
  //v->name = xstrdup (name);
  v->type = var_type;
  v->pos = local_pos;
  v->scop_ptr = data;
  v->abs_pos = global_pos;
  v->dim = dim;
  v->is_boolean = 0;
  v->is_nonnegative = 0;
  v->lower_bound = -PONOS_SPACE_MAX_INT_VAL;
  v->upper_bound = PONOS_SPACE_MAX_INT_VAL;
  v->optimal_value = PONOS_SPACE_MAX_INT_VAL;
  v->is_maximized = 0;
  v->usr = NULL;

  return v;
}


/**
 * Set a variable type to Boolean.
 *
 */
void
ponos_space_var_set_boolean (s_ponos_var_t* var)
{
  if (var)
    {
      var->is_boolean = 1;
      var->is_nonnegative = 1;
      var->lower_bound = 0;
      var->upper_bound = 1;
      var->optimal_value = 1;
    }
}


/**
 * Set a variable type to non-negative, with upper bound.
 *
 */
void
ponos_space_var_set_bounds (s_ponos_var_t* var,
			    int lower_bound,
			    int upper_bound)
{
  if (var)
    {
      var->is_boolean = 0;
      var->is_nonnegative = 0;
      if (lower_bound >= 0)
	var->is_nonnegative = 1;
      if (lower_bound == 0 && upper_bound == 1)
	var->is_boolean = 1;
      var->lower_bound = lower_bound;
      var->upper_bound = upper_bound;
      var->optimal_value = upper_bound;
    }
}


/**
 * Free a variable.
 *
 */
void
ponos_space_var_free (s_ponos_var_t* var)
{
  if (var)
    XFREE(var->name);
  XFREE(var);
}


/**
 *
 */
s_ponos_space_t* ponos_space_malloc()
{
  s_ponos_space_t* ret = XMALLOC(s_ponos_space_t, 1);

  ret->num_vars = ret->num_pars = ret->num_sched_dim = 0;
  ret->vars = NULL;
  ret->space = NULL;
  ret->scop = NULL;
  ret->max_coef_pos_val = PONOS_SPACE_MAX_INT_VAL;
  ret->has_valid_optimal_solution = 0;
  ret->last_solver_time = 0;

  return ret;
}


/**
 *
 */
void ponos_space_free(s_ponos_space_t* s)
{
  if (s->vars)
    {
      int i;
      for (i = 0; s->vars[i]; ++i)
	ponos_space_var_free (s->vars[i]);
      XFREE(s->vars);
    }
  if (s->space)
    fm_solution_free (s->space);
  XFREE(s);
}


/**
 *
 */
void
ponos_space_set_size(s_ponos_space_t* s, int dim)
{
  s->vars = XREALLOC(s_ponos_var_t*, s->vars, dim);
  s->num_vars = dim;
}


/**
 *
 */
void
ponos_space_print_vars (FILE* stream, s_ponos_space_t* space)
{
  if (stream == NULL)
    {
      fprintf (stderr, "[NULL stream]\n");
      return;
    }
  if (space == NULL)
    {
      fprintf (stream, "[NULL]\n");
      return;
    }
  int i;
  fprintf (stream, "Space: %d var(s), %d parameter(s)\n", space->num_vars,
	   space->num_pars);
  for (i = 0; i < space->num_vars; ++i)
    fprintf (stream, "[%d=%s] ", i, space->vars[i]->name);
  fprintf (stream, "\n");
}


/**
 *
 */
void
ponos_space_print (FILE* stream, s_ponos_space_t* space)
{
  ponos_space_print_vars (stream, space);
  if (stream && space)
    {
      fprintf (stream, "Solution space (FM balls):\n");
      fm_solution_print (stream, space->space);
      fprintf (stream, "\n\nScop:\n");
      scoplib_scop_print (stream, space->scop);
    }
}


/**
 * Print the constraint system in readable form.
 */
void
ponos_space_pprint_cst (FILE* stream, s_ponos_space_t* space)
{
  ponos_space_print_vars (stream, space);
  if (stream && space)
    {
      s_fm_system_t* s = fm_solution_to_system (space->space);
      int i;
      for (i = 0; i < s->nb_lines; ++i)
	ponos_space_pretty_print_vector (stream, space, s->lines[i]);
      fm_system_free (s);
    }
}


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type.
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients call with coef_type=PONOS_VAR_THETA.
 *
 */
int*
ponos_space_get_coefs (s_ponos_space_t* space,
		       int coef_type)
{
  if (space == NULL || space->vars == NULL)
    return NULL;
  int coefs[space->num_vars + 1];
  int pos = 0;
  int i;

  for (i = 0; i < space->num_vars; ++i)
    {
      if ((space->vars[i]->type & coef_type) != 0)
	coefs[pos++] = i;
    }

  int* ret = XMALLOC(int, pos + 1);
  for (i = 0; i < pos; ++i)
    ret[i] = coefs[i];
  ret[i] = -1;

  return ret;
}


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type and dimension.
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients of the first dimension, call with dim=0,
 * coef_type=PONOS_VAR_THETA.
 *
 */
int*
ponos_space_get_coefs_dim (s_ponos_space_t* space,
			   int dim,
			   int coef_type)
{
  if (space == NULL || space->vars == NULL)
    return NULL;
  int coefs[space->num_vars + 1];
  int pos = 0;
  int i;

  for (i = 0; i < space->num_vars; ++i)
    {
      if (space->vars[i]->dim == dim &&
	  ((space->vars[i]->type & coef_type) != 0))
	coefs[pos++] = i;
    }

  int* ret = XMALLOC(int, pos + 1);
  for (i = 0; i < pos; ++i)
    ret[i] = coefs[i];
  ret[i] = -1;

  return ret;
}


/**
 * Returns a -1-terminated array of variable positions in the space,
 * that match a variable type and dimension for a given statement.
 *
 * For instance, to get all column ids (positions) of theta
 * coefficients of the first dimension, call with dim=0,
 * coef_type=PONOS_VAR_THETA.
 *
 */
int*
ponos_space_get_coefs_dim_stmt (s_ponos_space_t* space,
				scoplib_statement_p stm,
				int dim,
				int coef_type)
{
  if (space == NULL || space->vars == NULL)
    return NULL;
  int coefs[space->num_vars + 1];
  int pos = 0;
  int i;

  for (i = 0; i < space->num_vars; ++i)
    {
      if (space->vars[i]->dim == dim &&
	  ((space->vars[i]->type & coef_type) != 0) &&
	  space->vars[i]->scop_ptr == stm)
	coefs[pos++] = i;
    }

  int* ret = XMALLOC(int, pos + 1);
  for (i = 0; i < pos; ++i)
    ret[i] = coefs[i];
  ret[i] = -1;

  return ret;
}


/**
 * Set a particular variable at position 'pos' in the space->vars[pos]
 * to 'val'.
 *
 * mode is one of:
 * PONOS_CONSTRAINT_EQUAL
 * PONOS_CONSTRAINT_GREATEREQUAL
 * PONOS_CONSTRAINT_GREATER
 * PONOS_CONSTRAINT_LOWEREQUAL
 * PONOS_CONSTRAINT_LOWER
 */
void
ponos_space_set_variable_to_value (s_ponos_space_t* space,
				   int pos,
				   int val,
				   int mode)
{
  s_fm_vector_t* v = fm_vector_alloc (pos + 3);
  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, 1);
  z_type_t mone; Z_INIT(mone); Z_ASSIGN_SI(mone, -1);
  z_type_t zv; Z_INIT(zv);

  if (mode == PONOS_CONSTRAINT_EQUAL)
    {
      fm_vector_set_eq (v);
      Z_ASSIGN_SI(one, 1);
      Z_ASSIGN_SI(zv, -val);
      fm_vector_assign_int_idx (v, one, pos + 1);
      fm_vector_assign_int_idx (v, zv, pos + 2);
    }
  else
    {
      fm_vector_set_ineq (v);
      if (mode == PONOS_CONSTRAINT_GREATEREQUAL ||
	  mode == PONOS_CONSTRAINT_GREATER)
	{
	  Z_ASSIGN_SI(one, 1);
	  if (mode == PONOS_CONSTRAINT_GREATER)
	    Z_ASSIGN_SI(zv, -val - 1);
	  else
	    Z_ASSIGN_SI(zv, -val);
	  fm_vector_assign_int_idx (v, one, pos + 1);
	  fm_vector_assign_int_idx (v, zv, pos + 2);
	}
      else if (mode == PONOS_CONSTRAINT_LOWEREQUAL ||
	       mode == PONOS_CONSTRAINT_LOWER)
	{
	  Z_ASSIGN_SI(one, 1);
	  if (mode == PONOS_CONSTRAINT_LOWER)
	    Z_ASSIGN_SI(zv, val - 1);
	  else
	    Z_ASSIGN_SI(zv, val);
	  fm_vector_assign_int_idx (v, mone, pos + 1);
	  fm_vector_assign_int_idx (v, zv, pos + 2);
	}
    }

  fm_solution_add_unique_line_at (space->space, v, pos + 1);
  Z_CLEAR(one); Z_CLEAR(zv); Z_CLEAR(mone);
}


/**
 * Count the number of variables of a certain type at a given dimension.
 *
 */
int
ponos_space_count_var_type_dim (s_ponos_space_t* space,
				int dim,
				int type)
{
  if (space == NULL || space->vars == NULL)
    return -1;

  int ret = 0;
  int i;
  for (i = 0; i < space->num_vars; ++i)
    if (space->vars[i]->dim == dim && ((space->vars[i]->type & type) != 0))
      ++ret;

  return ret;
}


/**
 * Count the number of variables of a certain type.
 *
 */
int
ponos_space_count_var_type (s_ponos_space_t* space,
			    int type)
{
  if (space == NULL || space->vars == NULL)
    return -1;

  int ret = 0;
  int i;
  for (i = 0; i < space->num_sched_dim; ++i)
    ret += ponos_space_count_var_type_dim (space, i, type);

  return ret;
}


/**
 * Insert a new variable in the space at position pos.
 *
 */
void
ponos_space_insert_variable_at_pos (s_ponos_space_t* space,
				    s_ponos_var_t* var,
				    int pos)
{
  if (! space || !space->vars || !var)
    return;

  assert(pos >= 0);
  int i, j;
  space->num_vars++;
  space->vars = XREALLOC(s_ponos_var_t*, space->vars, space->num_vars + 1);
  space->vars[space->num_vars] = NULL;
  for (i = space->num_vars; i > pos; --i)
    {
      space->vars[i] = space->vars[i - 1];
      if (space->vars[i])
	(space->vars[i]->abs_pos)++;
    }
  space->vars[pos] = var;
  fm_solution_add_columns (space->space, pos, 1);
  var->abs_pos = pos;
}


/**
 * Insert a new variable in the space in first position.
 *
 */
void
ponos_space_insert_variable_first (s_ponos_space_t* space,
				   s_ponos_var_t* var)
{
  if (! space || !space->vars)
    return;
  ponos_space_insert_variable_at_pos (space, var, 0);
}


/**
 * Insert a new variable in the space in last position.
 *
 */
void
ponos_space_insert_variable_last (s_ponos_space_t* space,
				  s_ponos_var_t* var)
{
  if (! space || !space->vars || !var)
    return;
  int pos = space->num_vars;
  int i, j;
  space->num_vars++;
  space->vars = XREALLOC(s_ponos_var_t*, space->vars, space->num_vars + 1);
  space->vars[pos] = var;
  var->abs_pos = pos;
  space->vars[pos + 1] = NULL;
  fm_solution_extend(space->space, space->num_vars);
  /* ponos_space_insert_variable_at_pos (space, var, space->num_vars); */
}


/**
 * Creates a summation constraint
 * var = \sum_i other_vars[i]
 *
 */
void
ponos_space_create_summation (s_ponos_space_t* space,
			      int var, int* other_vars,
			      int mode,
			      int sum_type,
			      int val)
{
  if (! space || !space->vars || !other_vars)
    return;

  // 1. Count the max. id.
  int max_id = var;
  int i;
  for (i = 0; other_vars[i] != -1; ++i)
    if (other_vars[i] > max_id)
      max_id = other_vars[i];
  if (max_id == -1)
    return;

  // 2. Create the constraint.
  s_fm_vector_t* v = fm_vector_alloc (max_id + 3);
  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, 1);
  z_type_t mone; Z_INIT(mone); Z_ASSIGN_SI(mone, -1);
  z_type_t cst; Z_INIT(cst); Z_ASSIGN_SI(cst, 0);
  z_type_t zval; Z_INIT(zval); Z_ASSIGN_SI(zval, val);

  // 3. Fill it. Assume var != max_id.
  if (var != -1)
    {
      if (mode == PONOS_CONSTRAINT_EQUAL)
	fm_vector_set_eq (v);
      else
	{
	  fm_vector_set_ineq (v);
	  if (mode == PONOS_CONSTRAINT_GREATEREQUAL ||
	      mode == PONOS_CONSTRAINT_GREATER)
	    {
	      Z_OPP(one, one);
	      Z_OPP(mone, mone);
	    }
	  if (mode == PONOS_CONSTRAINT_GREATER ||
	      mode == PONOS_CONSTRAINT_LOWER)
	    Z_ASSIGN_SI(cst, -1);
	  else
	    Z_ASSIGN_SI(cst, 0);
	}
      if (mode == PONOS_CONSTRAINT_EQUAL)
	{
	  if (sum_type == PONOS_OBJECTIVE_MINIMIZE)
	    fm_vector_assign_int_idx (v, mone, var + 1);
	  else if (sum_type == PONOS_OBJECTIVE_MAXIMIZE)
	    fm_vector_assign_int_idx (v, one, var + 1);
	  else if (sum_type == PONOS_OBJECTIVE_MAXIMIZE_POS)
	    fm_vector_assign_int_idx (v, one, var + 1);
	}
      else
	fm_vector_assign_int_idx (v, mone, var + 1);
      for (i = 0; other_vars[i] != -1; ++i)
	fm_vector_assign_int_idx (v, one, other_vars[i] + 1);

      if (sum_type == PONOS_OBJECTIVE_MAXIMIZE_POS)
	{
	  z_type_t v; Z_INIT(v); Z_ASSIGN_SI(v, space->max_coef_pos_val);
	  Z_SUB(cst, cst, v);
	  Z_CLEAR(v);
	}
      fm_vector_assign_int_idx (v, cst, max_id + 2);
    }
  else
    {
      if (mode == PONOS_CONSTRAINT_EQUAL)
	fm_vector_set_eq (v);
      else
	{
	  fm_vector_set_ineq (v);
	  if (mode == PONOS_CONSTRAINT_LOWEREQUAL ||
	      mode == PONOS_CONSTRAINT_LOWER)
	    {
	      Z_OPP(one, one);
	      Z_OPP(mone, mone);
	    }
	  if (mode == PONOS_CONSTRAINT_GREATER ||
	      mode == PONOS_CONSTRAINT_LOWER)
	    Z_ASSIGN_SI(cst, -1);
	  else
	    Z_ASSIGN_SI(cst, 0);
	}

      for (i = 0; other_vars[i] != -1; ++i)
	fm_vector_assign_int_idx (v, one, other_vars[i] + 1);
      if (mode == PONOS_CONSTRAINT_LOWEREQUAL ||
	  mode == PONOS_CONSTRAINT_LOWER)
	Z_ADD(cst, cst, zval);
      else
	Z_SUB(cst, cst, zval);
      fm_vector_assign_int_idx (v, cst, max_id + 2);
    }

  // 4. Insert.
  fm_solution_add_unique_line_at (space->space, v, max_id + 1);

  // Be clean.
  Z_CLEAR(one);
  Z_CLEAR(mone);
  Z_CLEAR(cst);
  Z_CLEAR(zval);
}


/**
 * Creates a summation constraint
 * var.var_weight op \sum_i other_vars[i].other_vars_weight[i]
 * where op is >=, <=, =
 */
void
ponos_space_create_weighted_summation (s_ponos_space_t* space,
				       int var, int var_weight,
				       int* other_vars,
				       int* other_vars_weight,
				       int mode,
				       int sum_type,
				       int val)
{
  if (! space || !space->vars || !other_vars)
    return;

  // 1. Count the max. id.
  int max_id = var;
  int i;
  for (i = 0; other_vars[i] != -1; ++i)
    if (other_vars[i] > max_id)
      max_id = other_vars[i];
  if (max_id == -1)
    return;

  // 2. Create the constraint.
  s_fm_vector_t* v = fm_vector_alloc (max_id + 3);
  z_type_t one; Z_INIT(one); Z_ASSIGN_SI(one, 1);
  z_type_t mone; Z_INIT(mone); Z_ASSIGN_SI(mone, -1);
  z_type_t cst; Z_INIT(cst); Z_ASSIGN_SI(cst, 0);
  z_type_t zval; Z_INIT(zval); Z_ASSIGN_SI(zval, val);
  z_type_t tmp; Z_INIT(tmp); Z_ASSIGN_SI(tmp, var_weight);

  // 3. Fill it. Assume var != max_id.
  if (var != -1)
    {
      if (mode == PONOS_CONSTRAINT_EQUAL)
	fm_vector_set_eq (v);
      else
	{
	  fm_vector_set_ineq (v);
	  if (mode == PONOS_CONSTRAINT_GREATEREQUAL ||
	      mode == PONOS_CONSTRAINT_GREATER)
	    {
	      Z_OPP(one, one);
	      Z_OPP(mone, mone);
	    }
	  if (mode == PONOS_CONSTRAINT_GREATER ||
	      mode == PONOS_CONSTRAINT_LOWER)
	    Z_ASSIGN_SI(cst, -1);
	  else
	    Z_ASSIGN_SI(cst, 0);
	}
      if (mode == PONOS_CONSTRAINT_EQUAL)
	{
	  Z_ASSIGN_SI(tmp, var_weight);
	  if (sum_type == PONOS_OBJECTIVE_MINIMIZE)
	    Z_MUL(tmp, tmp, mone);
	  else if (sum_type == PONOS_OBJECTIVE_MAXIMIZE)
	    Z_MUL(tmp, tmp, one);
	  else if (sum_type == PONOS_OBJECTIVE_MAXIMIZE_POS)
	    Z_MUL(tmp, tmp, one);
	  fm_vector_assign_int_idx (v, tmp, var + 1);
	}
      else
	{
	  Z_MUL(tmp, tmp, mone);
	  fm_vector_assign_int_idx (v, tmp, var + 1);
	}
      for (i = 0; other_vars[i] != -1; ++i)
	{
	  Z_ASSIGN_SI(tmp, other_vars_weight[i]);
	  Z_MUL(tmp, tmp, one);
	  fm_vector_assign_int_idx (v, tmp, other_vars[i] + 1);
	}
      if (sum_type == PONOS_OBJECTIVE_MAXIMIZE_POS)
	{
	  z_type_t v; Z_INIT(v); Z_ASSIGN_SI(v, space->max_coef_pos_val);
	  Z_SUB(cst, cst, v);
	  Z_CLEAR(v);
	}
      fm_vector_assign_int_idx (v, cst, max_id + 2);
    }
  else
    {
      if (mode == PONOS_CONSTRAINT_EQUAL)
	fm_vector_set_eq (v);
      else
	{
	  fm_vector_set_ineq (v);
	  if (mode == PONOS_CONSTRAINT_LOWEREQUAL ||
	      mode == PONOS_CONSTRAINT_LOWER)
	    {
	      Z_OPP(one, one);
	      Z_OPP(mone, mone);
	    }
	  if (mode == PONOS_CONSTRAINT_GREATER ||
	      mode == PONOS_CONSTRAINT_LOWER)
	    Z_ASSIGN_SI(cst, -1);
	  else
	    Z_ASSIGN_SI(cst, 0);
	}

      for (i = 0; other_vars[i] != -1; ++i)
	{
	  Z_ASSIGN_SI(tmp, other_vars_weight[i]);
	  Z_MUL(tmp, tmp, one);
	  fm_vector_assign_int_idx (v, tmp, other_vars[i] + 1);
	}
      if (mode == PONOS_CONSTRAINT_LOWEREQUAL ||
	  mode == PONOS_CONSTRAINT_LOWER)
	Z_ADD(cst, cst, zval);
      else
	Z_SUB(cst, cst, zval);
      fm_vector_assign_int_idx (v, cst, max_id + 2);
    }

  // 4. Insert.
  fm_vector_normalize_idx (v, v, max_id + 1);
  fm_solution_add_unique_line_at (space->space, v, max_id + 1);

  // Be clean.
  Z_CLEAR(one);
  Z_CLEAR(mone);
  Z_CLEAR(cst);
  Z_CLEAR(zval);
  Z_CLEAR(tmp);
}
