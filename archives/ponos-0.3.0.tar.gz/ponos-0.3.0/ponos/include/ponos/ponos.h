/*
 * ponos.h: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#ifndef PONOS_PONOS_H
# define PONOS_PONOS_H


# ifndef LINEAR_VALUE_IS_LONGLONG
#  define LINEAR_VALUE_IS_LONGLONG
# endif
# ifndef CANDL_SUPPORTS_SCOPLIB
#  define CANDL_SUPPORTS_SCOPLIB
# endif
# include <candl/program.h>
# include <candl/dependence.h>
# include <candl/options.h>
# ifndef SCOPLIB_INT_T_IS_LONGLONG
#  define SCOPLIB_INT_T_IS_LONGLONG
# endif
# include <scoplib/scop.h>
# include <ponos/space.h>
# include <ponos/options.h>
# include <ponos/objectives.h>


BEGIN_C_DECLS

/**
 * Special version when dependences are explicitly provided.
 *
 */
extern
int
ponos_scheduler_from_deplist (scoplib_scop_p scop,
			      CandlProgram* cprogram,
			      CandlDependence* deps,
			      s_ponos_options_t* options);

/**
 * Standard version when dependences are computed from the scop.
 *
 */
extern
int
ponos_scheduler (scoplib_scop_p scop, s_ponos_options_t* opts);



END_C_DECLS


#endif // PONOS_PONOS_H
