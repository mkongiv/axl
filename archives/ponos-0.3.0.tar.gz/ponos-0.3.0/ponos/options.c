/*
 * options.c: This file is part of the PONOS project.
 *
 * PONOS: POlyhedral aNd Optimal Schedulers
 *
 * Copyright (C) 2012 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cs.ucla.edu>
 *
 */
#if HAVE_CONFIG_H
# include <ponos/config.h>
#endif

#include <ponos/common.h>
#include <ponos/options.h>



/**
 *
 */
s_ponos_options_t* ponos_options_malloc()
{
  s_ponos_options_t* ret = XMALLOC(s_ponos_options_t, 1);

  ret->debug = 0;
  ret->build_2d_plus_one = 0;
  ret->maxscale_solver = 0;
  ret->noredundancy_solver = 0;
  ret->legality_constant = 3;
  ret->schedule_bound = 10;
  ret->schedule_size = 1;
  ret->solver = 1;
  ret->solver_precond = 0;
  ret->quiet = 0;
  ret->schedule_coefs_are_pos = 0;
  ret->objective = 0;
  ret->pipsolve_lp = 0;
  ret->pipsolve_gmp = 0;
  ret->candl_deps_isl_simplify = 0;
  ret->candl_deps_prune_transcover = 0;
  int i;
  for (i = 0; i < PONOS_MAX_CST_OBJ_NUM; ++i)
    ret->objective_list[i] = -1;
  ret->solver_cplex = 0;
  ret->output_file_template = NULL;
  ret->legal_space_normalization = 0;

  return ret;
}


/**
 *
 */
void ponos_options_free(s_ponos_options_t* opts)
{
  if (opts)
    XFREE(opts);

}
