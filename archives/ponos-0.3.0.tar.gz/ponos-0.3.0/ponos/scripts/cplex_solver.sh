#!/bin/sh
## cplex_solver.sh for  in /Users/pouchet
##
## Made by Louis-Noel Pouchet
## Contact: <pouchet@colostate.edu>
##
## Started on  Sat Jun 10 13:21:33 2017 Louis-Noel Pouchet
## Last update Thu Jun 29 23:59:57 2017 Louis-Noel Pouchet
##


## Global variable: path to 'cplex' binary.
## Adjust as needed for your system.
CPLEX_BIN="cplex";

## Run Cplex. Assumes first argument is a space-separated list of all
## variables of interest in the lp, and second argument the name of
## the lp system file to solve.
if [ $# -ne 2 ]; then
    echo "Usage: $0 <.lp problem file> <filename-template>";
    exit 1;
fi;

## 1. Generate the Cplex script.
echo "read $1
change problem milp
set mip tolerance mipgap 0.0000000000000001
mipopt
write $2.xml sol
" > "$2.script"


## 2. Execute Cplex.
rm -f "$2.xml";
## Make sure cplex binary is executable.
command -v $CPLEX_BIN >/dev/null 2>&1;
if [ $? -ne 0 ]; then
    echo "[CPLEX][ERROR] 'cplex' binary not accessible from PATH";
    exit 1;
fi;
$CPLEX_BIN -f "$2.script" > _cplex.output;
retval="$?";
if [ "$retval" -ne 0 ]; then
    rm -f _cplex.output;
    echo "[CPLEX][ERROR] Cplex exited with code $retval";
    exit $retval;
fi;

## 3. Extract the solution.
if [ -f "$2.xml" ]; then
echo "has sol";
    grep "variable name" "$2.xml" | sed -e 's/.*value="\(.*\)".*/\1/g' > _myoutput.tmp
    cat _myoutput.tmp;
else
    ## No solution, exit 1.
    exit 1;
fi;

## 4. Be clean.
rm -f _myoutput.tmp;
