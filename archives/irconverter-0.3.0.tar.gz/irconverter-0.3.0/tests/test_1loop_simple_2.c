#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <past/symbols.h>
#include <past/past.h>
#include <past/past_api.h>
#include <past/pprint.h>
#include <irconverter/p2s.h>
#include <scoplib/scop.h>
#include "tester_generic.h"


// symbols to be used:
static s_symbol_t* i;
static s_symbol_t* j;
static s_symbol_t* k;
static s_symbol_t* A;
static s_symbol_t* B;
static s_symbol_t* C;
static s_symbol_t* N;
static s_symbol_t* M;
static s_symbol_t* typeint;

// Constants to be used.
static s_past_node_t* mone;
static s_past_node_t* zero;
static s_past_node_t* one;


s_past_node_t* test1 (s_symbol_table_t* symt)
{

  // build a simple vector-add code:
  /* for (i = 0; i < N; ++i) { */
  /*   A[i] += B[i]; */
  /*   C += i / M; */
  /* } */

  // Build B[i]
  s_past_node_t* arrefB =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (B),
			     past_node_varref_create (i));
  // Build A[i]
  s_past_node_t* arrefA =
    past_node_binary_create (past_arrayref,
			     past_node_varref_create (A),
			     past_node_varref_create (i));

  // Build A[i] += B[i];
  s_past_node_t* stmt =
    past_node_statement_create
    (past_node_binary_create (past_addassign, arrefA, arrefB));

  // Build c += i / M;
  s_past_node_t* stmt2 = 
    past_node_statement_create
    (past_node_binary_create 
     (past_addassign,
      past_node_varref_create (C),
      past_node_binary_create
      (past_div,
       past_node_varref_create (i),
       past_node_varref_create (M))));

  // Build ++i
  s_past_node_t* inc =
    past_node_unary_create (past_inc_before,
			    past_node_varref_create (i));

  // Build i < N
  s_past_node_t* test =
    past_node_binary_create (past_lt,
			     past_node_varref_create (i),
			     past_node_varref_create (N));

  // Build i = 0
  s_past_node_t* init =
    past_node_binary_create (past_assign,
			     past_node_varref_create (i),
			     past_clone (zero));

  // Build program, encapsulate things in basic blocks.
  s_past_node_t* bb = past_node_block_create (stmt);
  past_append_last (stmt, stmt2);
  s_past_node_t* forloop =
    past_node_for_create (init, test, i,
			  inc, bb);
  s_past_node_t* prog =
    past_node_block_create (forloop);

  // Encapsulate in a fundef.
  s_past_node_t* fundef = 
    past_node_fundecl_create 
    (past_node_type_create (past_node_varref_create (typeint)),
     past_node_varref_create (symbol_add_from_char (symt, "foo")),
     NULL,
     prog);

  s_past_node_t* root = past_node_root_create (symt, fundef);

  return root;
}


int main() {
  s_symbol_table_t* symtable = symbol_table_malloc ();
  i = symbol_add_from_char (symtable, "i");
  j = symbol_add_from_char (symtable, "j");
  k = symbol_add_from_char (symtable, "k");
  A = symbol_add_from_char (symtable, "A");
  B = symbol_add_from_char (symtable, "B");
  C = symbol_add_from_char (symtable, "C");
  N = symbol_add_from_char (symtable, "N");
  M = symbol_add_from_char (symtable, "M");
  typeint = symbol_add_from_char (symtable, "int");
  mone = past_node_value_create_from_int (-1);
  zero = past_node_value_create_from_int (0);
  one = past_node_value_create_from_int (1);

  
  tester (test1 (symtable), 1);


  // Be clean.
  symbol_table_free (symtable);
}
