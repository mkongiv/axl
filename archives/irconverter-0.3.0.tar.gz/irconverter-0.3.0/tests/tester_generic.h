#include <irconverter/pastScopRecognizer.h>
#include <irconverter/pastScopConverter.h>

void tester (s_past_node_t* root, int nb_scop_expected)
{
  int i;
  printf ("[TEST] Starting test\n");
  printf ("[INFO] Input tree:\n");
  past_pprint (stdout, root);
  printf ("[TEST] Scop Recognizer:\n");
  s_past_node_t** trees = pastScopRecognizer (root, 1);
  for (i = 0; trees && trees[i]; ++i)
    {
      printf ("[INFO] Scop tree:\n");
      past_pprint (stdout, trees[i]);
    }
  if (i != nb_scop_expected)
    printf ("[FAIL] Expected %d scops, extracted %d scops\n",
	    nb_scop_expected, i);
  for (i = 0; trees && trees[i]; ++i)
    {
      printf ("[TEST] Scop Converter:\n");
      scoplib_scop_p scop = pastScopConverter (trees[i]);
      printf ("=> For sub-tree:\n");
      past_pprint (stdout, scop->usr);
      printf ("=> Got scop #%d:\n", i);
      scoplib_scop_print (stdout, scop);
      scoplib_scop_free (scop);
    }
  printf ("[INFO] Total number of scops extracted: %d/%d\n",
	  i, nb_scop_expected);
  past_deep_free (root);
  XFREE(trees);
  printf ("[TEST] All done\n");
}
