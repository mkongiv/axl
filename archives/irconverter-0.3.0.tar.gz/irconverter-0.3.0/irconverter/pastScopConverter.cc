/*
 * pastScopConverter.cc: This file is part of the IR-Converter project.
 *
 * IR-Converter: a library to convert PAST to ScopLib
 *
 * Copyright (C) 2011-2014 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <irconverter/config.h>
#endif

#include <irconverter/common.h>
#include <irconverter/stack.h>
#include <irconverter/pastScopConverter.h>
#include <past/past_api.h>
#include <past/pprint.h>

#include <assert.h>
#include <string.h>
#include <strings.h>

#include <vector>
#include <set>
#include <string>
#include <stack>
#include <queue>
#include <map>
#include <algorithm>

static int verbose = 1;
// Ugly hack to recognize an error.
static int errcode = 0;
// Ugly macro to maximize leak while emulating an exception for the poor...
#define CONVERTER_FAIL(x) { if (errcode != 0) return x; }

static
void converter_fail (s_past_node_t* node, std::string msg)
{
  if (verbose)
    {
      printf ("[AffineConverter] Node:\n");
      past_pprint (stdout, node);
      printf ("\nin: \n");
      past_pprint (stdout, node->parent);
      printf ("\nFAIL => %s\n", msg.c_str());
    }
  errcode = 1;
}

static
void merge_to_set_noiter (std::set<s_symbol_t*>& s, s_symbol_t** m,
			  s_symbol_t** iters)
{
  int i, j;
  for (i = 0; m && m[i]; ++i)
    {
      for (j = 0; iters && iters[j]; ++j)
	{
	  // printf ("COMPARE %s (%p) with %s (%p)\n", m[i]->name_str, m[i]->data, iters[j]->name_str, iters[j]->data);
	  if (symbol_equal (m[i], iters[j]))
	    break;
	}
      if (! iters || ! iters[j])
	{
	  // printf ("INSERT %s (%p)\n", m[i]->name_str, m[i]->data);
	  s.insert (m[i]);
	}
    }
}

static
void oppose_matrix (scoplib_matrix_p m)
{
  int i, j;
  for (i = 0; i < m->NbRows; ++i)
    for (j = 1; j < m->NbColumns; ++j)
      SCOPVAL_set_si(m->p[i][j], - SCOPVAL_get_si(m->p[i][j]));
}

static
void set_ineq_matrix (scoplib_matrix_p m)
{
  int i;
  for (i = 0; i < m->NbRows; ++i)
    SCOPVAL_set_si(m->p[i][0], 1);
}

static
void set_eq_matrix (scoplib_matrix_p m)
{
  int i;
  for (i = 0; i < m->NbRows; ++i)
    SCOPVAL_set_si(m->p[i][0], 0);
}

static
void add_constant_matrix (scoplib_matrix_p m, int val)
{
  int i;
  for (i = 0; i < m->NbRows; ++i)
    SCOPVAL_set_si(m->p[i][m->NbColumns - 1],
		   SCOPVAL_get_si(m->p[i][m->NbColumns - 1]) + val);
}

/**
 * Internal Helper. Computes the coefficient associated to a symbol in
 * an affine expression.
 *
 * For e = \sum_i a_i * b_i + a_0, with b_i (symb) as argument,
 * returns a_0 + a_i. Pass NULL as b_i to get a_0 first.
 *
 * Special case: compute the coefficient of a node, and not a
 * symbol. Useful for things like "(2+3) * max(i, j)", to get the
 * coeff (multiplier) to apply to each member of a
 * min/max/ceild/floord expression.
 */
static
scoplib_int_t
computeCoefficient(s_past_node_t* e, char* symb, s_past_node_t* node)
{
  scoplib_int_t res;
  SCOPVAL_init(res);

  if (e == node)
    {
      SCOPVAL_set_si(res, 1);
    }
  else if (past_node_is_a (e, past_value))
    {
      PAST_DECLARE_TYPED(value, pv, e);
      SCOPVAL_set_si(res, pv->value.intval);
    }
  else if (past_node_is_a (e, past_varref))
    {
      PAST_DECLARE_TYPED(varref, pv, e);
      if (symb && ! strcmp ((char*)pv->symbol->name_str, symb))
	SCOPVAL_set_si(res, 1);
      else
	SCOPVAL_set_si(res, 0);
    }
  else if (past_node_is_a (e, past_funcall))
    {
      PAST_DECLARE_TYPED(funcall, pf, e);
      if (! pf->is_pure_function)
	converter_fail (e, "only pure functions allowed in affine expressions");
      if (! past_node_is_a (pf->name, past_varref))
	converter_fail (e, "only varref supported for function name in a call");
      if (pf->args_list != NULL)
	converter_fail (e, "currently no argument to funcall supported in affine expressions");
      CONVERTER_FAIL(0);

      PAST_DECLARE_TYPED(varref, pv, pf->name);
      if (symb && ! strcmp ((char*)pv->symbol->name_str, symb))
	SCOPVAL_set_si(res, 1);
      else
	SCOPVAL_set_si(res, 0);
    }
  else if (past_node_is_a (e, past_binary))
    {
      PAST_DECLARE_TYPED(binary, pb, e);
      scoplib_int_t lhs = computeCoefficient(pb->lhs, symb, NULL);
      CONVERTER_FAIL(0);
      scoplib_int_t rhs = computeCoefficient(pb->rhs, symb, NULL);
      CONVERTER_FAIL(0);
      if (past_node_is_a (e, past_add))
	SCOPVAL_addto(res, lhs, rhs);
      else if (past_node_is_a (e, past_sub))
	SCOPVAL_subtract(res, lhs, rhs);
      else if (past_node_is_a (e, past_mul))
	SCOPVAL_multo(res, lhs, rhs);
      else
	converter_fail (e, "unsupported operator in expression");
      CONVERTER_FAIL(0);
      SCOPVAL_clear(lhs);
      SCOPVAL_clear(rhs);
    }
  else if (past_node_is_a (e, past_unaminus))
    {
      PAST_DECLARE_TYPED(unary, pu, e);
      scoplib_int_t val = computeCoefficient(pu->expr, symb, NULL);
      CONVERTER_FAIL(0);
      SCOPVAL_set_si(res, - SCOPVAL_get_si(val));
      SCOPVAL_clear(val);
    }
  else if (past_node_is_a (e, past_unaplus))
    {
      PAST_DECLARE_TYPED(unary, pu, e);
      scoplib_int_t val = computeCoefficient(pu->expr, symb, NULL);
      CONVERTER_FAIL(0);
      SCOPVAL_assign(res, val);
      SCOPVAL_clear(val);
    }
  else
    {
      converter_fail (e, "unsupported node type in expression");
      CONVERTER_FAIL(0);
    }
  return res;
}


static
scoplib_matrix_p convLinExprSimpleAff (s_past_node_t* e, int min_ok, int max_ok,
				       int floord_ok, int ceild_ok,
				       scoplib_statement_p stmt,
				       scoplib_scop_p scop)
{
  int i, j;

  // -+(2+-3)*(i*(2+1)) + 42*j - str.size()
  scoplib_matrix_p ret =
    scoplib_matrix_malloc (1, stmt->nb_iterators + scop->nb_parameters + 2);
  // Compute constant coef.
  scoplib_int_t cst = computeCoefficient (e, NULL, NULL);
  CONVERTER_FAIL(NULL);
  SCOPVAL_assign (ret->p[0][ret->NbColumns - 1], cst);
  SCOPVAL_clear(cst);

  // Compute iterator coefs.
  for (i = 0; i < stmt->nb_iterators; ++i)
    {
      scoplib_int_t cst = computeCoefficient (e, stmt->iterators[i], NULL);
      CONVERTER_FAIL(NULL);
      SCOPVAL_subtract(cst, cst, ret->p[0][ret->NbColumns - 1]);
      SCOPVAL_assign (ret->p[0][i + 1], cst);
      SCOPVAL_clear(cst);
    }

  // Compute parameter coefs.
  for (i = 0; i < scop->nb_parameters; ++i)
    {
      scoplib_int_t cst = computeCoefficient (e, scop->parameters[i], NULL);
      CONVERTER_FAIL(NULL);
      SCOPVAL_subtract(cst, cst, ret->p[0][ret->NbColumns - 1]);
      SCOPVAL_assign (ret->p[0][i + 1 + stmt->nb_iterators], cst);
      SCOPVAL_clear(cst);
    }

  return ret;
}

static
scoplib_matrix_p convLinExprSimple (s_past_node_t* e, int min_ok, int max_ok,
				    int floord_ok, int ceild_ok,
				    scoplib_statement_p stmt,
				    scoplib_scop_p scop)
{
  int i;
  if (floord_ok && past_count_nodetype (e, past_floord))
    {
      // Expression contains floord. Ensure it's the top of the expression.
      if (! past_node_is_a (e, past_floord) ||
	  past_count_nodetype (e, past_floord) > 1)
	converter_fail (e, "ceild/floord cannot appear together with arithmetic expressions");
      PAST_DECLARE_TYPED(binary, pb, e);
      if (! past_node_is_a (pb->rhs, past_value))
	converter_fail (e, "only numerical value allowed for rhs of ceild/floord");
      scoplib_matrix_p ret =
	convLinExprSimpleAff (pb->lhs, min_ok, max_ok, floord_ok,
			      ceild_ok, stmt, scop);
      CONVERTER_FAIL(NULL);
      PAST_DECLARE_TYPED(value, pv, pb->rhs);
      SCOPVAL_set_si(ret->p[0][0], pv->value.intval);
      return ret;
    }
  else if (ceild_ok && past_count_nodetype (e, past_ceild))
    {
      // Expression contains ceild. Ensure it's the top of the expression.
      if (! past_node_is_a (e, past_ceild) ||
	  past_count_nodetype (e, past_ceild) > 1)
	converter_fail (e, "ceild/floord cannot appear together with arithmetic expressions");
      PAST_DECLARE_TYPED(binary, pb, e);
      if (! past_node_is_a (pb->rhs, past_value))
	converter_fail (e, "only numerical value allowed for rhs of floord/ceild");
      scoplib_matrix_p ret =
	convLinExprSimpleAff (pb->lhs, min_ok, max_ok, floord_ok,
			      ceild_ok, stmt, scop);
      CONVERTER_FAIL(NULL);
      PAST_DECLARE_TYPED(value, pv, pb->rhs);
      SCOPVAL_set_si(ret->p[0][0], pv->value.intval);
      return ret;
    }
  else
    {
      scoplib_matrix_p ret =
	convLinExprSimpleAff (e, min_ok, max_ok, floord_ok, ceild_ok,
			      stmt, scop);
      CONVERTER_FAIL(NULL);
      return ret;
    }
}


/**
 * Demangle max(max(...)) as multiple rows, ditto for min. Will reject
 * max(max(...) + ... or anything else than other (1) a min/max-less
 * expression and (2) a min/max tree w/o any other operations outside
 * the min/max arguments. This tree expects/requires min(min(... and
 * not min(..., min(...), that is, cascading min/max are in the LHS of
 * the binary, as generated by CLooG/PAST.
 *
 */
static
scoplib_matrix_p convLinExprBase (s_past_node_t* e, int min_ok, int max_ok,
				  int floord_ok, int ceild_ok,
				  scoplib_statement_p stmt,
				  scoplib_scop_p scop)
{
  int i, j, k;

  if (min_ok && past_count_nodetype (e, past_min))
    {
      // Expression contains min. Ensure it's the top of the expression.
      if (! past_node_is_a (e, past_min))
	converter_fail (e, "min/max cannot appear together with arithmetic expressions");
      CONVERTER_FAIL(NULL);
      s_past_node_t** mins = past_collect_nodetype_postfix (e, past_min);
      scoplib_matrix_p ret =
	scoplib_matrix_malloc (0, stmt->nb_iterators + scop->nb_parameters + 2);
      for (i = 0; mins && mins[i]; ++i)
	{
	  PAST_DECLARE_TYPED(binary, pb, mins[i]);
	  scoplib_matrix_p m =
	    convLinExprSimple (pb->rhs, min_ok, max_ok, floord_ok,
			       ceild_ok, stmt, scop);
	  CONVERTER_FAIL(NULL);
	  if (! past_node_is_a (pb->lhs, past_min))
	    {
	      scoplib_matrix_p m2 =
		convLinExprSimple (pb->lhs, min_ok, max_ok, floord_ok,
				   ceild_ok, stmt, scop);
	      CONVERTER_FAIL(NULL);
	      scoplib_matrix_p tmp = scoplib_matrix_concat (m, m2);
	      scoplib_matrix_free (m);
	      scoplib_matrix_free (m2);
	      m = tmp;
	    }
	  scoplib_matrix_p merged = scoplib_matrix_concat (ret, m);
	  scoplib_matrix_free (ret);
	  scoplib_matrix_free (m);
	  ret = merged;
	}
      return ret;
    }
  else if (max_ok && past_count_nodetype (e, past_max))
    {
      // Expression contains max. Ensure it's the top of the expression.
      if (! past_node_is_a (e, past_max))
	converter_fail (e, "min/max cannot appear together with arithmetic expressions");
      CONVERTER_FAIL(NULL);
      s_past_node_t** maxs = past_collect_nodetype_postfix (e, past_max);
      scoplib_matrix_p ret =
	scoplib_matrix_malloc (0, stmt->nb_iterators + scop->nb_parameters + 2);
      for (i = 0; maxs && maxs[i]; ++i)
	{
	  PAST_DECLARE_TYPED(binary, pb, maxs[i]);
	  scoplib_matrix_p m =
	    convLinExprSimple (pb->rhs, min_ok, max_ok, floord_ok,
			       ceild_ok, stmt, scop);
	  CONVERTER_FAIL(NULL);
	  if (! past_node_is_a (pb->lhs, past_max))
	    {
	      scoplib_matrix_p m2 =
		convLinExprSimple (pb->lhs, min_ok, max_ok, floord_ok,
				   ceild_ok, stmt, scop);
	      CONVERTER_FAIL(NULL);
	      scoplib_matrix_p tmp = scoplib_matrix_concat (m, m2);
	      scoplib_matrix_free (m);
	      scoplib_matrix_free (m2);
	      m = tmp;
	    }
	  scoplib_matrix_p merged = scoplib_matrix_concat (ret, m);
	  scoplib_matrix_free (ret);
	  scoplib_matrix_free (m);
	  ret = merged;
	}
      return ret;
    }
  else
    {
      scoplib_matrix_p ret =
	convLinExprSimple (e, min_ok, max_ok, floord_ok, ceild_ok, stmt, scop);
      CONVERTER_FAIL(NULL);
      return ret;
    }
}


static
scoplib_matrix_p convLinExpr (s_past_node_t* e, int min_ok, int max_ok,
			      int floord_ok, int ceild_ok,
			      scoplib_statement_p stmt,
			      scoplib_scop_p scop)
{
  int i, j, k;

  // 1. Sanity checks.
  // a. Ensure a single comparison op is there.
  s_past_node_t** binops = past_collect_nodetype (e, past_binary);
  s_past_node_t* comp_op = NULL;
  int nb_comp_op = 0;
  for (i = 0; binops && binops[i]; ++i)
    if (past_node_is_a (binops[i], past_lt) ||
	past_node_is_a (binops[i], past_leq) ||
	past_node_is_a (binops[i], past_gt) ||
	past_node_is_a (binops[i], past_geq) ||
	past_node_is_a (binops[i], past_equal))
      {
	comp_op = binops[i];
	++nb_comp_op;
      }
  XFREE(binops);
  if (nb_comp_op > 1)
    converter_fail (e, "at most one comparison operator allowed in expression");
  // b. Ensure no min/max/ceild/floord as expected.
  if (! min_ok && past_count_nodetype (e, past_min))
    converter_fail (e, "no min allowed in this expression");
  if (! max_ok && past_count_nodetype (e, past_max))
    converter_fail (e, "no max allowed in this expression");
  if (! floord_ok && past_count_nodetype (e, past_floord))
    converter_fail (e, "no floord allowed in this expression");
  if (! ceild_ok && past_count_nodetype (e, past_ceild))
    converter_fail (e, "no ceild allowed in this expression");
  CONVERTER_FAIL(NULL);

  // 2. Parse both sides of comp_op, if any.
  if (comp_op)
    {
      PAST_DECLARE_TYPED(binary, pb, comp_op);
      // Get both sides of comp. op.
      scoplib_matrix_p m1 =
	convLinExprBase (pb->lhs, min_ok, max_ok, floord_ok, ceild_ok, stmt,
			 scop);
      CONVERTER_FAIL(NULL);
      scoplib_matrix_p m2 =
	convLinExprBase (pb->rhs, min_ok, max_ok, floord_ok, ceild_ok, stmt,
			 scop);
      CONVERTER_FAIL(NULL);

      // printf ("DEBUG 1:\n");
      // past_pprint (stdout, e);
      // scoplib_matrix_print (stdout, m1);
      // scoplib_matrix_print (stdout, m2);
      // printf ("\n");

      // Properly adjust the sign of coefficients to model an inequality as
      // .... >= 0 or  .... == 0
      if (past_node_is_a (comp_op, past_lt))
	{
	  oppose_matrix (m1);
	  add_constant_matrix (m1, -1);
	}
      else if (past_node_is_a (comp_op, past_leq))
	oppose_matrix (m1);
      else if (past_node_is_a (comp_op, past_gt))
	{
	  oppose_matrix (m2);
	  add_constant_matrix (m2, 1);
	}
      else if (past_node_is_a (comp_op, past_geq) ||
	       past_node_is_a (comp_op, past_equal))
	oppose_matrix (m2);

      // printf ("DEBUG 2:\n");
      // scoplib_matrix_print (stdout, m1);
      // scoplib_matrix_print (stdout, m2);
      // printf ("\n");


      // Create the cartesian product of rows in m1 and m2 as final result.
      scoplib_matrix_p ret =
	scoplib_matrix_malloc (m1->NbRows * m2->NbRows,
			       stmt->nb_iterators + scop->nb_parameters + 2);
      for (i = 0; i < m1->NbRows; ++i)
	for (j = 0; j < m2->NbRows; ++j)
	  {
	    // Compute multiplier, coming from ceil/floor expressions.
	    scoplib_int_t multm2; SCOPVAL_init(multm2);
	    scoplib_int_t multm1; SCOPVAL_init(multm1);
	    if (SCOPVAL_get_si(m1->p[i][0]) != 0)
	      SCOPVAL_assign(multm2, m1->p[i][0]);
	    else
	      SCOPVAL_set_si(multm2, 1);
	    if (SCOPVAL_get_si(m2->p[j][0]) != 0)
	      SCOPVAL_assign(multm1, m2->p[j][0]);
	    else
	      SCOPVAL_set_si(multm1, 1);

	    // Add row i of m1*mult1 and row j of m2*mult2 into a new row.
	    scoplib_int_t tmp1; SCOPVAL_init(tmp1);
	    scoplib_int_t tmp2; SCOPVAL_init(tmp2);
	    for (k = 1; k < m1->NbColumns; ++k)
	      {
		SCOPVAL_multo(tmp1, m1->p[i][k], multm1);
		SCOPVAL_multo(tmp2, m2->p[j][k], multm2);
		SCOPVAL_addto(ret->p[i * m2->NbRows + j][k],
			      tmp1, tmp2);
	      }
	    SCOPVAL_clear(tmp1);
	    SCOPVAL_clear(tmp2);
	    SCOPVAL_clear(multm1);
	    SCOPVAL_clear(multm2);
	  }
      scoplib_matrix_free (m1);
      scoplib_matrix_free (m2);
      // Adjust/reset the eq/ineq flag.
      if (! past_node_is_a (comp_op, past_equal))
	set_ineq_matrix (ret);
      else
	set_eq_matrix (ret);
      return ret;
    }
  else
    {
      scoplib_matrix_p ret =
	convLinExprBase (e, min_ok, max_ok, floord_ok, ceild_ok, stmt, scop);
      CONVERTER_FAIL(NULL);
      return ret;
    }
}



static
scoplib_matrix_p convExpr (s_past_node_t* e, int min_ok, int max_ok,
			   int floord_ok, int ceild_ok,
			   scoplib_statement_p stmt,
			   scoplib_scop_p scop)
{
  if (past_node_is_a (e, past_and))
    {
      PAST_DECLARE_TYPED(binary, pb, e);
      scoplib_matrix_p m1 =
	convExpr(pb->lhs, min_ok, max_ok, floord_ok, ceild_ok, stmt, scop);
      CONVERTER_FAIL(NULL);
      scoplib_matrix_p m2 =
	convExpr(pb->rhs, min_ok, max_ok, floord_ok, ceild_ok, stmt, scop);
      CONVERTER_FAIL(NULL);
      scoplib_matrix_p ret = scoplib_matrix_concat (m1, m2);
      scoplib_matrix_free (m1);
      scoplib_matrix_free (m2);
      return ret;
    }
  else
    {
      scoplib_matrix_p ret =
	convLinExpr (e, min_ok, max_ok, floord_ok, ceild_ok, stmt, scop);
      CONVERTER_FAIL(NULL);
      return ret;
    }

}


static
scoplib_matrix_p converter (s_past_node_t* node,
			    scoplib_matrix_p base,
			    scoplib_statement_p stmt,
			    scoplib_scop_p scop)
{
  scoplib_matrix_p ret = scoplib_matrix_malloc (0, base->NbColumns);
  scoplib_matrix_p tmp;
  scoplib_matrix_p ret2;
  int i;

  if (past_node_is_a (node, past_for))
    {
      PAST_DECLARE_TYPED(for, pf, node);
      if (! past_node_is_a (pf->init, past_assign))
	converter_fail (pf->init, "expect a ... = ... for the init clause");
      CONVERTER_FAIL(NULL);
      PAST_DECLARE_TYPED(binary, pb, pf->init);
      // convert the expr, allowing for max and ceild. Expr is like
      // '42' in 'i = 42'
      tmp = convExpr (pb->rhs, 0, 1, 0, 1, stmt, scop);
      CONVERTER_FAIL(NULL);
      // oppose the matrix: i = 42 is actually i - 42 >= 0
      oppose_matrix (tmp);
      for (i = 0; i < stmt->nb_iterators &&
	     strcmp ((char*) stmt->iterators[i], pf->iterator->name_str);
	   ++i)
	  ;
      int iter_pos = i;
      for (i = 0; i < tmp->NbRows; ++i)
	{
	  // add i >= to all rows.
	  SCOPVAL_set_si(tmp->p[i][iter_pos + 1],
			 SCOPVAL_get_si(tmp->p[i][iter_pos + 1] + 1));
	  // multiply by denominator for ceild expressions, if any.
	  if (SCOPVAL_get_si(tmp->p[i][0]) != 0)
	    SCOPVAL_multo(tmp->p[i][iter_pos + 1], tmp->p[i][iter_pos + 1],
			  tmp->p[i][0]);
	  SCOPVAL_set_si(tmp->p[i][0], 1);
	}
      ret2 = scoplib_matrix_concat (ret, tmp);
      scoplib_matrix_free (ret);
      scoplib_matrix_free (tmp);
      ret = ret2;
      if (! past_node_is_a (pf->test, past_binary))
	converter_fail (pf->init, "expect a binary for the test clause");
      // convert the expr, allowing for min and floord. Expr is like 'i < N'.
      tmp = convExpr (pf->test, 1, 0, 1, 0, stmt, scop);
      CONVERTER_FAIL(NULL);
      ret2 = scoplib_matrix_concat (ret, tmp);
      scoplib_matrix_free (ret);
      scoplib_matrix_free (tmp);
      ret = ret2;
    }
  else if (past_node_is_a (node, past_if))
    {
      PAST_DECLARE_TYPED(if, pf, node);
      // Allow for min/max/ceild/floord, convexity is checked by convExpr.
      tmp = convExpr (pf->condition, 1, 1, 1, 1, stmt, scop);
      CONVERTER_FAIL(NULL);
      ret2 = scoplib_matrix_concat (ret, tmp);
      scoplib_matrix_free (ret);
      scoplib_matrix_free (tmp);
      ret = ret2;
    }
  else if (past_node_is_a (node, past_affineguard))
    {
      PAST_DECLARE_TYPED(affineguard, pf, node);
      // Allow for min/max/ceild/floord, convexity is checked by convExpr.
      tmp = convExpr (pf->condition, 1, 1, 1, 1, stmt, scop);
      CONVERTER_FAIL(NULL);
      ret2 = scoplib_matrix_concat (ret, tmp);
      scoplib_matrix_free (ret);
      scoplib_matrix_free (tmp);
      ret = ret2;
    }

  return ret;
}




static
scoplib_matrix_list_p
build_control_matrix (std::stack<s_past_node_t*>& cs,
		      std::set<s_symbol_t*> params,
		      scoplib_statement_p stmt,
		      scoplib_scop_p scop)
{
  int i, j;
  std::set<s_symbol_t*>::iterator it;

  // count the number of loops in the control stack.
  int nb_iter = 0;
  std::vector<s_symbol_t*> itersyms;
  s_past_node_t* its;
  std::vector<s_past_node_t*> csr;
  std::vector<s_past_node_t*>::iterator itv;
  std::stack<s_past_node_t*> ctrl_bk = cs;
  while (cs.size())
    {
      its = cs.top();
      cs.pop();
      if (past_node_is_a (its, past_for))
	{
	  ++nb_iter;
	  PAST_DECLARE_TYPED(for, pf, its);
	  itersyms.push_back(pf->iterator);
	}
      csr.push_back(its);
    }
  // add fake iterator around statements surrounded by 0 loop.
  int has_fake_iterator = nb_iter == 0;
  if (has_fake_iterator)
    {
      nb_iter = 1;
      stmt->iterators = XMALLOC(char*, 2);
      stmt->iterators[0] = strdup ("fk");
    }
  else
    {
      stmt->iterators = XMALLOC(char*, nb_iter + 1);
      if (nb_iter)
	{
	  for (i = 0; i < nb_iter; ++i)
	    stmt->iterators[i] = strdup ((char*)itersyms[i]->name_str);
	}
    }
  stmt->nb_iterators = nb_iter;
  stmt->iterators[nb_iter] = NULL;

  // Create the initial matrix, 0-sized.
  scoplib_matrix_p ret = scoplib_matrix_malloc (0, 2 + nb_iter + params.size());

  // parse the control, convert to matrix representation.
  if (has_fake_iterator)
    {
      scoplib_matrix_free (ret);
      ret = scoplib_matrix_malloc (1, 2 + nb_iter + params.size());
      SCOPVAL_set_si(ret->p[0][1], 1);
    }
  else
    for (itv = csr.begin(); itv != csr.end(); ++itv)
      {
	scoplib_matrix_p cmat = converter (*itv, ret, stmt, scop);
	CONVERTER_FAIL(NULL);
	scoplib_matrix_p ret2 = scoplib_matrix_concat (ret, cmat);
	scoplib_matrix_free (cmat);
	scoplib_matrix_free (ret);
	ret = ret2;
      }
  cs = ctrl_bk;

  scoplib_matrix_list_p retl = scoplib_matrix_list_malloc ();
  retl->elt = ret;
  return retl;
}

static
void build_access_functions (s_past_node_t* stmt,
			     std::set<s_symbol_t*>& read_arrays,
			     std::set<s_symbol_t*>& write_arrays,
			     scoplib_statement_p sc,
			     scoplib_scop_p ret)
{
  int i, j;
  std::set<s_symbol_t*>::iterator it;
  int stmt_is_vardecl = past_count_nodetype (stmt, past_vardecl);

  for (int cnt = 0; cnt < 2; ++cnt)
    {
      scoplib_matrix_p acc =
	scoplib_matrix_malloc (0, sc->nb_iterators + ret->nb_parameters + 2);

      s_symbol_t** s = NULL;
      if (cnt == 0)
	s = past_collect_read_symbols (stmt);
      else
	{
	  if (s)
	    XFREE(s);
	  s = past_collect_write_symbols (stmt);
	}
      for (i = 0; s && s[i]; ++i)
	{
	  // Skip variable declarations: make them read/write
	  // "nothing".  Reason: needs to implement a computation of
	  // the number of array dimensions to properly size array
	  // declarations.
	  if (stmt_is_vardecl)
	    break;

	  s_past_node_t** vrefs =
	    past_collect_nodetype_postfix (stmt, past_varref);
	  for (j = 0; j < ret->nb_arrays &&
		 strcmp (s[i]->name_str, ret->arrays[j]); ++j)
	      ;
	  if (j == ret->nb_arrays)
	    continue;
	  int arr_id = j + 1; // variables are 1-indexed.
	  for (j = 0; vrefs && vrefs[j]; ++j)
	    {
	      PAST_DECLARE_TYPED(varref, pvar, vrefs[j]);
	      if (symbol_equal (pvar->symbol, s[i]))
		{
		  s_past_node_t* parent = vrefs[j]->parent;
		  scoplib_matrix_p ref = scoplib_matrix_malloc
		    (0, sc->nb_iterators + ret->nb_parameters + 2);
		  while (parent && past_node_is_a (parent, past_arrayref))
		    {
		      PAST_DECLARE_TYPED(binary, pb, parent);
		      scoplib_matrix_p ret2 =
			convExpr (pb->rhs, 0, 0, 0, 0, sc, ret);
		      CONVERTER_FAIL();
		      scoplib_matrix_p rc =
			scoplib_matrix_concat (ref, ret2);
		      scoplib_matrix_free (ref);
		      scoplib_matrix_free (ret2);
		      ref = rc;
		      parent = parent->parent;
		    }
		  // scalar ref.
		  if (ref->NbRows == 0)
		    {
		      scoplib_matrix_free (ref);
		      ref = scoplib_matrix_malloc
			(1, sc->nb_iterators + ret->nb_parameters + 2);
		    }
		  SCOPVAL_set_si(ref->p[0][0], arr_id);
		  scoplib_matrix_p rc = scoplib_matrix_concat (acc, ref);
		  scoplib_matrix_free (acc);
		  scoplib_matrix_free (ref);
		  acc = rc;
		}
	    }
	}
      if (cnt == 0)
	sc->read = acc;
      else
	sc->write = acc;
    }
}
/**
 *
 */
static
void traverse_buildAstMap (s_past_node_t* node, void* args)
{
  void** data = (void**)args;
  std::map<s_past_node_t*, int>* astNumber =
    (std::map<s_past_node_t*, int>*)data[0];
  std::map<s_past_node_t*, int>* astCounter =
    (std::map<s_past_node_t*, int>*)data[1];
  if (past_node_is_a (node, past_for) ||
      past_node_is_a (node, past_statement) ||
      past_node_is_a (node, past_cloogstmt))
    {
      s_past_node_t* enc = past_get_enclosing_node (node, past_for);
      (*astNumber)[node] = ((*astCounter)[enc])++;
    }
}


static
std::map<s_past_node_t*, int> build_sched_info (s_past_node_t* root)
{
  std::map<s_past_node_t*, int> astNumber;
  std::map<s_past_node_t*, int> astCounter;
  int i;
  s_past_node_t** forloops = past_collect_nodetype (root, past_for);
  for (i = 0; forloops && forloops[i]; ++i)
    astCounter[forloops[i]] = 0;
  astCounter[NULL] = 0;
  void* data[3]; data[0] = &astNumber; data[1] = &astCounter;

  past_visitor (root, traverse_buildAstMap, (void*)data, NULL, NULL);

  return astNumber;
}

static
scoplib_matrix_p build_schedule (s_past_node_t* node,
				 std::map<s_past_node_t*, int>& m,
				 std::stack<s_past_node_t*>& control,
				 scoplib_statement_p stm,
				 scoplib_scop_p scop)
{
  int stmtAstId = m[node];
  int i;
  std::vector<int> sched;
  while (control.size())
    {
      s_past_node_t* n = control.top();
      control.pop();
      if (past_node_is_a (n, past_for))
	sched.push_back (m[n]);
    }

  // deal with fake iterator here.
  if (sched.size() == 0)
    {
      sched.push_back (stmtAstId);
      sched.push_back (0);
    }
  else
    sched.push_back(stmtAstId);

  int sz = sched.size();
  int nbScatt = 2 * sz - 1;
  scoplib_matrix_p res =
    scoplib_matrix_malloc(nbScatt, stm->nb_iterators + scop->nb_parameters + 2);

  for (i = 0; i < nbScatt; ++i)
    {
      if (i % 2 == 1)
	SCOPVAL_set_si(res->p[i][1 + i/2], 1);
      else
	SCOPVAL_set_si(res->p[i][res->NbColumns - 1], sched[i/2]);
    }

  return res;
}


/**
 * Fixme: not needed anymore.
 *
 */
static
void beta_normalization (scoplib_scop_p scop)
{
  scoplib_statement_p s;
  int i, j;
  int cont;
  int curr_row = 0;
  do
    {
      cont = 0;
      std::set<int> vals;
      std::set<int>::iterator it;
      std::map<int,int> repl;
      for (s = scop->statement; s; s = s->next)
	{
	  if (curr_row + 1 < s->schedule->NbRows)
	    cont = 1;
	  // collect all entries for that beta level.
	  if (curr_row < s->schedule->NbRows)
	    {
	      int val = SCOPVAL_get_si(s->schedule->p[curr_row][s->schedule->NbColumns - 1]);
	      vals.insert (val);
	      repl[val] = 0;
	    }
	}
      // sort the set of values.
      std::vector<int> v;
      for (it = vals.begin(); it != vals.end(); ++it)
	v.push_back (*it);
      for (i = 0; i < v.size() - 1; ++i)
	for (j = i + 1; j < v.size(); ++j)
	  if (v[j] < v[i])
	    {
	      int tmp = v[i];
	      v[i] = v[j];
	      v[j] = tmp;
	    }
      // Update the map.
      for (i = 0; i < v.size(); ++i)
	repl[v[i]] = i;
      // Update the statement schedules.
      for (s = scop->statement; s; s = s->next)
	if (curr_row < s->schedule->NbRows)
	  SCOPVAL_set_si(s->schedule->p[curr_row][s->schedule->NbColumns - 1],
			 repl[s->schedule->p[curr_row][s->schedule->NbColumns - 1]]);

      curr_row += 2;
    }
  while (cont);
}


/**
 * Converts a tree produced by pastScopRecognizer into a scoplib
 * representation. Each past_statement pointer is kept in the 'usr' attribute
 * of the associated scoplib_statement_p.
 *
 */
scoplib_scop_p pastScopConverter (s_past_node_t* root)
{
  past_rebuild_symbol_table (root);

  scoplib_scop_p ret = scoplib_scop_malloc ();
  int i, j;
  /// FIXME: deal with cloogstatements?
  s_past_node_t** cstmts = past_collect_nodetype (root, past_cloogstmt);
  if (cstmts && cstmts[0])
    {
      printf ("[WARNING] CloogStatements cannot be converted to scoplib without original scop. Use past2scop_control_only as needed\n");
    }
  XFREE(cstmts);

  // Collect all parameters.
  std::set<s_symbol_t*> params;
  // a. collect all loop iterators.
  s_past_node_t** forloops = past_collect_nodetype (root, past_for);
  int nb_for = past_count_nodetype (root, past_for);
  s_symbol_t* foriters[nb_for + 1];
  for (i = 0; forloops && forloops[i]; ++i)
    {
      PAST_DECLARE_TYPED(for, pf, forloops[i]);
      foriters[i] = pf->iterator;
    }
  foriters[i] = NULL;

  // b. create list of all non-iterator symbols used in all for
  // expressions and if conditionals, a.k.a. scop parameters.
  for (i = 0; forloops && forloops[i]; ++i)
    {
      PAST_DECLARE_TYPED(for, pf, forloops[i]);
      s_symbol_t** syms = past_collect_read_symbols (pf->init);
      merge_to_set_noiter (params, syms, foriters);
      XFREE(syms);
      syms = past_collect_read_symbols (pf->test);
      merge_to_set_noiter (params, syms, foriters);
      XFREE(syms);
    }
  XFREE(forloops);
  s_past_node_t** cond = past_collect_nodetype (root, past_if);
  for (i = 0; cond && cond[i]; ++i)
    {
      PAST_DECLARE_TYPED(if, pf, cond[i]);
      s_symbol_t** syms = past_collect_read_symbols (pf->condition);
      merge_to_set_noiter (params, syms, foriters);
      XFREE(syms);
    }
  XFREE(cond);
  cond = past_collect_nodetype (root, past_affineguard);
  for (i = 0; cond && cond[i]; ++i)
    {
      PAST_DECLARE_TYPED(affineguard, pf, cond[i]);
      s_symbol_t** syms = past_collect_read_symbols (pf->condition);
      merge_to_set_noiter (params, syms, foriters);
      XFREE(syms);
    }
  XFREE(cond);

  // c. Store the parameter array in the scop.
  char** pars = XMALLOC(char*, params.size() + 1);
  pars[params.size()] = NULL;
  std::set<s_symbol_t*>::iterator it;
  if (params.size())
    {
      s_symbol_t* s = *(params.begin());
      char buff[32];
      for (it = params.begin(), i = 0; it != params.end(); ++it, ++i)
	pars[i] = strdup ((char*)(*it)->name_str);
    }
  ret->parameters = pars;
  ret->nb_parameters = params.size();
  // d. Create the context matrix (0 row, as no context info).
  ret->context = scoplib_matrix_malloc (0, ret->nb_parameters + 2);

  // Collect all array/scalars accessed in the scop.
  std::set<s_symbol_t*> arrays;
  std::set<s_symbol_t*> read_arrays;
  std::set<s_symbol_t*> write_arrays;
  s_symbol_t** syms = past_collect_read_symbols (root);
  merge_to_set_noiter (arrays, syms, foriters);
  merge_to_set_noiter (read_arrays, syms, foriters);
  XFREE(syms);
  syms = past_collect_write_symbols (root);
  merge_to_set_noiter (arrays, syms, foriters);
  merge_to_set_noiter (write_arrays, syms, foriters);
  XFREE(syms);
  for (it = params.begin(); it != params.end(); ++it)
    {
      arrays.erase (*it);
      read_arrays.erase (*it);
      write_arrays.erase (*it);
    }
  char** arrs = XMALLOC(char*, arrays.size() + 1);
  if (arrays.size())
    {
      char buff[32];
      for (it = arrays.begin(), i = 0; it != arrays.end(); ++it, ++i)
	arrs[i] = strdup ((char*)(*it)->name_str);
    }
  arrs[arrays.size()] = NULL;
  ret->arrays = arrs;
  ret->nb_arrays = arrays.size();

  // Prepare the AST numbering.
  std::map<s_past_node_t*, int> mAST = build_sched_info (root);

  // Iterate on all statements, build control stack and statement structure.
  s_past_node_t** stmts = past_collect_nodetype (root, past_statement);
  scoplib_statement_p* curr_stmt = &(ret->statement);
  for (i = 0; stmts && stmts[i]; ++i)
    {
      scoplib_statement_p sc = scoplib_statement_malloc ();
      // 1. build control stack, collecting all control parents.
      std::stack<s_past_node_t*> control;
      s_past_node_t* parent = stmts[i]->parent;
      while (parent && parent != root->parent)
	{
	  if (past_node_is_a (parent, past_if) ||
	      past_node_is_a (parent, past_affineguard) ||
	      past_node_is_a (parent, past_for))
	    control.push (parent);
	  parent = parent->parent;
	}

      // 2. Build iteration domain.
      sc->domain = build_control_matrix (control, params, sc, ret);
      CONVERTER_FAIL(NULL);

      // 3. Build access functions.
      build_access_functions (stmts[i], read_arrays, write_arrays, sc, ret);
      CONVERTER_FAIL(NULL);

      // 4. Build schedule.
      sc->schedule = build_schedule (stmts[i], mAST, control, sc, ret);

      // 5. Keep track of the statement pointer.
      sc->usr = stmts[i];

      // 6. Fill-in the body in textual form, for convenience
      FILE* tmpf = fopen ("___tmp___dump.txt", "w");
      s_past_node_t* next = stmts[i]->next;
      stmts[i]->next = NULL;
      past_pprint (tmpf, stmts[i]);
      stmts[i]->next = next;
      fclose (tmpf);
      tmpf = fopen ("___tmp___dump.txt", "r");
      // make the bet a statement is never more than 8k...
      char* buffer = XMALLOC(char, 8192);
      int sz = fread (buffer, sizeof(char), 8192, tmpf);
      if (sz >= 8192)
	converter_fail (stmts[i], "statement size cannot be more than 8k characters");
      CONVERTER_FAIL(NULL);
      buffer[sz] = 0;
      sc->body = strdup (buffer);
      XFREE(buffer);
      fclose (tmpf);

      // insert the statement.
      *curr_stmt = sc;
      curr_stmt = &(sc->next);
    }
  XFREE(stmts);

  // // Reduce range of beta vectors, for easier reading.
  // beta_normalization (ret);

  return ret;
}
