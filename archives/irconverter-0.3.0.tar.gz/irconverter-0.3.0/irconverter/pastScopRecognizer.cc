/*
 * p2s.cc: This file is part of the IR-Converter project.
 *
 * IR-Converter: a library to convert PAST to ScopLib
 *
 * Copyright (C) 2011 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#if HAVE_CONFIG_H
# include <irconverter/config.h>
#endif

#include <irconverter/common.h>
#include <irconverter/stack.h>
#include <irconverter/pastScopRecognizer.h>
#include <irconverter/pastScopConverter.h>
#include <past/past_api.h>
#include <past/pprint.h>

#include <assert.h>

#include <vector>
#include <set>
#include <string>
#include <algorithm>

static int verbose;

static
void extractor_fail (s_past_node_t* node, std::string msg)
{
  if (verbose)
    {
      printf ("[ScopExtractor] Node:\n");
      past_pprint (stdout, node);
      printf ("\nin: \n");
      past_pprint (stdout, node->parent);
      printf ("\nFAIL => %s\n", msg.c_str());
    }
}

static
int past_is_scop(s_past_node_t* node,
		 std::set<s_past_node_t*>& valid,
		 std::set<s_past_node_t*>& invalid);

static
int past_expr_is_scop(s_past_node_t* node,
		      s_symbol_t** invalid_syms,
		      std::set<s_past_node_t*>& valid,
		      std::set<s_past_node_t*>& invalid)
{
  int i, j;
  // 1. Ensure symbols in expression are only read-only symbols in scope.
  s_past_node_t** vrefs = past_collect_nodetype (node, past_varref);
  for (i = 0; vrefs && vrefs[i]; ++i)
    {
      PAST_DECLARE_TYPED(varref, pv, vrefs[i]);
      for (j = 0; invalid_syms && invalid_syms[j]; ++j)
	{
	  if (symbol_equal (pv->symbol, invalid_syms[j]))
	    break;
	}
      if (invalid_syms[j])
	{
	  XFREE(vrefs);
	  extractor_fail (node, "expression uses symbol(s) written in scope");
	  return 0;
	}
    }
  XFREE(vrefs);

  // 2. Ensure no symbol is written in expression, just in case.
  s_symbol_t** rs = past_collect_write_symbols_noloopiter (node);
  int has_rw = rs[0] != NULL;
  XFREE(rs);
  if (has_rw)
    {
      extractor_fail (node, "expression writes symbol(s)");
      return 0;
    }

  // 3. Ensure only supported node types.
  // supported types: +, -, *, un-, un+, &&, ternary,
  // min/max/ceild/floord, value, varref, dot, arrow,
  // <, <=, >=, >, ==
  // funcall with side-effect free
  cs_past_node_type_t* oktypes[] =
    {
      past_add, past_sub, past_mul, past_unaminus, past_unaplus,
      past_ternary_cond, past_and, past_value, past_varref,
      past_min, past_max, past_ceild, past_floord, past_lt, past_leq,
      past_dot, past_arrow, past_gt, past_geq, past_equal, past_funcall
    };
  if (! past_node_type_in_set (node, oktypes))
    {
      extractor_fail (node, "expression contains unsupported node types");
      return 0;
    }
  s_past_node_t** funcalls = past_collect_nodetype (node, past_funcall);
  for (i = 0; funcalls && funcalls[i]; ++i)
    {
      PAST_DECLARE_TYPED(funcall, pf, funcalls[i]);
      if (! pf->is_pure_function)
	{
	  extractor_fail (node, "only pure functions are allowed");
	  XFREE(funcalls);
	  return 0;
	}
    }
  XFREE(funcalls);

  // 4. Ensure lhs and rhs of a * does not contain both a varref.
  s_past_node_t** muls = past_collect_nodetype (node, past_mul);
  for (i = 0; muls && muls[i]; ++i)
    {
      PAST_DECLARE_TYPED(binary, pb, muls[i]);
      s_past_node_t** lhs = past_collect_nodetype (pb->lhs, past_varref);
      s_past_node_t** rhs = past_collect_nodetype (pb->rhs, past_varref);
      int ok = lhs[0] == NULL || rhs[0] == NULL;
      XFREE(lhs);
      XFREE(rhs);
      if (! ok)
	{
	  extractor_fail (node, "expression is not affine (required)");
	  return 0;
	}
    }

  // 5. Ensure ternary models min/max only.
  s_past_node_t** tern = past_collect_nodetype (node, past_ternary_cond);
  int tern_is_min = 0;
  int tern_is_max = 0;
  for (i = 0; tern && tern[i]; ++i)
    {
      PAST_DECLARE_TYPED(ternary_cond, pt, tern[i]);
      // min: a < b ? a : b
      // min: a > b ? a : b
      /// FIXME: will reject ceild and floord as min/max.
      if (! past_node_is_a (pt->cond, past_lt) &&
	  ! past_node_is_a (pt->cond, past_gt))
	break;
      PAST_DECLARE_TYPED(binary, pb, pt->cond);
      if (past_tree_are_equal (pb->lhs, pt->true_clause))
	break;
      if (past_tree_are_equal (pb->rhs, pt->false_clause))
	break;
      if (past_node_is_a (pt->cond, past_lt))
	tern_is_min = 1;
      tern_is_max = !tern_is_min;
    }
  int ret = tern[i] == NULL;
  if (! ret)
    extractor_fail (node,
		    "ternary operators do not model a min/max (required)");
  XFREE(tern);

  // 6. Ensure convexity. i >= max, and i <= min only.
  /// FIXME: currently only caught at conversion.

  return ret;
}

static
int past_expr_if_is_scop(s_past_node_t* node,
			 std::set<s_past_node_t*>& valid,
			 std::set<s_past_node_t*>& invalid)
{
  s_symbol_t** w = past_collect_write_symbols_noloopiter (node);
  int ret = past_expr_is_scop(node, w, valid, invalid);
  XFREE(w);

  return ret;
}

static
int past_expr_for_is_scop(s_past_node_t* node,
			  s_past_for_t* fullfor,
			  int is_lb_expr,
			  std::set<s_past_node_t*>& valid,
			  std::set<s_past_node_t*>& invalid)
{
  int ret = 0;
  if (is_lb_expr && ! past_node_is_a (node, past_assign))
    {
      extractor_fail (node, "init not an assignment (required)");
      return 0;
    }
  if (! past_node_is_a (node, past_binary))
    {
      extractor_fail (node, "expect binary node (required)");
      return 0;
    }
  PAST_DECLARE_TYPED(binary, pb, node);
  if (is_lb_expr)
    {
      if (past_node_is_a (pb->lhs, past_vardecl))
	{
	  // Init is a vardecl.
	  PAST_DECLARE_TYPED(vardecl, pv, pb->lhs);
	  // ensure type is int.
	  if (! past_type_is_integral (pv->type))
	    {
	      extractor_fail (pb->lhs, "not an integral type (required)");
	      return 0;
	    }
	  // ensure symbol matches loop iterator
	  if (! past_node_is_a (pv->name, past_varref))
	    {
	      extractor_fail (pb->lhs,
			  "only scalar variables can be declared here (required)");
	      return 0;
	    }
	  PAST_DECLARE_TYPED(varref, pvar, pv->name);
	  if (! symbol_equal (pvar->symbol, fullfor->iterator))
	    {
	      extractor_fail (pb->lhs,
			  "does not match for loop iterator symbol (required)");
	      return 0;
	    }
	}
      s_symbol_t** w = past_collect_write_symbols_noloopiter (fullfor->body);
      ret = past_expr_is_scop (pb->rhs, w, valid, invalid);
      XFREE(w);
    }
  else
    {
      s_symbol_t** w = past_collect_write_symbols_noloopiter (fullfor->body);
      ret = past_expr_is_scop (pb->rhs, w, valid, invalid);
      XFREE(w);
    }

  return ret;
}

static
int past_check_statement(s_past_node_t* node,
			 std::set<s_past_node_t*>& valid,
			 std::set<s_past_node_t*>& invalid)
{
  int ret = 1;

  int i;
  // 1. Ensure all array access expressions are affine.
  // 1.a find enclosing loop, if any, or root.
  s_past_node_t* enc;
  for (enc = node->parent; enc && ! past_node_is_a (enc, past_for) &&
	 ! past_node_is_a (enc, past_root); enc = enc->parent)
    ;
  s_symbol_t** w = past_collect_write_symbols_noloopiter (enc);
  s_past_node_t** arrefs = past_collect_nodetype (node, past_arrayref);
  for (i = 0; arrefs && arrefs[i]; ++i)
    {
      PAST_DECLARE_TYPED(binary, pa, arrefs[i]);
      if (! past_expr_is_scop (pa->rhs, w, valid, invalid))
	{
	  extractor_fail (arrefs[i], "array access is not affine");
	  break;
	}
    }
  ret = arrefs[i] == NULL;
  XFREE(arrefs);
  XFREE(w);

  // 2. Ensure a single variable is written.
  w = past_collect_write_symbols (node);
  int single_write = !w || !w[0] || w[1] == NULL;
  XFREE(w);
  if (! single_write)
    {
      ret = 0;
      extractor_fail (node, "more than 1 assignment in statement");
    }

  // 3. Ensure all function calls are side-effect free.
  s_past_node_t** funcalls = past_collect_nodetype (node, past_funcall);
  for (i = 0; funcalls && funcalls[i]; ++i)
    {
      PAST_DECLARE_TYPED(funcall, pf, funcalls[i]);
      if (! pf->is_pure_function)
	{
	  ret = 0;
	  extractor_fail (funcalls[i], "function call not marked as side-effect free");
	  break;
	}
    }
  XFREE(funcalls);

  if (ret)
    {
      s_past_node_t** allnodes = past_collect_nodetype (node, past_node);
      for (i = 0; allnodes && allnodes[i]; ++i)
	valid.insert(allnodes[i]);
      XFREE(allnodes);
    }
  else
    invalid.insert(node);

  return ret;
}

static
int past_check_loop_increment(s_past_for_t* node,
			      std::set<s_past_node_t*>& valid,
			      std::set<s_past_node_t*>& invalid)
{
  if (! past_for_is_stride_one(node))
    {
      extractor_fail (node->increment, "not a stride-1 loop (required)");
      return 0;
    }
  // Ensure the iterator is not written in the loop body.
  s_symbol_t** syms = past_collect_write_symbols (node->body);
  int i;
  int ret = 1;
  for (i = 0; syms && syms[i]; ++i)
    if (symbol_equal (node->iterator, syms[i]))
      {
	extractor_fail (node->increment, "loop iterator assigned in loop body");
	ret = 0;
	break;
      }
  XFREE(syms);

  return ret;
}

static
int past_check_for(s_past_node_t* node,
		   std::set<s_past_node_t*>& valid,
		   std::set<s_past_node_t*>& invalid)
{
  int ret = 1;

  if (! past_node_is_a (node, past_for))
    return 0;
  PAST_DECLARE_TYPED(for, pf, node);

  // Check the body is affine.
  ret = past_is_scop (pf->body, valid, invalid);
  if (! ret)
    extractor_fail (pf->body, "loop body is not a scop (required)");
  if (ret)
    // Check the loop increment.
    ret = past_check_loop_increment (pf, valid, invalid);
  if (ret)
    // Check the loop lb.
    ret = past_expr_for_is_scop (pf->init, pf, 1, valid, invalid);
  if (! ret)
    extractor_fail (pf->init, "loop init is not affine (required)");
  if (ret)
    // Check the loop ub.
    ret = past_expr_for_is_scop (pf->test, pf, 0, valid, invalid);
  if (! ret)
    extractor_fail (pf->test, "loop test is not affine (required)");

  int i;
  s_past_node_t** nodes;
  if (ret)
    {
      nodes = past_collect_nodetype (node, past_node);
      for (i = 0; nodes && nodes[i]; ++i)
	valid.insert(nodes[i]);
    }
  else
    {
      // insert for node and its bounds and increment as non-scop.
      nodes = past_collect_nodetype (pf->init, past_node);
      for (i = 0; nodes && nodes[i]; ++i)
	invalid.insert(nodes[i]);
      XFREE(nodes);
      nodes = past_collect_nodetype (pf->test, past_node);
      for (i = 0; nodes && nodes[i]; ++i)
	invalid.insert(nodes[i]);
      XFREE(nodes);
      nodes = past_collect_nodetype (pf->increment, past_node);
      for (i = 0; nodes && nodes[i]; ++i)
	invalid.insert(nodes[i]);
      invalid.insert(node);
    }
  XFREE(nodes);

  return ret;
}

static
int past_check_if(s_past_node_t* node,
		  std::set<s_past_node_t*>& valid,
		  std::set<s_past_node_t*>& invalid)
{
  int ret = 1;
  if (! past_node_is_a (node, past_if))
    return 0;
  PAST_DECLARE_TYPED(if, pf, node);

  // No else clause: it causes a disjunction. Need openscop to support
  // this.
  if (pf->else_clause)
    ret = 0;
  else
    {
      // Check the then_clause is affine.
      ret = past_is_scop (pf->then_clause, valid, invalid);
      if (ret)
	// Check the conditional.
	ret = past_expr_if_is_scop (pf->condition, valid, invalid);
    }
  int i;
  s_past_node_t** nodes;
  if (ret)
    {
      nodes = past_collect_nodetype (node, past_node);
      for (i = 0; nodes && nodes[i]; ++i)
	valid.insert(nodes[i]);
    }
  else
    {
      // Insert the if node and its conditional as non-valid.
      invalid.insert(node);
      nodes = past_collect_nodetype (pf->condition, past_node);
      for (i = 0; nodes && nodes[i]; ++i)
	invalid.insert(nodes[i]);
    }
  XFREE(nodes);

  return ret;
}

static
int past_check_block(s_past_node_t* node,
		     std::set<s_past_node_t*>& valid,
		     std::set<s_past_node_t*>& invalid)
{
  int ret = 1;

  s_past_node_t* tmp;
  if (! past_node_is_a (node, past_block))
    return 0;
  PAST_DECLARE_TYPED(block, pb, node);
  for (tmp = pb->body; tmp; tmp = tmp->next)
    if (std::find(valid.begin(), valid.end(), tmp) == valid.end())
      {
	ret = 0;
	extractor_fail (pb->body,
			"not all statements in block are valid scops");
	break;
      }
  if (! tmp)
    valid.insert (node);

  return ret;
}


static
int past_is_scop(s_past_node_t* node,
		 std::set<s_past_node_t*>& valid,
		 std::set<s_past_node_t*>& invalid)
{
  int ret = 1;
  past_set_parent (node);
  int i, j;
  // Prevent past_dot and past_arrow to be scops for the moment
  // (scoplib does not allow their general support).
  if (past_count_nodetype (node, past_dot) ||
      past_count_nodetype (node, past_arrow))
    {
	extractor_fail (node,
			"cannot contain past_dot or past_arrow");
	return 0;
    }
  // Collect nodes in postfix order.
  s_past_node_t** nodes = past_collect_nodetype_postfix (node, past_node);
  for (i = 0; nodes && nodes[i]; ++i)
    {
      // Skip already processed nodes.
      if (std::find (valid.begin(), valid.end(), nodes[i]) != valid.end())
	continue;
      // If a node is invalid, well, it's not a scop!
      if (std::find (invalid.begin(), invalid.end(), nodes[i]) != invalid.end())
	{
	  XFREE(nodes);
	  return 0;
	}
      // Check node.
      // Only these node types need to be handled for scop extraction:
      else if (past_node_is_a (nodes[i], past_statement))
	ret &= past_check_statement (nodes[i], valid, invalid);
      else if (past_node_is_a (nodes[i], past_if))
	ret &= past_check_if (nodes[i], valid, invalid);
      else if (past_node_is_a (nodes[i], past_for))
	ret &= past_check_for (nodes[i], valid, invalid);
      else if (past_node_is_a (nodes[i], past_block))
	ret &= past_check_block (nodes[i], valid, invalid);
      // Must be affine/valid nodes.
      else if (past_node_is_a (nodes[i], past_affineguard) ||
	       past_node_is_a (nodes[i], past_cloogstmt))
	{
	  s_past_node_t** naff = past_collect_nodetype (nodes[i], past_node);
	  for (j = 0; naff && naff[j]; ++j)
	    valid.insert(naff[j]);
	  XFREE(naff);
	}
    }
  // If all nodes are valid, then it is a (sub-)scop.
  for (i = 0; nodes && nodes[i]; ++i)
    if (std::find (valid.begin(), valid.end(), nodes[i]) == valid.end())
      {
	extractor_fail (nodes[i], "node is not a scop");
	ret = 0;
	break;
      }
  XFREE(nodes);

  return ret;
}

static
int
past_has_iterator_liveout (s_past_node_t* s1, s_past_node_t* s2)
{
  /// FIXME: not implemented.
  return 0;

  int i;
  // 1. collect all iterator symbols in the scop.
  std::set<s_symbol_t*> iters;
  s_past_node_t** fl = past_collect_nodetype (s1, past_for);
  for (i = 0; fl && fl[i]; ++i)
    {
      // insert the iterator only if it's not a vardecl in the init clause.
      PAST_DECLARE_TYPED(for, pf, fl[i]);
      PAST_DECLARE_TYPED(binary, pb, pf->init);
      if (! past_node_is_a (pb->lhs, past_vardecl))
	iters.insert(pf->iterator);
    }
  XFREE(fl);
  for (s1 = s2; s1 && s1 != s2->next; s1 = s1->next)
    {
      s_past_node_t** fl = past_collect_nodetype (s1, past_for);
      for (i = 0; fl && fl[i]; ++i)
	{
	  PAST_DECLARE_TYPED(for, pf, fl[i]);
	  PAST_DECLARE_TYPED(binary, pb, pf->init);
	  if (! past_node_is_a (pb->lhs, past_vardecl))
	    iters.insert(pf->iterator);
	}
      XFREE(fl);
    }

  // 2. Collect all read/written symbols in the fundecl/root.
  s_past_node_t* tmp = s1->parent;
  while (tmp && ! past_node_is_a (tmp, past_fundecl) &&
	 ! past_node_is_a (tmp, past_root))
    tmp = tmp->parent;

  /// FIXME: complete this function!!
  return 0;
}


/**
 * Returns a NULL-terminated array of past nodes that are the single
 * root of a SCoP. In case of sibling nodes being scops, a single
 * basic block is created and returned.
 *
 */
s_past_node_t**
pastScopRecognizer (s_past_node_t* root, int verbose_level)
{
  past_set_parent (root);
  verbose = verbose_level;
  std::set<s_past_node_t*> validNodes;
  std::set<s_past_node_t*> validFor;
  std::set<s_past_node_t*> invalidNodes;
  int i, j;

  // 0. Mark all 'past_generic' nodes as "black holes" (invalid nodes for
  // them and all their ascendants).
  s_past_node_t** nodes = past_collect_nodetype_postfix (root, past_generic);
  for (i = 0; nodes && nodes[i]; ++i)
    {
      s_past_node_t* tmp = nodes[i];
      while (tmp)
	{
	  invalidNodes.insert (tmp);
	  tmp = tmp->parent;
	}
    }

  // 1. Collect all inner-most for loop.
  s_past_node_t** infor = past_inner_loops (root);
  // 2. Check if loop body is scop.
  for (i = 0; infor[i]; ++i)
    {
      PAST_DECLARE_TYPED(for, pf, infor[i]);
      if (past_is_scop (pf->body, validNodes, invalidNodes))
	{
	  if (past_is_scop (infor[i], validNodes, invalidNodes))
	    {
	      validFor.insert(infor[i]);
	      continue;
	    }
	}
      // Node is invalid. None of its ascendant can be a scop.
      s_past_node_t* tmp = infor[i]->parent;
      for (; tmp && tmp != root; tmp = tmp->parent)
	invalidNodes.insert(tmp);
    }
  XFREE(infor);

  // 3. Proceed on all valid inner-most for loop upwards.
  std::set<s_past_node_t*>::iterator it;
  std::set<s_past_node_t*> toRemove;
  std::set<s_past_node_t*> toInsert;
  std::set<s_past_node_t*> validScops;
  for (it = validFor.begin(); it != validFor.end(); ++it)
    {
      s_past_node_t* parent = (*it)->parent;
      while (parent && past_is_scop (parent, validNodes, invalidNodes))
	parent = parent->parent;
    }

  // 4. Create scops from validNodes.
  it = validNodes.begin();
  while (validNodes.size())
    {
      if (past_node_is_a (*it, past_for) ||
	  past_node_is_a (*it, past_statement) ||
	  past_node_is_a (*it, past_if) ||
	  past_node_is_a (*it, past_affineguard) ||
	  past_node_is_a (*it, past_cloogstmt) ||
	  past_node_is_a (*it, past_block) ||
	  past_node_is_a (*it, past_root))
	{
	  s_past_node_t* parent = (*it)->parent;
	  s_past_node_t* curr = *it;
	  while (std::find (validNodes.begin(), validNodes.end(), parent)
		 != validNodes.end())
	    {
	      curr = parent;
	      parent = parent->parent;
	    }
	  // curr is the highest scop node. Look for valid siblings.
	  s_past_node_t* tmp;
	  for (tmp = curr; tmp->next; tmp = tmp->next)
	    if (std::find (validNodes.begin(), validNodes.end(), tmp)
		== validNodes.end())
	      break;
	  // curr -- tmp is the consecutive set of valid siblings,
	  // look for siblings before curr.
	  std::set<s_past_node_t*>::iterator it2;
	  int resume;
	  do
	    {
	      resume = 0;
	      for (it2 = validNodes.begin(); it2 != validNodes.end(); ++it2)
		{
		  if ((*it2)->next == curr)
		    {
		      if (std::find (validNodes.begin(), validNodes.end(), *it2)
			  == validNodes.end())
			break;
		      else
			{
			  curr = *it2;
			  resume = 1;
			}
		    }
		}
	    }
	  while (resume);

	  // curr -- tmp is the consecutive set of valid candidate
	  // siblings.  Check no iterator in candidate is read outside
	  // the scop, and ensure at least 1 loop in the scop.
	  if (! past_has_iterator_liveout (curr, tmp))
	    {
	      // mark as scop by putting in a bb and mark it as scop.
	      s_past_node_t* bb = curr;
	      if (curr != tmp)
		{
		  // create a new bb for the scop, for convenience, in
		  // case of scop made of multiple siblings.
		  s_past_node_t* bk;
		  bk = tmp->next;
		  tmp->next = NULL;
		  bb = past_node_block_create (NULL);
		  PAST_DECLARE_TYPED(block, pb, bb);
		  past_replace_node (curr, bb);
		  pb->body = curr;
		  past_set_parent (bb);
		  pb->artificial_bb = 1;
		  bb->next = bk;
		}
	      else if (! past_node_is_a (bb, past_block))
		{
		  s_past_node_t* newb = past_node_block_create (NULL);
		  past_replace_node (bb, newb);
		  PAST_DECLARE_TYPED(block, pb, newb);
		  pb->body = bb;
		  past_set_parent (newb);
		  pb->artificial_bb = 1;
		  bb = newb;
		}
	      if (past_count_nodetype (bb, past_for) > 0)
		validScops.insert(bb);
	    }
	  while (curr && curr != tmp->next)
	    {
	      s_past_node_t** n = past_collect_nodetype (curr, past_node);
	      for (i = 0; n && n[i]; ++i)
		validNodes.erase (n[i]);
	      XFREE(n);
	      curr = curr->next;
	    }
	}
      else
	validNodes.erase(*it);
      it = validNodes.begin();
    }

  // Prepare the output.
  if (verbose)
    printf ("[ScopRecognizer][INFO] Found %ld scop candidate(s)\n",
	    validScops.size());
  s_past_node_t** scopList = XMALLOC(s_past_node_t*, validScops.size() + 1);
  for (it = validScops.begin(), i = 0; it != validScops.end(); ++it)
      scopList[i++] = *it;
  scopList[i] = NULL;

  return scopList;
}
