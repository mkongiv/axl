/*
 * pastScopConverter.h: This file is part of the IR-Converter project.
 *
 * IR-Converter: a library to convert PAST to ScopLib
 *
 * Copyright (C) 2011-2014 Louis-Noel Pouchet
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 3
 * of the License, or (at your option) any later version.
 *
 * The complete GNU Lesser General Public Licence Notice can be found
 * as the `COPYING.LESSER' file in the root directory.
 *
 * Author:
 * Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 *
 */
#ifndef IRCONVERTER_PASTSCOPCONVERTER_H
# define IRCONVERTER_PASTSCOPCONVERTER_H

# include <past/past.h>
# include <scoplib/scop.h>


BEGIN_C_DECLS


/**
 * Converts a tree produced by pastScopRecognizer into a scoplib
 * representation. Each past_statement pointer is kept in the 'usr' attribute
 * of the associated scoplib_statement_p.
 *
 */
extern
scoplib_scop_p
pastScopConverter (s_past_node_t* root);



END_C_DECLS


#endif // IRCONVERTER_PASTSCOPCONVERTER_H
